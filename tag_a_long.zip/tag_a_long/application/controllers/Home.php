<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    
	    public function __construct() {
        parent::__construct();
		$this->load->model('residence_model');
		$this->load->model('crud_model');
  
     
    }
	
	public function index()
	{
		 $data ['content'] = $this->load->view('home/home', $data, true);
        $this->load->view('template_view', $data);
	}

	public function residence($id){
		$id = $this->common->decode($id);
		$data['speciality'] = $this->db->get('residence_specaility')->result();
		$data['detail'] = $this->residence_model->detail($id);
		$data ['content'] = $this->load->view('residence/detail', $data, true);
        $this->load->view('template_view', $data);
	}
	
	public function userVerify(){
		
		$userid = $this->common->decode($_GET['u']);
		$email = $this->common->decode($_GET['e']);
		
		$where = array(
		'email' => $email,
		'id' => $userid, 
		);
		$already = $this->db->get_where('users' , array(
		'email' => $email,
		'id' => $userid, 'is_verify' => 1))->row_array();
		if(!empty($already)){
			$this->session->set_flashdata('error_message', 'Your Email is Already Verified..!');
		redirect(site_url('user/login'));
		}
		$update = array(
		'status' => 1,
		'is_active' => 1,
		'is_verify' => 1,
		);
		 $this->crud_model ->updateData($update , 'users' ,  $where);
		 $this->session->set_flashdata('success_message', 'Your Email is Verified..!');
		redirect(site_url('user/login'));
	}
	
	public function userforget(){
		$data['title_bar'] = 'Forget password';
		 $data ['content'] = $this->load->view('user/forget', $data, true);
        $this->load->view('template_view', $data);
	}
	
		public function userforgetpass(){
		
	
		$email = $this->common->decode($_POST['email']);
	
		$where = array(
		'email' => $email,
		);
	

			$updatedata = array(
				'password' => md5($_POST['password']),
				'orignal_password' => $this->input->post('password')
				);
			$this->crud_model ->updateData( $updatedata, 'users' ,  $where);
			$this->session->set_flashdata('success_message', 'You have Successfully Updated Password!');
			redirect(base_url());
	}
	
	public function quality(){
		$data['title_bar'] = 'About Quality Printing';
		 $data ['content'] = $this->load->view('quality', $data, true);
        $this->load->view('templete-view', $data);
	}
	public function frames(){
		$data['title_bar'] = 'About Quality Frames';
		$data['frames'] = $this->crud_model ->getArray('frames');
		 $data ['content'] = $this->load->view('frames', $data, true);
        $this->load->view('templete-view', $data);
	}
	
		public function cms() {

        $data = array();

        $segment = $this->uri->segment(2);	
        $page = getRowArray('*', 'contentmanagement', array('slug' => $segment));
       if($page['is_contactus'] == 1){
       	$data ['content'] = $this->load->view('contact', $data, true);
        $this->load->view('template_view', $data);
        return;
       }
        if (count($page) > 0) {         
		$data['title_bar'] = $page['title'];
				$data ['title'] = $page['title'];
                $data ['content'] = $page['description'];
        } else {
         
            $data ['content'] = '404 Page not found!';
        }
        $this->load->view('template_view_cms.php', $data);
    }

public function formsubmit(){
		if(isset($_POST)){
			
		 $email = ADMIN_EMAIL;
                        $e_data['receiver_name'] = 'Admin';
                        $e_data['email_content'] = "You have New Contact Us Email Name : ".$_POST['name']. " <br>Message : ".$_POST['message']."<br> Contact Number : ".$_POST['number']." <br>Email : ".$_POST['email'];
                   
                 
                            $e_data['title'] = 'Contact us Email On '.SITE_NAME ;
                            $e_data['content'] = $data['email_content'];
                            
                            $e_data['footer'] = "Regards ".SITE_NAME;
                            $subject = $e_data['title'];
                            $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
                           // $this->emailutility->send_email_user($email_content, $email, $subject);
							
							
                $this->session->set_flashdata('success_message', 'THANK YOU FOR YOUR MESSAGE, WE WILL BE IN CONTACT WITH YOU SOON.');
				 redirect(site_url('cms/contact'));
		}
	}
	
}
