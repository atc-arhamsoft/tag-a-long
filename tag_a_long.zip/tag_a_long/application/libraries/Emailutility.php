<?php

if (!defined('APPPATH'))
    exit('No direct script access allowed');

/*
 * @Author: Saad Khan
 *
 */

final class EmailUtility {

    function __construct() {
        $this->CI = & get_Instance();
        $this->_obj = & get_instance();
        // $this->CI->load->library('phpmailer');
    }

    /*
      Send Mail
      Pra @ To Email address
      Pra @ sendor name
      Pra @ sendor email address
      Pra @ subject
      Pra @ html body
      Pra @ html text
     */

    function accountVarification($email_content, $email, $subject) {
        $body_html = $email_content;

        EmailUtility::sendMail($email, SITE_NAME,ADMIN_EMAIL, $subject, $body_html);
    }

    function send_email_user($email_content, $email, $subject) {
        $body_html = $email_content;

        EmailUtility::sendMail($email, SITE_NAME, ADMIN_EMAIL, $subject, $body_html);
    }

    function send_email_admin($email_content,$subject) {
        $body_html = $email_content;

        EmailUtility::sendMail(ADMIN_EMAIL, SITE_NAME, ADMIN_EMAIL, $subject, $body_html);
    }

    function send_contact_inquiry($email_content, $subject) {
        $body_html = $email_content;

        EmailUtility::sendMail(ADMIN_EMAIL,SITE_NAME, ADMIN_EMAIL, $subject, $body_html);
    }

    function send_companyContact_inquiry($email_content, $subject,$email) {
        $body_html = $email_content;

        EmailUtility::sendMail($email,SITE_NAME, ADMIN_EMAIL, $subject, $body_html);
    }

    function leave_feedback_message($data, $email_content,$subject) {

        $body_html = $email_content;


        EmailUtility::sendMail($data['to_email'], SITE_NAME, ADMIN_EMAIL, $subject, $body_html);
    }

    // New Function 
      function sendMail($to_email, $sendor_name, $sendor_email, $subject, $body_html, $cc = '', $bcc = '') {
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=iso-8859-1';
        $headers[] = 'To: ' . $to_email . ' <' . $to_email . '>';
        $headers[] = 'From: ' . $sendor_name . ' <' . $sendor_email . '>';
        $header[] = "X-Priority: 1"; 
        if ($cc <> '')
            $headers[] = 'Cc: ' . $cc . '';
        if ($bcc <> '')
            $headers[] = 'Bcc: ' . $bcc . '';

        $headers[] = 'X-Mailer: PHP/' . phpversion() . '';

        mail($to_email, $subject, $body_html, implode("\r\n", $headers));
       
        
    }
    // End New Function




//     function sendMail($to_email, $sendor_name, $sendor_email, $subject, $body_html, $cc = '', $bcc='') {

//         $header = "";
//         $header .= "From: " . $sendor_name . "<" . $sendor_email . ">\r\n";
// //        $cc = 'saeed.ullah3074@hotmail.com';
//         if ($cc <> '')
//             $header = "cc:  " . $cc . "\r\n";
//         if ($bcc <> '')
//             $header = "bcc:  " . $bcc . "\r\n";
//         $header .= "MIME-Version: 1.0\n";
//         $header .= "Content-type: text/html\r\n";

//         mail($to_email, $subject, $body_html, $header);
//        /* if( @$send = mail($to_email, $subject, $body_html, $header)){
//    //do something
//             die('sent');
// }else{
//       die('not sent');
//   //do something
// }*/
//     }




// Php Mailer 


    // function sendMail($to_email, $sender_name = 'Zillo', $sender_email = 'admin@blockchainlinkpoint.com', $subject, $body_html, $cc = '', $bcc = '', $attachments = array())
    // {

    //     require_once 'phpmailer/PHPMailerAutoload.php';

    //     $mail   = new PHPMailer;
    //     $mail->isSendmail();
    //     $mail->isSMTP();
    //     $mail->Host       = 'smtp.gmail.com';
    //     $mail->SMTPAuth   = true;
    //     $mail->Username   = 'buzzfli.project@gmail.com';
    //     $mail->Password   = 'buzzfliproject';
    //     $mail->SMTPSecure = 'tls';
    //     $mail->Port       = 587;
    //     $mail->From     = $sender_email;
    //     $mail->FromName = $sender_name;
    //     $mail->AddAddress($to_email);
    //     $mail->Mailer = “smtp”; 
    //     $mail->isHTML(true);

    //     $mail->Subject = $subject;
    //     $mail->Body    = $body_html;

    //     $mail->AltBody = $body_html;

    //     if (!$mail->send())
    //     {   
    //         echo 'Message could not be sent.';
    //         echo 'Mailer Error: ' . $mail->ErrorInfo . '';
    //         exit;
    //     }
    // }


}

?>