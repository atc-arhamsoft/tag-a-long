<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CollabsPostController extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
       
      
        $this->load->model('collabsPost_model');


    }

// End __construct

    /**
      @Method: index
      @Return: collabs post Listing
     */
    public function index() {

        // Check rights
        if (rights(44) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['result'] = $this->collabsPost_model->loadListing();
        $data ['content'] = $this->load->view('collabsPost/listing', $data, true);
        $this->load->view('templete-view', $data);
    }
	
    public function check_participant($post_id){
        $post_id = decode($post_id);
        $data['result_check'] = $this->collabsPost_model->check_participant($post_id);
        $data ['content'] = $this->load->view('participant/participant', $data, true);
        $this->load->view('templete-view', $data);
    }
}
