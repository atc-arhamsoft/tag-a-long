<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('dashboard_model');
        //check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
    }

// End __construct
    /**
     * Method: index
     */

    public function index() {
        $data = array();
        $data['result'] = $this->dashboard_model->getfollwers();
        $data['users'] = $this->dashboard_model->getUsers();
        $data['soloPosts'] = $this->dashboard_model->getsoloPosts();
        $data['collabsPosts'] = $this->dashboard_model->getcollabsPosts();
        $data['likePosts'] = $this->dashboard_model->getlikePosts();
        $data['UsersSPapacePlan'] = $this->dashboard_model->UsersSpacePlan();
        $data['FreeUsers'] = $this->dashboard_model->FreeUsers();
        $data['PaidUsers'] = $this->dashboard_model->PaidUsers();
        $data['TotalPayment'] = $this->dashboard_model->TotalPayment();
        $data['TotalBeatTracks'] = $this->dashboard_model->TotalBeatTracks();
        $data['FreeBeatTracks'] = $this->dashboard_model->FreeBeatTracks();
        $data['PremiumBeatTracks'] = $this->dashboard_model->PremiumBeatTracks();
        $data['content'] = $this->load->view('dashboard', $data, true);
        $this->load->view('templete-view', $data);
    }


}

//End Class