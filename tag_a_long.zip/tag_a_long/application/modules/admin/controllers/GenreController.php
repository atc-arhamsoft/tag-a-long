<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class GenreController extends CI_Controller {

    public function __construct() {
        parent::__construct();
//        error_reporting(E_ALL);
        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
      

        $this->load->model('genre_model');


    }

// End __construct
    /**
      @Method: index
      @Return: vehicles Listing
     */
    public function index() {

         // Check rights
        if (rights(24) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['result'] = $this->genre_model->loadListing();

        $data ['content'] = $this->load->view('genre/listing', $data, true);
        $this->load->view('templete-view', $data);
    }

    /**
     * Method: add
     * Return: Load Add Form
     */
    public function add() {
        $data = array();
        // Check rights
        if ($this->input->post()) {
            /// Profile Photo
            if ($_FILES['image_url']['name'] != '') {
                unlink('uploads/admin_users/pic/' . $_POST['old_image_url']);
                unlink('uploads/admin_users/small/' . $_POST['old_image_url']);
                $extension = $this->common->getExtension($_FILES ['image_url'] ['name']);
                $extension = strtolower($extension);
                if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                    return false;
                }
                $path = 'uploads/genre/';
                $allow_types = 'gif|jpg|jpeg|png';
                $max_height = '8000';
                $max_width = '8000';
                $photo = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['image_url']['tmp_name'], $_FILES ['image_url']['name']);
                $picture = base_url() . $path . 'pic/' . $photo;
                }
              
                $db_query = $this->genre_model->saveItem($_POST, $picture);


            if ($db_query) {
                $this->session->set_flashdata('success_message', 'Information successfully saved.');
                redirect('admin/genreController'); // due to flash data.
            } else {
                $this->session->set_flashdata('error_message', 'Opps! Error saving informtion. Please try again.');
            }
        }
          // Check rights
        if (rights(25) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['action'] = 'add';
        $data ['content'] = $this->load->view('genre/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    
    }

    /**
     * Method: edit
     * Return: Load Edit Form
     */
    public function edit($id) {
        $itemId = decode($id);
        $data['id'] = $itemId;
        $data['row'] = $this->genre_model->getRow($itemId);

          // Check rights
        if (rights(26) != true) {
            redirect(base_url('admin/dashboard'));
        }


        $data['action'] = 'edit';
        $data ['rights'] = $this->genre_model->rights();
        $data ['content'] = $this->load->view('genre/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }

    /**
      @Method: delete
      @Params: itemId
      @Retrun: True/False
     */
    public function delete($id) {

        
        $itemId = decode($id);
        $result = $this->genre_model->deleteItem($itemId);
        if ($result) {
            $this->session->set_flashdata('success_message', 'Record deleted successfully.');
            redirect('admin/genreController'); // due to flash data.
        } else {
            $this->session->set_flashdata('error_message', 'Opps! Error occured while deleting record. Please try again.');
        }
    }

    /**
     * Method: ajaxChangeStatus
     *
     */
    public function ajaxChangeStatus() {
        $itemId = $_POST['itemId'];
        $status = $_POST['status'];
        $result = $this->genre_model->updateItemStatus($itemId, $status);
        echo $result;
    }

    public function checkname() {
        
        $genrename = $_POST['name'];
        $name = $this->genre_model->checkname($genrename);
        if ($name == 0) {
            echo 0;
        } else {
            echo 1;
        }
        exit;
    }

}



//End Class