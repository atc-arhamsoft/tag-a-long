<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home_Setting extends CI_Controller {

    public $tbl = 'site_settings';

    public function __construct() {
        parent::__construct();
        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
        // Check rights
        $this->load->model('Home_setting_model');
    }

// End __construct
    /**
     * Method: index
     */
    public function index() 
    {
        $result = $this->Home_setting_model->getSettings();
        $row = array();
        foreach($result as $row1)
        {
            $row[$row1['field_name']] = $row1['field_value'];
        }    
        $data['row'] = $row;
      
        if ($this->input->post())
        {
           
            $db_query = $this->Home_setting_model->saveItem($_POST);

            if ($db_query) {
                $this->session->set_flashdata('success_message', 'Information successfully saved.');
                redirect('admin/Home_Setting'); // due to flash data.
            } else {
                $this->session->set_flashdata('error_message', 'Opps! Error saving informtion. Please try again.');
            }
        }
        $data ['content'] = $this->load->view('home_setting/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }
}

//End Class