<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Payment_method extends CI_Controller {

    public $tbl = 'site_settings';

    public function __construct() {
        parent::__construct();
        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
        $this->load->model('payment_method_model');
    }

// End __construct
    /**
     * Method: index
     */
    public function index() 
    {  
        $data ['row'] = $this->payment_method_model->getMethods();
        $data ['content'] = $this->load->view('payment_method/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
 
    }
    public function saveData(){
        
            $db_query = $this->payment_method_model->saveItem($_POST);

            if ($db_query) {
                $this->session->set_flashdata('success_message', 'Information successfully saved.');
                redirect('admin/payment_method'); // due to flash data.
            } else {
                $this->session->set_flashdata('error_message', 'Opps! Error saving informtion. Please try again.');
           }
    }
}

//End Class