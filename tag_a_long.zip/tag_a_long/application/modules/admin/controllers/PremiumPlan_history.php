<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class PremiumPlan_history extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
		$this->load->model('premiumPlanHistory_model');


    }

// End __construct
    /**
      @Method: index
      @Return: vehicles Listing
     */
    public function index() {

        // Check rights
        if (rights(43) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $query = $this->premiumPlanHistory_model->StatusChangeToRead();

        $data['result'] = $this->premiumPlanHistory_model->loadListing();
        $data ['content'] = $this->load->view('premiumPlan_history/listing', $data, true);
        $this->load->view('templete-view', $data);
    }
}
