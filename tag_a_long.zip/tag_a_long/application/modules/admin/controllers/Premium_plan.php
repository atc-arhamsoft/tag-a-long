<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Premium_plan extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
        
        $this->load->model('premiumPlan_model');


    }

// End __construct
    /**
      @Method: index
      @Return: vehicles Listing
     */
    public function index() {
        $data['result'] = $this->premiumPlan_model->loadListing();
        

        $data ['content'] = $this->load->view('premium_plan/listing', $data, true);
        $this->load->view('templete-view', $data);
    }

    /**
     * Method: add
     * Return: Load Add Form
     */
    public function add() {
        $data = array();

        if ($this->input->post()) {

            $db_query = $this->premiumPlan_model->saveItem($_POST);

            if ($db_query) {
                $this->session->set_flashdata('success_message', 'Role successfully saved.');
                redirect('admin/premium_plan'); // due to flash data.
            } else {
                $this->session->set_flashdata('error_message', 'Opps! This role already exist.');
            }
        }
       
        $data['action'] = 'add';
        $data ['rights'] = $this->premiumPlan_model->rights();
        $data ['content'] = $this->load->view('premium_plan/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }

    /**
     * Method: edit
     * Return: Load Edit Form
     */
    public function edit($id) {

        $plan_id = decode($id);
        // $data['id'] = $itemId;
        $data['row'] = $this->premiumPlan_model->getRow($plan_id);
        $data['action'] = 'edit';
        $data ['rights'] = $this->premiumPlan_model->rights();
        $data ['content'] = $this->load->view('premium_plan/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }

    /**
      @Method: delete
      @Params: itemId
      @Retrun: True/False
     */
    public function delete($id) {
      
        $itemId = decode($id);
        $result = $this->premiumPlan_model->deleteItem($itemId);
        if ($result) {
            $this->session->set_flashdata('success_message', 'Record deleted successfully.');
            redirect('admin/premium_plan'); // due to flash data.
        } else {
            $this->session->set_flashdata('error_message', 'Opps! Error occured while deleting record. Please try again.');
        }
    }

    /**
     * Method: ajaxChangeStatus
     *
     */
    public function ajaxChangeStatus() {
        $itemId = $_POST['itemId'];
        $status = $_POST['status'];
        $result = $this->premiumPlan_model->updateItemStatus($itemId, $status);
        echo $result;
    }
    public function checkTokenName() {
        $plan_name = $_POST['plan_name'];
        $name = $this->premiumPlan_model->checkTokenName($plan_name);
        if ($name == 0) {
            echo 0;
        } else {
            echo 1;
        }

        exit;
    }

  

}



//End Class