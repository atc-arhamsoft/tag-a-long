<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SoloPostController extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');

        $this->load->model('soloPost_model');


    }

// End __construct
    /**
      @Method: index
      @Return:  Listing
     */
    public function index() {

        // Check rights
        if (rights(44) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['result'] = $this->soloPost_model->loadListing();
        $data ['content'] = $this->load->view('soloPost/listing', $data, true);
        $this->load->view('templete-view', $data);
    }
}
