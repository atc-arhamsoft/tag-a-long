<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SpacePlan_history extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');
       // $this->engineinit->_is_not_super_admin_redirect('admin/dashboard');
    
        $this->load->model('spacePlanHistory_model');


    }

// End __construct
    /**
      @Method: index
      @Return: vehicles Listing
     */
    public function index() {
      // Check rights
        if (rights(43) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $query = $this->spacePlanHistory_model->StatusChangeToRead();

        $data['result'] = $this->spacePlanHistory_model->loadListing();
        $data ['content'] = $this->load->view('spacePlan_history/listing', $data, true);
        $this->load->view('templete-view', $data);
    }
}
