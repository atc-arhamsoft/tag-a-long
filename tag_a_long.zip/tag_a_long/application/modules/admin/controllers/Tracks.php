<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tracks extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // check if admin login
        $this->engineinit->_is_not_admin_logged_in_redirect('admin/login');

        $this->load->model('tracks_model');
        $this->load->library('emailutility');
    }

// End __construct
    /**
      @Method: index
      @Return: vehicles Listing
     */
    public function index() {

        // Check rights
        if (rights(14) != true) {
            redirect(base_url('admin/dashboard'));
        }

        if (isset($_GET['filter'])) {
            $search_query = $_GET['filter'];
        }

        $data['result'] = $this->tracks_model->loadListing($search_query);
//        $data['pagination'] = $this->pagination->create_links();
        $data['search_query'] = $search_query;
        $data ['content'] = $this->load->view('tracks/listing', $data, true);

        $this->load->view('templete-view', $data);
    }

    /**
     * Method: add
     * Return: Load Add Form
     */
    public function add() {
        ini_set('post_max_size', '500M');
        ini_set('upload_max_filesize', '500M');
        $data = array();
        // Check rights

        if ($this->input->post()) {
            $oldmask = umask(0);
            //Profile Image
            if ($_FILES['image_url']['name'] != '') {
                unlink('uploads/admin_users/pic/' . $_POST['old_image_url']);
                unlink('uploads/admin_users/small/' . $_POST['old_image_url']);
                $extension = $this->common->getExtension($_FILES ['image_url'] ['name']);
                $extension = strtolower($extension);
                if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                    return false;
                }
                $path = 'uploads/track_photo/';
                $allow_types = 'gif|jpg|jpeg|png';
                $max_height = '8000';
                $max_width = '8000';
                $photo = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['image_url']['tmp_name'], $_FILES ['image_url']['name']);
                $picture = base_url() . $path . 'pic/' . $photo;
            }
            /// Profile Photo
            if ($_FILES['audio_url']['name'] != '') {
                unlink('uploads/tracks/' . $_POST['old_file_name']);
                $extension = $this->common->getExtension($_FILES ['audio_url'] ['name']);
                $extension = strtolower($extension);
                $path = 'uploads/tracks/';
                $tag_name = $_FILES ['audio_url']['tmp_name'];
                $file_name = $_FILES ['audio_url']['name'];
            
                $name = explode(".", $file_name);
                $up_ext = strtolower($name [(count($name) - 1)]);
                $rand = rand(1, 99999999999);
                $string = str_replace(' ', '-', $name[0]); // Replaces all spaces with hyphens.
                $names = preg_replace('/[^A-Za-z0-9\-]/', '', $string);
                $file_name = $names . '_' . $rand . '.' . $up_ext;
                $target_path = $path . $file_name;

                chmod($_SERVER['DOCUMENT_ROOT'] . '/' . $target_path, 0777);
                if (move_uploaded_file($tag_name, $target_path)) {

                    umask($oldmask);
                }

                $target_path = BURL . $target_path;
            }

            $db_query = $this->tracks_model->saveItem($_POST, $target_path, $picture);

            if ($db_query) {
                $this->session->set_flashdata('success_message', 'Information successfully saved.');
                redirect('admin/tracks'); // due to flash data.
            } else {
                $this->session->set_flashdata('error_message', 'Opps! Error saving informtion. Please try again.');
            }
        }
        // Check rights
        if (rights(15) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['GenreRow'] = $this->tracks_model->GetGenre();
        $data['action'] = 'add';
        $data ['content'] = $this->load->view('tracks/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }

    /**
     * Method: edit
     * Return: Load Edit Form
     */
    public function edit($id) {

        $itemId = decode($id);
        $data['id'] = $itemId;
        $data['GenreRow'] = $this->tracks_model->GetGenre();
        $data['row'] = $this->tracks_model->getRow($itemId);

        // Check rights
        if (rights(16) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $data['action'] = 'edit';

        $data ['content'] = $this->load->view('tracks/form', $data, true); //Return View as data
        $this->load->view('templete-view', $data);
    }

    /**
      @Method: delete
      @Params: itemId
      @Retrun: True/False
     */
    public function delete($id) {
        // Check rights
        if (rights(17) != true) {
            redirect(base_url('admin/dashboard'));
        }

        $itemId = decode($id);
        $result = $this->tracks_model->deleteItem($itemId);
        if ($result) {
            $this->session->set_flashdata('success_message', 'Record deleted successfully.');
            redirect('admin/tracks'); // due to flash data.
        } else {
            $this->session->set_flashdata('error_message', 'Opps! Error occured while deleting record. Please try again.');
        }
    }

    /**
     * Method: ajaxChangeStatus
     *
     */
    public function ajaxChangeStatus() {
        $itemId = $_POST['itemId'];
        $status = $_POST['status'];
        $result = $this->tracks_model->updateItemStatus($itemId, $status);
        echo $result;
    }

    public function check_extenstion() {
        $v = $this->input->post('audio_url');
        $extension = $this->common->getExtension($v);
        if ($extension == "m4a" || $extension == "mp3") {
            echo 0;
        } else {
            echo 1;
        }
        exit;
    }

    public function check_trackName() {
        $title = $this->input->post('title');
        $name = $this->tracks_model->check_trackName($title);
        if ($name == 1) {
            echo 0;
        } else {
            echo 1;
        }

        exit;
    }

    public function approve_track() {
       
        $data = array('approve' => 1);
        $this->db->where('track_id', $_POST['id']);
        $this->db->update("tracks", $data);
         $user=getVal('user_id','tracks', 'track_id',$_POST['id']);
       
        $to_user = getValArray('email,name', 'users', 'user_id', $user);
        $e_data['receiver_name'] = $to_user['name'];

        $e_data['email_content'] = "Congratulations!
                                <br /><br />
                                Your track has been approved. you can use this track free.
                                <br /><br />
                                Thankyou
                                ";


        $e_data['title'] = 'Your track has been approved';
        $e_data['footer'] = "Copyright &copy; " . date("Y") . " Tag-a-Long. All Rights Reserved.";
        $subject = $e_data['title'];
        $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
       
        $this->emailutility->send_email_user($email_content, $to_user['email'], $subject);
        $data['msg'] = "Approve Email sent Successfully";

        echo json_encode($data, JSON_NUMERIC_CHECK);


        exit;
    }

}

//End Class