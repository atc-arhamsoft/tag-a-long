<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CollabsPost_model extends CI_Model {
    

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $this->db->select('users.name as user_name,posts.*');
        $this->db->from('users','posts');
        $this->db->join('posts', 'posts.user_id = users.user_id');
        $this->db->where('posts.post_type','1');
        $query = $this->db->get();
        return $query;
        
    }
    public function check_participant($post_id) {
        $this->db->select('participant.*');
        $this->db->from('participant');
        $this->db->join('users', 'users.user_id = participant.user_id');
        $this->db->where('post_id',$post_id);
        $query = $this->db->get();
        return $query->result();
    }
}
