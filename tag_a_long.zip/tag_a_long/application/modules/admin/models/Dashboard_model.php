<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class dashboard_model extends CI_Model {

    var $tbl = 'admin_users';

    public function __construct() {
        parent::__construct();
     }
     function getfollwers()
     {
        $this->db->select('*');
        $this->db->from('follower');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function getsoloPosts()
     {
        $this->db->select('*');
        $this->db->from('posts');
        $this->db->where('post_type','0');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function getUsers()
     {
        $this->db->select('*');
        $this->db->from('users');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function getcollabsPosts()
     {
        $this->db->select('*');
        $this->db->from('posts');
        $this->db->where('post_type','1');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function getlikePosts()
     {
        $this->db->select('*');
        $this->db->from('post_likes');
        $query = $this->db->get();
        return $query->num_rows();
     }
     public function UsersSpacePlan()
     {
        $this->db->select('*');
        $this->db->where('purchase_type',3);
        $this->db->from('payment_history');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function FreeUsers()
     {
        $this->db->select('*');
        $this->db->where('is_premium','0');
        $this->db->from('users');
        $query = $this->db->get();
        return $query->num_rows();
     }

     function PaidUsers()
     {
        $this->db->select('*');
        $this->db->where('is_premium','1');
        $this->db->from('users');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function TotalPayment()
     {
        $this->db->select_sum('price');
        $result = $this->db->get('payment_history')->row();  
        $value = $result->price;
        $value = round($value,2);
        return $value;
     }
     function TotalBeatTracks()
     {
         $this->db->select('*');
        $this->db->from('tracks');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function FreeBeatTracks()
     {
        $this->db->select('*');
        $this->db->where('is_free','1');
        $this->db->from('tracks');
        $query = $this->db->get();
        return $query->num_rows();
     }
     function PremiumBeatTracks()
     {
        $this->db->select('*');
        $this->db->where('is_free','0');
        $this->db->from('tracks');
        $query = $this->db->get();
        return $query->num_rows();
     }
    public function GetUsersNotifications(){
        $this->db->select('*');
        $this->db->where('is_read','0');
        $this->db->from('users');
        $query = $this->db->get();
        return $query->num_rows();
     }
        public function Newslettersubscription()
        {
        $this->db->select('*');
        $this->db->where('is_read',0);
        $this->db->from('subcribe_email');
        $query = $this->db->get();
        return $query->num_rows();
        }

    }
 ?>
