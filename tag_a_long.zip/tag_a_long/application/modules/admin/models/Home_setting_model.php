<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home_setting_model extends CI_Model {

    var $tbl = 'home_setting';

    public function __construct() {
        parent::__construct();
    }

//End __construct
    /**
     * Method: getRow
     * Params: $id
     * Return: data row
     */
    function getSettings() {
        $this->db->select('*');
        $this->db->from($this->tbl);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

//End get_row
    /**
     * Method: saveItem
     * Params: $post
     * Return: True/False
     */
    public function saveItem($post) 
    {
        $data_insert = array();
        if (is_array($post)) {
            foreach ($post as $k => $v) {
                $data_insert[$k] = $v;
            }
        }
       

        foreach ($data_insert as $key => $value) {
            $query = $this->db->query("select id from home_setting where field_name = '" . $key . "'");
            if ($query->num_rows() > 0) {
                $upData = array();
                $upData['field_value'] = $value;
                $this->db->where('field_name', $key);
                $this->db->update('home_setting', $upData);
            } else {
                $insData = array();
                $insData['field_name'] = $key;
                $insData['field_value'] = $value;
                $this->db->insert('home_setting', $insData);
            }
        }

        return 1;
    }

}

//End Class