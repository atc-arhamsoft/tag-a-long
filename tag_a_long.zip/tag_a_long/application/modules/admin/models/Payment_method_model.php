<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Payment_method_model extends CI_Model {

    var $tbl = 'site_settings';

    public function __construct() {
        parent::__construct();
    }

//End __construct
    /**
     * Method: getRow
     * Params: $id
     * Return: data row
     */
    function getMethods() {
        $this->db->select('*');
        $this->db->from('payment_integration');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        }
    }

//End get_row
    /**
     * Method: saveItem
     * Params: $post
     * Return: True/False
     */
    public function saveItem($post) 
    {
    $id = $this->input->post('id');
    $data['id'] = $this->input->post('id');
    $data['braintree_merchant_id'] = $this->input->post('braintree_merchant_id');
    $data['braintree_public_key'] = $this->input->post('braintree_public_key');
    $data['braintree_private_key'] = $this->input->post('braintree_private_key');
    $data['braintree_environment'] = $this->input->post('braintree_environment');
    $data['is_active'] = '1';
    $this->db->where('id', $id);
    $this->db->update('payment_integration', $data);
    return 1;
    }

}

//End Class