<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class PremiumPlanHistory_model extends CI_Model {
    

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $this->db->select('users.name as user_name,payment_history.*,premium_plans.plan_name as premiumplan_name');
        $this->db->from('users','payment_history','premium_plans');
        $this->db->join('payment_history', 'payment_history.user_id = users.user_id');
        $this->db->join('premium_plans', 'premium_plans.plan_id = payment_history.plan_id');
        $this->db->where('payment_history.purchase_type	','2');
        $query = $this->db->get();
        return $query;
      
    }
     public function StatusChangeToRead(){
         $this->db->select('*');
         $this->db->from('payment_history');
         $query = $this->db->get()->result_array();
         $update['is_purcahsed'] = 1;
         foreach ($query as $value) 
         {
              $this->db->where('purchase_type',2);
              $this->db->update('payment_history',$update);
         }
         return $query;
    }
}
