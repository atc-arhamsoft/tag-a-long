<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class soloPost_model extends CI_Model {
    

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $this->db->select('users.name as user_name,posts.*');
        $this->db->from('users','posts');
        $this->db->join('posts', 'posts.user_id = users.user_id');
        $this->db->where('posts.post_type','0');
        $query = $this->db->get();
        return $query;
        
    }
}
