<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Testimonial_model extends CI_Model {
    
    var $tbl = 'admin_users';
    var $tbl_testimonial = 'testimonial';
    var $tbl_rights = 'admin_rights';
    var $tbl_permission = 'admin_permissions';

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $sql_ = "SELECT
                    *
                FROM
                    " . $this->tbl_testimonial . " role where id != '0'";

        $sql_ .= "ORDER BY id DESC";
        $query = $this->db->query($sql_);
        return $query;
    }

    function getRow($id) {

        $query = "SELECT * from testimonial where id=$id";
        $query = $this->db->query($query);

        if ($query->num_rows() > 0) {
            return $query->row_array();
        }
    }

    public function deleteItem($itemId) {
        $this->db->where('id', $itemId);
        $this->db->delete('testimonial');
        $error = $this->db->error();
        if ($error['code'] <> 0) {
            return false;
        } else {
            return true;
        }
    }

   
    public function saveItem($post, $image) {
        $data_insert = array();
        $id = $post['id'];
        $data_insert['name'] = $post['name'];
        $data_insert['about'] = $post['about'];

        if ($image <> '') {
            $data_insert['image_url'] = $image;
            unset($data_insert['old_image_url']);
        } 
        else {
            if($data_insert['old_image_url'] != '')
            $data_insert['image_url'] = $data_insert['old_image_url'];
            else
            unset($data_insert['image_url']);
            unset($data_insert['old_image_url']);
        }
    
        if ($post['action'] == 'add') {//Save Data
            return $this->db->insert('testimonial', $data_insert);
        } else {//Update Data

            $this->db->where('id', $id);
            return $this->db->update('testimonial', $data_insert);
        }
    }

}



//End Class