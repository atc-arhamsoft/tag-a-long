<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Token_plan_model extends CI_Model {
    
    var $tbl = 'admin_users';
    var $tbl_tokenplans = 'tokenplans';
    var $tbl_rights = 'admin_rights';
    var $tbl_permission = 'admin_permissions';

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $sql_ = "SELECT
                    *
                FROM
                    " . $this->tbl_tokenplans . "  where plan_id != '0'";

        $sql_ .= "ORDER BY plan_id DESC";
        $query = $this->db->query($sql_);
        return $query;
    }

    function getRow($id) {

        $query = "Select * from $this->tbl_tokenplans where plan_id=$id";
        $query = $this->db->query($query);

        if ($query->num_rows() > 0) {
            return $query->row_array();
        }
    }

    /**
     * Method: updateItemStatus
     * Params: $itemId, $status
     */
    public function updateItemStatus($itemId, $status) {
        if ($status == 1) {
            $status = 0;
        } else {
            $status = 1;
        }
        $data_insert = array('is_active' => $status);
        $this->db->where('plan_id', $itemId);
        $this->db->update('tokenplans', $data_insert);
        $action = 'Status updated successfully. Please wait...';
        $msg = $action;
        return $msg;
    }

    /**
     * Method: deleteItem
     * Params: $itemId
     * Return: True/False
     */
    public function deleteItem($itemId) {
        $this->db->where('plan_id', $itemId);
        $this->db->delete($this->tbl_tokenplans);
        $error = $this->db->error();
        if ($error['code'] <> 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Method: saveItem
     * Params: $post
     * Return: True/False
     */
    public function saveItem($post) {

        $id = $post['plan_id'];
        $data_insert['token_name'] = $post['token_name'];
        $data_insert['tokens'] = $post['tokens'];
        $data_insert['price'] = $post['price'];
        $data_insert['store_id'] = $post['store_id'];
        $data_insert['is_active'] = $post['is_active'];
        if ($post['action'] == 'add') {//Save Data
            $this->db->insert('tokenplans', $data_insert);
            $this->session->set_flashdata('success_message', 'Role successfully saved.');
            redirect('admin/tokenplans');

        } else {//Update Data
            $this->db->where('plan_id', $id);
            $db = $this->db->update('tokenplans', $data_insert);   
            return $db;
        }
    }

    function rights() {
        $this->db->select('admin_rights.*');
        $this->db->select('admin_modules.module');
        $this->db->join('admin_modules', 'admin_modules.id = admin_rights.module_id', 'left');
        $this->db->where('admin_rights.status', 1);
        $this->db->order_by("admin_modules.id", "asc");
        $this->db->order_by("admin_rights.id", "asc");
        $query = $this->db->get('admin_rights');
        return $query->result_array();
    }

    function checkTokenName($token_name) {
        $sql_ = "SELECT token_name FROM tokenplans WHERE token_name = '" . $token_name . "'";
        $query = $this->db->query($sql_);
        if ($query->num_rows() >= 1) {
            return 1;
        } else {
            return 0;
        }
    }

}



//End Class