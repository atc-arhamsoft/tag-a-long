<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tracks_model extends CI_Model {

    var $tbl = 'tracks';
    var $tbl_roles = 'admin_roles';

    public function __construct() {
        parent::__construct();
    }

//End __construct
    // Common Functions
    public function loadListing($search_query = '') {
          if(isset($search_query) && ($search_query != '') ){
            $this->db->select('*');
           $this->db->where('is_free',$search_query);
           return $this->db->get('tracks');
          }
          else
        {
            // ""
            $this->db->select('*');
            return $this->db->get('tracks');
        }
    }
    public function GetGenre() {
        $sql_ = "SELECT * FROM genre";
        $query = $this->db->query($sql_)->result_array();
        return $query;
    }
    function getRow($id) {
        $query = $this->db->get_where($this->tbl, array('track_id' => $id));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        }
    }

    /**
     * Method: updateItemStatus
     * Params: $itemId, $status
     */
    public function updateItemStatus($itemId, $status) {
        if ($status == 1) {
            $status = 0;
        } else {
            $status = 1;
        }
        $data_insert = array('is_active' => $status);
        $this->db->where('track_id', $itemId);
        $this->db->update($this->tbl, $data_insert);
        $action = 'Status updated successfully. Please wait...';
        $msg = $action;
        return $msg;
    }

    /**
     * Method: deleteItem
     * Params: $itemId
     * Return: True/False
     */
    public function deleteItem($itemId) {
        $this->db->where('track_id', $itemId);
        $this->db->delete($this->tbl);
        $error = $this->db->error();
        if ($error['code'] <> 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Method: saveItem
     * Params: $post
     * Return: True/False
     */
    public function saveItem($post, $audio,$picture) {
       
        $id = $post['track_id'];
        $data_insert = array();
        if (is_array($post)) {
            foreach ($post as $k => $v) {
                if ($k != 'track_id' && $k != 'action') {
                    $data_insert[$k] = $v;
                }
            }
        }
        if ($audio <> '') {
            $audio_url = $audio;
            $data_insert['audio_url'] = $audio_url;
            unset($data_insert['old_file_name']);
        } else {
            if($data_insert['old_file_name'] != '')
            $data_insert['audio_url'] = $data_insert['old_file_name'];
            else
            unset($data_insert['audio_url']);
            unset($data_insert['old_file_name']);
        }

         if ($picture <> '') {
            $data_insert['image_url'] = $picture;
            unset($data_insert['old_image_url']);
        } 
        else {
            if($data_insert['old_image_url'] != '')
            $data_insert['image_url'] = $data_insert['old_image_url'];
            else
            unset($data_insert['image_url']);
            unset($data_insert['old_image_url']);
        }
        if($post['is_free']==1){
             unset($data_insert['required_tag_tokens']);
        }
         
        if ($post['action'] == 'add') {//Save Data
            
            $data_insert['created'] = strtotime(date('Y-m-d H:i:s'));
           
            return $this->db->insert($this->tbl, $data_insert);
           
        } else {//Update Data
            if($data_insert['is_free']==1){
                $data_insert['required_tag_tokens']=0;
            }
            $this->db->where('track_id', $id);
            return $this->db->update($this->tbl, $data_insert);
        }
    }

    function check_trackName($title) {
        $sql_ = "SELECT title FROM tracks WHERE title = '" . $title . "'";
        $query = $this->db->query($sql_);
        if ($query->num_rows() >= 1) {
            return 1;
        } else {
            return 0;
        }
    }

}

//End Class