<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SpacePlanHistory_model extends CI_Model {
    

    public function __construct() {
        parent::__construct();
       
    }
   
//End __construct
    // Common Functions
    public function loadListing() {
        $this->db->select('users.name as user_name,payment_history.*,additional_space.space as space_name');
        $this->db->from('users','payment_history','additional_space');
        $this->db->join('payment_history', 'payment_history.user_id = users.user_id');
        $this->db->join('additional_space', 'additional_space.plan_id = payment_history.plan_id');
        $this->db->where('payment_history.purchase_type	','3');
        $query = $this->db->get();
        return $query;
    }

    public function StatusChangeToRead(){
         $this->db->select('*');
         $this->db->from('payment_history');
         $query = $this->db->get()->result_array();
         $update['is_purcahsed'] = 1;
         foreach ($query as $value) 
         {
              $this->db->where('purchase_type',3);
              $this->db->update('payment_history',$update);
         }
         return $query;
    }
}
