
<div class="page-header">
    <h1>
        Genre
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Show Testimonial
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
        <?php
        if (rights(25) == true) {
            ?>
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <a href="<?php echo base_url('admin/Testimonial/add') ?>"><button type="button" class="btn btn-primary"   style="float: right; margin-right: 15px;">Add New</button></a>
            </div>
        <?php } ?>
    </div>
</div>

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="alert" id="formErrorMsg" style="display: none;">
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Image</th>
                    <th>About You</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows() > 0) {

                    foreach ($result->result() as $row) {
                        ?>
                        <tr id="roles_<?php echo $row->id; ?>">
                            <td><?php echo ucwords($row->name); ?></td>
                            <td><img style="height:40px;width:40px;" src="<?php echo $row->image_url?>" alt=""></td>
                            <td><?php echo $row->about?></td>
                            <td>
                                <a  href="<?php echo base_url('admin/testimonial/edit/' . encode($row->id)) ?>" class="tooltip-success" data-rel="tooltip" title="Edit">
                                    <span class="green">
                                        <i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
                                    </span>
                                </a> 
                               <a href="<?php echo base_url('admin/testimonial/delete/' . encode($row->id)) ?>" onclick="return delete_confirm();" class="tooltip-error" data-rel="tooltip" title="Delete">
                                    <span class="red">
                                        <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                    </span>
                                </a>        
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                <?php }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- page specific plugin scripts -->

<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.bootstrap.min.js') ?>"></script>
<script>
    jQuery(function () {
        $('#dynamic-table').dataTable({
        bAutoWidth: false,
        "aoColumns": [
        {"bSortable": true},
        {"bSortable": true},
        null,
        {"bSortable": false}
        ],
        "aaSorting": []

        });


    });
</script>