<div class="breadcrumbs" id="breadcrumbs">
    <script type="text/javascript">
        try {
            ace.settings.check('breadcrumbs', 'fixed')
        } catch (e) {
        }
    </script>

    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="#">Home</a>
        </li>
        <li class="active">Dashboard</li>
    </ul><!-- /.breadcrumb -->
</div>

    <div class="page-header">
        <h1>
            Dashboard
            <small>
                <i class="ace-icon fa fa-angle-double-right"></i>
                overview &amp; stats
            </small>
        </h1>
    </div><!-- /.page-header -->

    <div class="row">
        <div class="col-xs-12">
            <!-- PAGE CONTENT BEGINS -->
            <div class="alert alert-block alert-success">
                <button type="button" class="close" data-dismiss="alert">
                    <i class="ace-icon fa fa-times"></i>
                </button>

                <i class="ace-icon fa fa-check green"></i>

                Welcome to
                <strong class="green">
                    <?php echo ucwords(SITE_NAME);?>

                </strong>

            </div>

            <div class="row">
                <div class="space-6"></div>

                <div class="col-sm-12 infobox-container">
                    <div class="infobox infobox-green">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-users"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $users;?></span>
                            <div class="infobox-content">Total Users</div>
                        </div>
                    </div>
                    <div class="infobox infobox-green">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-users"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $PaidUsers;?></span>
                            <div class="infobox-content">Paid Users</div>
                        </div>
                    </div>
                    <div class="infobox infobox-green">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-users"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $FreeUsers;?></span>
                            <div class="infobox-content">Free Users</div>
                        </div>
                    </div>

                    <div class="infobox infobox-blue">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-check"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $result;?></span>
                            <div class="infobox-content">Followers</div>
                        </div>

                       
                    </div>
                    <div class="infobox infobox-blue">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-check"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $result;?></span>
                            <div class="infobox-content">Following</div>
                        </div>

            
                    </div>

                    <div class="infobox infobox-pink">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-shopping-cart"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $soloPosts;?></span>
                            <div class="infobox-content">Solo Posts</div>
                        </div>
                    </div>

                    <div class="infobox infobox-red">
                        <div class="infobox-icon">
                            <i class="ace-icon fa fa-shopping-cart"></i>
                        </div>

                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $collabsPosts;?></span>
                            <div class="infobox-content">Collabs Post</div>
                        </div>
                    </div>

                    <div class="infobox infobox-pink">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-thumbs-up"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $likePosts;?></span>
                            <div class="infobox-content">Liked Post</div>
                        </div>
                    </div>

                    <div class="infobox infobox-orange2">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-users"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $UsersSPapacePlan;?></span>
                            <div class="infobox-content">User (Space Plan)</div>
                        </div>
                    </div>
                    <div class="infobox infobox-orange2">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-usd"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $TotalPayment;?></span>
                            <div class="infobox-content">Total Payment</div>
                        </div>
                    </div>
                    <div class="infobox infobox-pink">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-music"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $TotalBeatTracks;?></span>
                            <div class="infobox-content">Total Tracks</div>
                        </div>
                    </div>
                     <div class="infobox infobox-orange2">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-music"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $FreeBeatTracks;?></span>
                            <div class="infobox-content">Free Tracks</div>
                        </div>
                    </div>

                     <div class="infobox infobox-green">
                         <div class="infobox-icon">
                            <i class="ace-icon fa fa-music"></i>
                         </div>
                        <div class="infobox-data">
                            <span class="infobox-data-number"><?php echo $PremiumBeatTracks;?></span>
                            <div class="infobox-content">Premium Tracks</div>
                        </div>
                    </div>


                 
                    

                </div>

            </div><!-- /.row -->

            <div class="hr hr32 hr-dotted"></div>


            <div class="hr hr32 hr-dotted"></div>


            <!-- PAGE CONTENT ENDS -->
        </div><!-- /.col -->
    </div><!-- /.row -->
<!-- /.page-content -->
