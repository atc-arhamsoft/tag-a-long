<div class="page-header">
    <h1>
        Genre

    </h1>
</div><!-- /.page-header -->

<div class="breadcrumbs" id="breadcrumbs">
    <script type="text/javascript">
        try {
            ace.settings.check('breadcrumbs', 'fixed')
        } catch (e) {
        }
    </script>

    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="<?php echo base_url('admin/dashboard') ?>">Home</a>
        </li>

        <li>
            <a href="<?php echo base_url('genreController/users') ?>">Gnere</a>
        </li>
        <li class="active">Add users</li>
    </ul><!-- /.breadcrumb -->


</div>


<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="space-8"></div>
        <div class="space-8"></div>
        <form id="users_form" name="users_form" action="<?php echo base_url('admin/genreController/add') ?>" class="form-horizontal" role="form" method="post"  accept-charset="utf-8" enctype="multipart/form-data">

            <input type="hidden" name="action" id="action" value="<?php echo $action; ?>">

            <input type="hidden"  id="id" name="id" value="<?php echo $row['id']; ?>"  >
           
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Name*</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" class="col-xs-12 col-sm-5" id="name" name="name"  placeholder="Name" onchange="checkname();" value="<?php echo $row['name']; ?>" required>
                    </div>
                    <span style="color:#d16e6c" id="name_error"></span>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Status *</label>
                <div class="col-xs-12 col-sm-9">
                    <div>
                        <label class="blue">
                            <input type="radio" id="status" class="ace" <?php echo ( isset($row) && $row['is_active'] == 1) ? 'checked' : '' ?> value="1" name="is_active" required>
                            <span class="lbl">&nbsp;Active</span>
                        </label>
                    </div>
                    <div>
                        <label class="blue">
                            <input type="radio" class="ace" <?php echo ( isset($row) && $row['is_active'] == 0) ? 'checked' : '' ?> id="status" value="0" name="is_active" required>
                            <span class="lbl">&nbsp;Inactive</span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="photo">Profile Image</label>

                <div  class="col-xs-10 col-sm-4">
                    <input class="col-xs-12 col-sm-5 ckeditor" type="file" id="image_url" name="image_url">
                    <div class="space-2"></div>
                    <input type="hidden" name="old_profile_image"  id="old_photo" value="<?php echo $row['image_url']; ?>">
                      <?php
                    if (isset($row)) {
                        if ($row['image_url'] == '') {
                            $row['image_url'] = 'abc.png';
                        }
                        echo '<img src="' . $this->common->check_image(base_url("uploads/admin_users/small/" . $row['profile_image']), 'no_image.jpg') . '" width="50" height="50" />';
                    }
                    ?>


                </div>
            </div>
            <div class="space-2"></div>

            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Submit
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#users_form');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                        Reset
                    </button>
                </div>
            </div>

        </form>

    </div>
</div>

<script>
        function checkname()
        {       
            var url = '<?php echo base_url("admin/genreController/checkname");?>';
            var name=$('#name').val();
            $.ajax({
            type:'post',
            url:url,
            data:{name:name},
            success:function(data){
            console.log(data);
            if(data==1)
            { 
            $("#name_error").html('This User Already Exist');
            $('#name').val("");
            }
            else{
            $("#name_error").html('');
            }
            }  
            });
        }
</script>