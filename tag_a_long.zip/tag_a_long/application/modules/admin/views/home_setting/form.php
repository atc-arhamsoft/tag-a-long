<div class="page-header">
    <h1>
        Payment Method
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
           Method
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <!-- PAGE CONTENT BEGINS -->
       <form class="form-horizontal" role="form" name="setting_form" id="setting_form" method="post" action="<?php echo base_url('admin/Home_Setting') ?>" accept-charset="utf-8" enctype="multipart/form-data" >
            <input type="hidden" id="id" name="id" value="<?php echo isset($row) ? $row['id'] : 1 ?>"/>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Heading:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="heading_1" name="heading_1" rows="3" cols="45" required> <?php echo $row['heading_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Heading:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="heading_2" name="heading_2" rows="3" cols="45" required> <?php echo $row['heading_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Heading:3 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="heading_3" name="heading_3" rows="3" cols="45" required> <?php echo $row['heading_3']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Headings (Discription) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="heading_discription" name="heading_discription" rows="3" cols="45" required> <?php echo $row['heading_discription']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:1 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_1_text_1" name="button_1_text_1" rows="3" cols="45" required> <?php echo $row['button_1_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:1 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_1_text_2" name="button_1_text_2" rows="3" cols="45" required> <?php echo $row['button_1_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:2 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_2_text_1" name="button_2_text_1" rows="3" cols="45" required> <?php echo $row['button_2_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:2 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_2_text_2" name="button_2_text_2" rows="3" cols="45" required> <?php echo $row['button_2_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:3 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_3_text_1" name="button_3_text_1" rows="3" cols="45" required> <?php echo $row['button_3_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:3 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_3_text_2" name="button_3_text_2" rows="3" cols="45" required> <?php echo $row['button_3_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:3 Text:3 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_3_text_3" name="button_3_text_3" rows="3" cols="45" required> <?php echo $row['button_3_text_3']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:4 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_4_text_1" name="button_4_text_1" rows="3" cols="45" required> <?php echo $row['button_4_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:4 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_4_text_2" name="button_4_text_2" rows="3" cols="45" required> <?php echo $row['button_4_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:5 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_5_text_1" name="button_5_text_1" rows="3" cols="45" required> <?php echo $row['button_5_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Button:5 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="button_5_text_2" name="button_5_text_2" rows="3" cols="45" required> <?php echo $row['button_5_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Title :1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_title_1" name="about_title_1" rows="3" cols="45" required> <?php echo $row['about_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Title :2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_title_2" name="about_title_2" rows="3" cols="45" required> <?php echo $row['about_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Title (Discription Line:1) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_discription_line_1" name="about_discription_line_1" rows="3" cols="45" required> <?php echo $row['about_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Title (Discription Line:2) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_discription_line_2" name="about_discription_line_2" rows="3" cols="45" required> <?php echo $row['about_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Sub Title : 1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_sub_title_1" name="about_sub_title_1" rows="3" cols="45" required> <?php echo $row['about_sub_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Sub Title : 2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_sub_title_2" name="about_sub_title_2" rows="3" cols="45" required> <?php echo $row['about_sub_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Sub Title (Discription :1 ) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_sub_title_discription_1" name="about_sub_title_discription_1" rows="3" cols="45" required> <?php echo $row['about_sub_title_discription_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">About Sub Title (Discription :2 ) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="about_sub_title_discription_2" name="about_sub_title_discription_2" rows="3" cols="45" required> <?php echo $row['about_sub_title_discription_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Beat Selection (Title) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="beat_selection_title" name="beat_selection_title" rows="3" cols="45" required> <?php echo $row['beat_selection_title']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Beat Selection (Discription) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="beat_selection_discription" name="beat_selection_discription" rows="3" cols="45" required> <?php echo $row['beat_selection_discription']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Tag Friends (Title) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="tag_friend_title" name="tag_friend_title" rows="3" cols="45" required> <?php echo $row['tag_friend_title']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Tag Friends (Discription) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="tag_friend_discription" name="tag_friend_discription" rows="3" cols="45" required> <?php echo $row['tag_friend_discription']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Bars Selection (Title) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="bars_selection_title" name="bars_selection_title" rows="3" cols="45" required> <?php echo $row['bars_selection_title']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Bars Selection (Discription) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="bars_selection_discription" name="bars_selection_discription" rows="3" cols="45" required> <?php echo $row['bars_selection_discription']; ?> </textarea>
                    </div>
               </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_title_1" name="feature_title_1" rows="3" cols="45" required> <?php echo $row['feature_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Title:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_title_2" name="feature_title_2" rows="3" cols="45" required> <?php echo $row['feature_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Features (Discription Line:1) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_discription_line_1" name="feature_discription_line_1" rows="3" cols="45" required> <?php echo $row['feature_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Features (Discription Line:2) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_discription_line_2" name="feature_discription_line_2" rows="3" cols="45" required> <?php echo $row['feature_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_title_1" name="feature_sub_title_1" rows="3" cols="45" required> <?php echo $row['feature_sub_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Discription:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_discription_1" name="feature_sub_discription_1" rows="3" cols="45" required> <?php echo $row['feature_sub_discription_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Title:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_title_2" name="feature_sub_title_2" rows="3" cols="45" required> <?php echo $row['feature_sub_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Discription:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_discription_2" name="feature_sub_discription_2" rows="3" cols="45" required> <?php echo $row['feature_sub_discription_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Title:3 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_title_3" name="feature_sub_title_3" rows="3" cols="45" required> <?php echo $row['feature_sub_title_3']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Discription:3 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_discription_3" name="feature_sub_discription_3" rows="3" cols="45" required> <?php echo $row['feature_sub_discription_3']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Title:4 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_title_4" name="feature_sub_title_4" rows="3" cols="45" required> <?php echo $row['feature_sub_title_4']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name">Feature Sub Discription:4 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_discription_4" name="feature_sub_discription_4" rows="3" cols="45" required> <?php echo $row['feature_sub_discription_4']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Title:5 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_title_5" name="feature_sub_title_5" rows="3" cols="45" required> <?php echo $row['feature_sub_title_5']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Feature Sub Discription:5 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="feature_sub_discription_5" name="feature_sub_discription_5" rows="3" cols="45" required> <?php echo $row['feature_sub_discription_5']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Title : 1</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_title_1" name="download_title_1" rows="3" cols="45" required> <?php echo $row['download_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Title : 2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_title_2" name="download_title_2" rows="3" cols="45" required> <?php echo $row['download_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download (Discription Line:1) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_discription_line_1" name="download_discription_line_1" rows="3" cols="45" required> <?php echo $row['download_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download (Discription Line:2) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_discription_line_2" name="download_discription_line_2" rows="3" cols="45" required> <?php echo $row['download_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Button:1 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_button_1_text_1" name="download_button_1_text_1" rows="3" cols="45" required> <?php echo $row['download_button_1_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Button:1 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_button_1_text_2" name="download_button_1_text_2" rows="3" cols="45" required> <?php echo $row['download_button_1_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Button:2 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_button_2_text_1" name="download_button_2_text_1" rows="3" cols="45" required> <?php echo $row['download_button_2_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download Button:2 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_button_2_text_2" name="download_button_2_text_2" rows="3" cols="45" required> <?php echo $row['download_button_2_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Review Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="review_title_1" name="review_title_1" rows="3" cols="45" required> <?php echo $row['review_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Review Title:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="review_title_2" name="review_title_2" rows="3" cols="45" required> <?php echo $row['review_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Review Discription Line:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="review_discription_line_1" name="review_discription_line_1" rows="3" cols="45" required> <?php echo $row['review_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Review Discription Line:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="review_discription_line_2" name="review_discription_line_2" rows="3" cols="45" required> <?php echo $row['review_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right"> ScreenShots Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="screenshot_title_1" name="screenshot_title_1" rows="3" cols="45" required> <?php echo $row['screenshot_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> ScreenShots Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="screenshot_title_2" name="screenshot_title_2" rows="3" cols="45" required> <?php echo $row['screenshot_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> ScreenShot Discription Line:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="screenshot_discription_line_1" name="screenshot_discription_line_1" rows="3" cols="45" required> <?php echo $row['screenshot_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> ScreenShot Discription Line:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="screenshot_discription_line_2" name="screenshot_discription_line_2" rows="3" cols="45" required> <?php echo $row['screenshot_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Contact Title:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="contact_title_1" name="contact_title_1" rows="3" cols="45" required> <?php echo $row['contact_title_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Contact Title:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="contact_title_2" name="contact_title_2" rows="3" cols="45" required> <?php echo $row['contact_title_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Contact (Discription Line:1) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="contact_discription_line_1" name="contact_discription_line_1" rows="3" cols="45" required> <?php echo $row['contact_discription_line_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Contact (Discription Line:2) </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="contact_discription_line_2" name="contact_discription_line_2" rows="3" cols="45" required> <?php echo $row['contact_discription_line_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Email Us Title </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="email_us_title" name="email_us_title" rows="3" cols="45" required> <?php echo $row['email_us_title']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Contant Info Title </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="contact_info_title" name="contact_info_title" rows="3" cols="45" required> <?php echo $row['contact_info_title']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download App Title </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_app_title" name="download_app_title" rows="3" cols="45" required> <?php echo $row['download_app_title']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download App Button:1 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_app_button_1_text_1" name="download_app_button_1_text_1" rows="3" cols="45" required> <?php echo $row['download_app_button_1_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download App Button:1 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_app_button_1_text_2" name="download_app_button_1_text_2" rows="3" cols="45" required> <?php echo $row['download_app_button_1_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download App Button:2 Text:1 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_app_button_2_text_1" name="download_app_button_2_text_1" rows="3" cols="45" required> <?php echo $row['download_app_button_2_text_1']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Download App Button:2 Text:2 </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="download_app_button_2_text_2" name="download_app_button_2_text_2" rows="3" cols="45" required> <?php echo $row['download_app_button_2_text_2']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Subcribe Email Title </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="subcribe_email_title" name="subcribe_email_title" rows="3" cols="45" required> <?php echo $row['subcribe_email_title']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Subcribe Email Discription </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="subcribe_email_discription" name="subcribe_email_discription" rows="3" cols="45" required> <?php echo $row['subcribe_email_discription']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

              <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Copyright </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="copyright" name="copyright" rows="3" cols="45" required> <?php echo $row['copyright']; ?> </textarea>
                    </div>
               </div>
            </div>
            
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Site Name </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea id="sitename" name="sitename" rows="3" cols="45" required> <?php echo $row['sitename']; ?> </textarea>
                    </div>
               </div>
            </div>

            <div class="space-2"></div>

            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Submit
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#setting_form');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                       Reset
                    </button>
                </div>
            </div>

        </form>



        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->
</div><!-- /.row -->


<script>
    $(function () {
        $('#setting_form').validate({
            errorElement: 'div',
            errorClass: 'help-block',
            focusInvalid: true,
            highlight: function (e) {
                $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
            },
            success: function (e) {
                $(e).closest('.form-group').removeClass('has-error');
                $(e).remove();
            },
            errorPlacement: function (error, element) {
                if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                    var controls = element.closest('div[class*="col-"]');
                    if (controls.find(':checkbox,:radio').length > 1)
                        controls.append(error);
                    else
                        error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                }
                else if (element.is('.select2')) {
                    error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                }
                else if (element.is('.chosen-select')) {
                    error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                }
                else
                    error.insertAfter(element.parent());
            },
            invalidHandler: function (form) {
            }
        });
    });
</script>