<div class="page-header">
    <h1>
        Newsletter Emails
    </h1>
</div><!-- /.page-header -->

<div class="breadcrumbs" id="breadcrumbs">
    <script type="text/javascript">
        try {
            ace.settings.check('breadcrumbs', 'fixed')
        } catch (e) {
        }
    </script>

    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="<?php echo base_url('admin/dashboard') ?>">Home</a>
        </li>

        <li>
            <a href="<?php echo base_url('admin/pages') ?>">Newsletters</a>
        </li>
        <li class="active">Add Email</li>
    </ul><!-- /.breadcrumb -->


</div>


<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->
        <?php
        $display = '';
        if ($row['is_main_page'] == 1) {
            $display = 'display:none';
        }
        ?>

        <form id="formEmail" action="<?php echo base_url('admin/newsletter/addIntoDb')?>" class="form-horizontal" role="form" method="post" accept-charset="utf-8">
                    <div class="form-group">
                        <label class="control-label col-xs-12 col-sm-3 no-padding-right">Email *</label>
                        <div class="col-xs-12 col-sm-9">
                            <div class="clearfix">
                            <input  type="email" class="col-xs-12 col-sm-5" id="pageTitle" name="email"  placeholder="Welcome Message" value="<?php echo $email;?>" required >
                        </div></div>
                    </div>
         <div class="space-2"></div>

            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Send Newsletter
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#formEmail');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                        Reset
                    </button>
                </div>
            </div>
        </form>