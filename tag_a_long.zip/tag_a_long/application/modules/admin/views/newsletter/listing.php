<div class="page-header">
    <h1>
        Newsletter
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Manage Newsletter
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
       
        <div class="col-sm-8"></div>
        <!-- <div class="col-sm-4">
            <a href="<?php //echo base_url('admin/newsletter/addNewsLetter') ?>"><button type="button" class="btn btn-primary"   style="float: right; margin-right: 15px;">Send Newsletter</button></a>
        </div> -->
 
    </div>
</div>

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="alert" id="formErrorMsg" style="display: none;">
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">


                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                     </thead>
                            <?php 
                            foreach ($result as $value) { 
                                if ($value['is_active'] == 1) {
                                $status = '<span class="label label-sm label-info status_label' . $value['id'] . '">Active</span>';
                                } else {
                                  $status = '<span class="label label-sm label-danger status_label' . $value['id'] . '">Inactive</span>';
                                }
                                ?>
                                <tbody>
                                <td><?php echo $value['email'];?></td>
                                <td><?php echo $status; ?></td> 
                                <td>
                                    <?php
                                    if ($value['is_active'] == 1) {
                                        echo '<a title="Status" href="javascript:void(0);" class="blue status_button' . $value['id'] . '" onclick=updateStatus("newsletter",' . $value['id'] . ',1)><i class="ace-icon fa fa-play bigger-130"></i></a>';
                                    } else {
                                        echo '<a title="Status" href="javascript:void(0);" class="red status_button' . $value['id'] . '" onclick=updateStatus("newsletter",' . $value['id'] . ',0)><i class="ace-icon fa fa-stop bigger-130"></i></a>';
                                    }
                                    ?>
                                    <a href="<?php echo base_url('admin/newsletter/deleteEmail/' . encode($value['id'])) ?>" onclick="return delete_confirm();" class="tooltip-error" data-rel="tooltip" title="Delete">
                                        <span class="red">
                                            <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                        </span>
                                    </a> 
                                </td>
                                </tbody>
                            <?php 
                            }
                            ?>
                     </table>
                    </div>
</div>

<!-- page specific plugin scripts -->

        <script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/admin/js/jquery.dataTables.bootstrap.min.js') ?>"></script>
<script>
jQuery(function(){
                    $('#dynamic-table').dataTable({
                            bAutoWidth: false,
                            "aoColumns": [
                                {"bSortable": true},
                                null, null,
                                {"bSortable": false}
                            ],
                            "aaSorting": []

                        });


});
</script>