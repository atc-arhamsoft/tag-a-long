<div class="page-header">
    <h1>
        Payment Method
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
           Method
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <!-- PAGE CONTENT BEGINS -->
       <form class="form-horizontal" role="form" name="setting_form" id="setting_form" method="post" action="<?php echo base_url('admin/Payment_method/saveData') ?>" accept-charset="utf-8" enctype="multipart/form-data" >
            <input type="hidden" id="id" name="id" value="<?php echo isset($row) ? $row->id : 1 ?>"/>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Braintree Merchant Id </label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text"  name="braintree_merchant_id" id="braintree_merchant_id" value="<?php echo $row->braintree_merchant_id; ?>" placeholder="braintree_merchant_id" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_title">Braintree Public Key </label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text"  id="braintree_public_key" name="braintree_public_key" value="<?php echo $row->braintree_public_key; ?>" placeholder="braintree_public_key" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_email">Braintree Private Key</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" id="braintree_private_key" name="braintree_private_key" value="<?php echo $row->braintree_private_key; ?>" placeholder="braintree_private_key" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Method</label>
                <div class="col-xs-12 col-sm-9">
                    <div>
                        <label class="blue">
                            <input type="radio" id="status" class="ace" <?php echo ( isset($row) && $row->braintree_environment == 0) ? 'checked' : '' ?> value="0" name="braintree_environment" required>
                            <span class="lbl">&nbsp;SandBox</span>
                        </label>
                    </div>
                    <div>
                        <label class="blue">
                            <input type="radio" class="ace" <?php echo ( isset($row) && $row->braintree_environment == 1) ? 'checked' : '' ?> id="status" value="1" name="braintree_environment" required>
                            <span class="lbl">&nbsp;Live</span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>			
            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Submit
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#setting_form');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                       Reset
                    </button>
                </div>
            </div>

        </form>



        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->
</div><!-- /.row -->


<script>
    $(function () {
        $('#setting_form').validate({
            errorElement: 'div',
            errorClass: 'help-block',
            focusInvalid: true,
            highlight: function (e) {
                $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
            },
            success: function (e) {
                $(e).closest('.form-group').removeClass('has-error');
                $(e).remove();
            },
            errorPlacement: function (error, element) {
                if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                    var controls = element.closest('div[class*="col-"]');
                    if (controls.find(':checkbox,:radio').length > 1)
                        controls.append(error);
                    else
                        error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                }
                else if (element.is('.select2')) {
                    error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                }
                else if (element.is('.chosen-select')) {
                    error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                }
                else
                    error.insertAfter(element.parent());
            },
            invalidHandler: function (form) {
            }
        });
    });
</script>