
<div class="page-header">
    <h1>
        Payment History
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Premium Plan History
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
        <?php
        if (rights(7) == true) {
            ?>
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <!-- <a href="<?php echo base_url('admin/Premium_plan/add') ?>"><button type="button" class="btn btn-primary"   style="float: right; margin-right: 15px;">Add New</button></a> -->
            </div>
        <?php } ?>
    </div>
</div>

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="alert" id="formErrorMsg" style="display: none;">
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Users</th>
                    <th>Premium Plan name</th> 
                    <th>Price</th> 
                    <th>Months</th>
                    <th>Date</th>
                    <th>Expiry Data</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach ($result->result() as $row) 
            {   
            ?>
            <tr>
                <td><?php echo $row->user_name?></td>
                <td><?php echo $row->premiumplan_name?></td>
                <td><?php echo $row->price?></td> 
                <td><?php echo $row->months?></td> 
                <td>
                <?php 
                 echo $row->created_date;
                ?>
                </td>   
                <td>
                <?php
                $months = $row->months;
                $Currentdate = $row->created_date;
                $expirydate = date('d/m/Y',strtotime('+'.$months.'months',strtotime($Currentdate)));
                echo $expirydate;
                ?>  
                </td>  
            </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- page specific plugin scripts -->

<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.bootstrap.min.js') ?>"></script>
<script>
    jQuery(function () {
        $('#dynamic-table').dataTable({
            bAutoWidth: false,
            "aoColumns": [
                {"bSortable": true},
                {"bSortable": false},
                {"bSortable": true},
                {"bSortable": true},
                {"bSortable": true},
                null,
                {"bSortable": true},
                null
            ],
            "aaSorting": []

        });
        function newf(){

        }

    });
    
</script>