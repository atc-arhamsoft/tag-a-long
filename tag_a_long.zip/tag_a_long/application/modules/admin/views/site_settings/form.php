<div class="page-header">
    <h1>
        Site Settings
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Main site settings
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <!-- PAGE CONTENT BEGINS -->
       <form class="form-horizontal" role="form" name="setting_form" id="setting_form" method="post" action="<?php echo base_url('admin/site_settings') ?>" accept-charset="utf-8" enctype="multipart/form-data" >
            <input type="hidden" id="id" name="id" value="<?php echo isset($row) ? $row['id'] : 1 ?>"/>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_name"> Site Name * </label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text"  name="site_name" id="site_name" value="<?php echo $row['site_name']; ?>" placeholder=" Site Name" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_title">Site Title * </label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text"  id="site_title" name="site_title" value="<?php echo $row['site_title']; ?>" placeholder="Site Title " class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_keywords">Site Keywords * </label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">

                        <textarea  class="col-xs-12 col-sm-5 limited" id="site_keywords" name="site_keywords"  style="height: 150px;" maxlength="1000" required><?php echo $row['site_keywords']; ?></textarea>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_description"> Site Description * </label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea  class="col-xs-12 col-sm-5 limited" id="site_description" name="site_description" style="height: 75px;"  maxlength="1000" required><?php echo $row['site_description']; ?></textarea>
                    </div>
                </div>
            </div>

            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_email">Site Email *</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="email" id="site_email" name="site_email" value="<?php echo $row['site_email']; ?>" placeholder="Site Email " class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_phone"> Site Contact No  *</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" id="site_phone" name="site_phone" value="<?php echo $row['site_phone']; ?>" placeholder="Site Contact No" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="admin_address">Address *</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea  class="col-xs-12 col-sm-5" id="address" name="address" style="height: 75px;" required><?php echo $row['address']; ?></textarea></div>
                </div>
            </div>

            <div class="space-2"></div>			

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="admin_email"> Admin Email *</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="email" id="admin_email" name="admin_email" value="<?php echo $row['admin_email']; ?>" placeholder=" Admin Email" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="admin_phone"> Admin Contact No *</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" id="admin_phone" name="admin_phone" value="<?php echo $row['admin_phone']; ?>" placeholder=" Admin Contact no" class="col-xs-12 col-sm-5" required/></div>
                </div>
            </div>
              <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="storage_type">Free Storage Type*</label>
                <div class="col-xs-12 col-sm-9">
                    <select id="storage_type" name="storage_type" class="col-xs-12 col-sm-5" required="">
                        <option value="">Select Type</option>
                        <option value="MB" <?php if($row['storage_type']=="MB") echo "selected=selected"?>>MB</option>
                        <option value="GB" <?php if($row['storage_type']=="GB") echo "selected=selected"?>>GB</option>
                        <option value="TB" <?php if($row['storage_type']=="TB") echo "selected=selected"?>>TB</option>
                                
                    </select>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="free_space"> Free Space*</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="number" id="free_space" name="free_space" value="<?php echo $row['free_space']; ?>" class="col-xs-12 col-sm-5" required=""/></div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="twitter_url"> Twitter</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="twitter_url" name="twitter_url" value="<?php echo $row['twitter_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>

            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="linkedin_url"> Linkedin</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="linkedin_url" name="linkedin_url" value="<?php echo $row['linkedin_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>

            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="instagram_url"> Pinterest</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="pinterest_url" name="pinterest_url" value="<?php echo $row['pinterest_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>

            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="google_plus_url"> Google Plus</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="google_plus_url" name="google_plus_url" value="<?php echo $row['google_plus_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="google_plus_url"> Facebook</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="facebook_url" name="facebook_url" value="<?php echo $row['facebook_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="google_plus_url"> YouTube</label>

                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="url" id="youtube_url" name="youtube_url" value="<?php echo $row['youtube_url']; ?>" class="col-xs-12 col-sm-5"/></div>
                </div>
            </div>
            
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="site_logo">Site Logo *</label>

                <div  class="col-xs-10 col-sm-4">
                    <input type="file" id="site_logo" name="site_logo">
                    <div class="space-2"></div>
                    <input type="hidden" name="old_site_logo"  id="old_site_logo" value="<?php echo $row['site_logo']; ?>">
                    <?php
                    if (isset($row)) {
                        if ($row['site_logo'] == '') {
                            $row['site_logo'] = 'abc.png';
                        }
                        echo '<img src="' . $this->common->check_image(base_url("uploads/site/pic/" . $row['site_logo']), 'no_image.jpg') . '" width="70"/>';
                    }
                    ?>


                </div>
            </div>
            <div class="space-2"></div>


            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="Favicon"> Site Favicon *</label>

                <div  class="col-xs-10 col-sm-4">
                    <input type="file" id="favicon" name="favicon">
                    <div class="space-2"></div>
                    <input type="hidden" name="old_favicon"  id="old_favicon" value="<?php echo $row['favicon']; ?>">
                    <?php
                    if (isset($row)) 
                    {
                        if ($row['favicon'] == '') {
                            $row['favicon'] = 'abc.png';
                        }
                        echo '<img src="' . $this->common->check_image(base_url("uploads/site/pic/" . $row['favicon']), 'no_image.jpg') . '" width="50" />';
                    }
                    ?>

                </div>
            </div>
            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Submit
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#setting_form');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                       Reset
                    </button>
                </div>
            </div>

        </form>



        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->
</div><!-- /.row -->


<script>
    $(function () {
        $('#setting_form').validate({
            errorElement: 'div',
            errorClass: 'help-block',
            focusInvalid: true,
            highlight: function (e) {
                $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
            },
            success: function (e) {
                $(e).closest('.form-group').removeClass('has-error');
                $(e).remove();
            },
            errorPlacement: function (error, element) {
                if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                    var controls = element.closest('div[class*="col-"]');
                    if (controls.find(':checkbox,:radio').length > 1)
                        controls.append(error);
                    else
                        error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                }
                else if (element.is('.select2')) {
                    error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                }
                else if (element.is('.chosen-select')) {
                    error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                }
                else
                    error.insertAfter(element.parent());
            },
            invalidHandler: function (form) {
            }
        });
    });
</script>