
<div class="page-header">
    <h1>
        Payment History
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Token Plan History
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
        <?php
        if (rights(7) == true) {
            ?>
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <!-- <a href="<?php echo base_url('admin/Premium_plan/add') ?>"><button type="button" class="btn btn-primary"   style="float: right; margin-right: 15px;">Add New</button></a> -->
            </div>
        <?php } ?>
    </div>
</div>

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="alert" id="formErrorMsg" style="display: none;">
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Users</th>
                    <th>Token Plan name</th> 
                    <th>Price</th> 
                    <th>Tokens</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach ($result->result() as $row) 
            {
            ?>
            <tr>
                <td><?php echo $row->user_name?></td>
                <td><?php echo $row->tokenplan_name?></td>
                <td><?php echo $row->price?></td> 
                <td><?php echo $row->token?></td>
            </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- page specific plugin scripts -->

<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.bootstrap.min.js') ?>"></script>
<script>
    jQuery(function () {
        $('#dynamic-table').dataTable({
            bAutoWidth: false,
            "aoColumns": [
                {"bSortable": true},
                null,
                {"bSortable": false},
                {"bSortable": true},
                null,
                {"bSortable": true},
                null
            ],
            "aaSorting": []

        });


    });
</script>