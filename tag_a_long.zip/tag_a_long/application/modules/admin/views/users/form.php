<div class="page-header">
    <h1>
        Users

    </h1>
</div><!-- /.page-header -->

<div class="breadcrumbs" id="breadcrumbs">
    <script type="text/javascript">
        try {
            ace.settings.check('breadcrumbs', 'fixed')
        } catch (e) {
        }
    </script>

    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="<?php echo base_url('admin/dashboard') ?>">Home</a>
        </li>

        <li>
            <a href="<?php echo base_url('admin/users') ?>">Users</a>
        </li>
        <li class="active">Add users</li>
    </ul><!-- /.breadcrumb -->


</div>


<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="space-8"></div>
        <div class="space-8"></div>
        <form id="users_form" name="users_form" action="<?php echo base_url('admin/users/add') ?>" class="form-horizontal" role="form" method="post"  accept-charset="utf-8" enctype="multipart/form-data">

            <input type="hidden" name="action" id="action" value="<?php echo $action; ?>">

            <input type="hidden"  id="user_id" name="user_id" value="<?php echo $row['user_id']; ?>"  >
           
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">First Name *</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" class="col-xs-12 col-sm-5" id="first_name" name="first_name"  placeholder="First Name" value="<?php echo $row['first_name']; ?>" required>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Last Name *</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <input type="text" class="col-xs-12 col-sm-5" id="last_name" name="last_name" placeholder="Last Name" value="<?php echo $row['last_name'] ?>" required />
                    </div></div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Email *</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">

                        <input type="email" class="col-xs-12 col-sm-5 ckeditor" id="email" name="email" value="<?php echo $row['email'] ?>"  placeholder="Email"  onchange="checkEmail();" required/>
                        <label class="help-block" id="emailExist_error" style="display: none;"></label>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Password <?php echo (!isset($row)) ? '*' : '' ?></label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">

                        <input type="password" class="col-xs-12 col-sm-5 ckeditor" id="password" name="password" onblur="validate_password()" placeholder="Password" <?php echo (!isset($row)) ? 'required' : '' ?>/>
                        <!-- <label class="help-block" id="validate_password_error" style="display: none;"></label> -->
                    </div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Username</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">

                        <input type="text" class="col-xs-12 col-sm-5 ckeditor"  value="<?php echo $row['username'] ?>" id="username" name="username" onblur="validate_username()" onchange="checkusernames()" placeholder="Username" <?php echo (!isset($row)) ? 'required' : '' ?>/>
                        <label class="help-block" id="validate_username_error" style="display: none;"></label>
                        <span style="color:#d16e6c" id="user_error"></span>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Address</label>
                <div class="col-xs-12 col-sm-9">
                    <div class="clearfix">
                        <textarea class="col-xs-12 col-sm-5 ckeditor"  placeholder="Address" name="address" class="form-control"><?php echo $row['address']; ?> </textarea>

                    </div>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Country</label>
                <div class="col-xs-12 col-sm-9" >
                    <select class="col-xs-12 col-sm-5" id="country_id" name="country_id" class="form-control" onchange="country_city_auto_change();">
                        <option value="">Select Country</option>
                        <?php
                            foreach ($countries as $country) {
                                $sel='';
                                if( $row['country_id'] ==  $country['id']){
                                    $sel = 'selected';
                                }
                                ?>
                                <option value="<?php echo $country['id'] ?>" <?php echo $sel ?> ><?php echo $country['name'] ?></option>
                                <?php
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">City</label>
                <div class="col-xs-12 col-sm-9 col-md-9">
                <select class="col-xs-12 col-sm-5" id="city_id" name="city_id" class="form-control">
                <?php
                foreach ($cities as $city) {
                 $sel='';
                 if( $row['city_id'] ==  $city['id']){
                 $sel = 'selected';
                 }
                ?>
                <option value="<?php echo $city['id'] ?>" <?php echo $sel ?> ><?php echo $city['name'] ?></option>
                <?php
                }
                ?>       
                </select>
                </div>
            </div>
            <div class="space-2"></div>
            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Contact No</label>
                <div class="col-xs-12 col-sm-9 col-md-9">
                    <input class="col-xs-12 col-sm-5 ckeditor" type="text" placeholder="Enter Contact no" value="<?php echo $row['phone_no']; ?>" name="phone_no" class="form-control">
                </div>
            </div>
           
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right">Status *</label>
                <div class="col-xs-12 col-sm-9">
                    <div>
                        <label class="blue">
                            <input type="radio" id="status" class="ace" <?php echo ( isset($row) && $row['is_active'] == 1) ? 'checked' : '' ?> value="1" name="is_active" required>
                            <span class="lbl">&nbsp;Active</span>
                        </label>
                    </div>
                    <div>
                        <label class="blue">
                            <input type="radio" class="ace" <?php echo ( isset($row) && $row['is_active'] == 0) ? 'checked' : '' ?> id="status" value="0" name="is_active" required>
                            <span class="lbl">&nbsp;Inactive</span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="space-2"></div>

            <div class="form-group">
                <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="photo">Profile Image</label>

                <div  class="col-xs-10 col-sm-4">
                    <input class="col-xs-12 col-sm-5 ckeditor" type="file" id="photo" name="profile_image">
                    <div class="space-2"></div>
                    <input type="hidden" name="old_profile_image"  id="old_photo" value="<?php echo $row['profile_image']; ?>">
                    <?php
                    if (isset($row)) {
                        if ($row['profile_image'] == '') {
                            $row['profile_image'] = 'abc.png';
                        }
                        echo '<img src="' . $this->common->check_image(base_url("uploads/admin_users/small/" . $row['profile_image']), 'no_image.jpg') . '" width="50" height="50" />';
                    }
                    ?>


                </div>
            </div>
            <div class="space-2"></div>

            <div class="space-2"></div>
            <div class="clearfix form-actions">
                <div class="col-md-offset-3 col-md-9">
                    <button class="btn btn-info" type="submit">
                        <i class="ace-icon fa fa-check bigger-110"></i>
                        Submit
                    </button>

                    &nbsp; &nbsp; &nbsp;
                    <button class="btn" type="reset" onclick="clear_form_elements('#users_form');">
                        <i class="ace-icon fa fa-undo bigger-110"></i>
                        Reset
                    </button>
                </div>
            </div>

        </form>

    </div>
</div>

<script>
        function checkusernames()
        {       
            var url = '<?php echo base_url("admin/users/checkUsername");?>';
            var username=$('#username').val();
            $.ajax({
            type:'post',
            url:url,
            data:{username:username},
            success:function(data){
            console.log(data);
            if(data==1)
            { 
            $("#user_error").html('This User Already Exist');
            $('#username').val("");
            }
            else{
            $("#user_error").html('');
            }
            }  
            });
        }
        function country_city_auto_change(){
            var url = '<?php echo base_url("admin/users/fetch_city");?>';
            var country_id = $('#country_id').val();
            if(country_id != '')
            {
            $.ajax({
            url:url,
            method:"POST",
            data:{country_id:country_id},
            success:function(data)
            {
            $('#city_id').html(data);
            document.getElementById('city_id').disabled = false;
            }
            });
            }
            else
            {
            $('#city_id').html('<option value="">Select City</option>');
            document.getElementById('city_id').disabled = true;
            }
        }
</script>