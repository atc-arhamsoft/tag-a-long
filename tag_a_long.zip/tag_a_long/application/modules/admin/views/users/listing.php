
<div class="page-header">
    <h1>
        Users
        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            Manage Users
        </small>
    </h1>
</div><!-- /.page-header -->

<div class="row">
    <div class="col-xs-12">
        <?php
        if (rights(2) == true) {
            ?>
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <!-- <a href="<?php //echo base_url('admin/users/add') ?>"><button type="button" class="btn btn-primary"   style="float: right; margin-right: 15px;">Add New</button></a> -->
            </div>
        <?php } ?>
    </div>
    <div class="col-xs-12">
        <form action="<?php echo base_url('admin/users/'); ?>" method="get">
        <div class="row">
            <div class="col-xs-12">
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <label for="select-widget">Select Plans</label>  
                        <div class="select-holder">
                            <select name="filter" class="form-control" id="filter">
                                <?php 
                                   $selected = 'selected';
                                ?>
                                <option value=''>All Users</option>
                                <option value='0' <?php if($search_query==0 && $search_query!=''){echo $selected;}?>>Free</option>
                                <option value='1' <?php if($search_query==1 && $search_query!=''){echo $selected;}?>>Premium</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12">
                        <button type="submit" class="btn btn-primary btn-square" style="margin-top: 20px;" id='btn_search'>
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>    
            </div>
            </form>
        </div>
    
    <br>
    </div>
</div>

<div class="row">
    <div class="col-xs-12">

        <?php
        if ($this->session->flashdata('success_message')) {
            echo '<div class="alert alert-success alertMessage">' . $this->session->flashdata('success_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- Notification -->
        <?php
        if ($this->session->flashdata('error_message')) {
            echo '<div class="alert alert-danger">' . $this->session->flashdata('error_message') . '</div>';
        };
        ?>
        <div class="clearfix"></div>
        <!-- /Notification -->

        <div class="alert" id="formErrorMsg" style="display: none;">
        </div>

        <table id="dynamic-table" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th class="hidden-480">Email</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
                if ($result->num_rows() > 0) {
                    foreach ($result->result() as $row) {
                        if ($row->is_active == 1) {
                            $status = '<span class="label label-sm label-info status_label' . $row->user_id . '">Active</span>';
                        } else {
                            $status = '<span class="label label-sm label-danger status_label' . $row->user_id . '">Inactive</span>';
                        }
                        ?>
                        <tr id="users_<?php echo $row->user_id; ?>">
                            <td><?php echo $row->username; ?></td>
                            <td  class="hidden-480"><?php echo $row->email ?></td>
                            <td><?php echo $status; ?></td>
                            <td>

                                    <?php
                                    if ($row->is_active == 1) {
                                        echo '<a title="Status" href="javascript:void(0);" class="blue status_button' . $row->user_id . '" onclick=updateStatus("users",' . $row->user_id . ',1)><i class="ace-icon fa fa-play bigger-130"></i></a>';
                                    } else {
                                        echo '<a title="Status" href="javascript:void(0);" class="red status_button' . $row->user_id . '" onclick=updateStatus("users",' . $row->user_id . ',0)><i class="ace-icon fa fa-stop bigger-130"></i></a>';
                                    }
                                    ?>
                                    <!-- <a title="Edit" class="green" href="<?php echo base_url('admin/users/edit/' . encode($row->user_id).'/'. encode($row->country_id)); ?>">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                    </a> -->
                                    <?php
                                    if (rights(4) == true) {
                                    ?>
                                    <a title="Delete" onclick="return delete_confirm();" class="red" href="<?php echo base_url('admin/users/delete/' . encode($row->user_id)) ?>">
                                            <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                    </a>
                                    <?php } ?>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>

                <?php }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- page specific plugin scripts -->

<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.bootstrap.min.js') ?>"></script>
<script>
    jQuery(function () {
        $('#dynamic-table').dataTable({
            bAutoWidth: false,
            "aoColumns": [
                {"bSortable": true},
                null, null, null,
                {"bSortable": false}
            ],
            "aaSorting": []

        });

        
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
     
    });
</script>