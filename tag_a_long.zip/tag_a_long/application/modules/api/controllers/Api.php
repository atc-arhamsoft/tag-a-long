<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Api extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $X_API_KEY = $this->common->getHeaders('Tag-a-long-Api-Key');
        $this->secret_key = $X_API_KEY; //'zRyxpCaGosehZTcNHlQfDPnAWmdBrjKFJkXIMLti-IBLyZsiG'

        $this->common->chechSecurity();

        $this->load->model('api_model');
        $this->load->library('emailutility');
    }

    /**
     * Method: Test
     * params: Posted Data $post
     * Return: Json
     */
    function upAndRunning() {
        $data = array();
        $data['status'] = 1;
        $data['message'] = "We are up and running";

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    /**
     * Method: login
     * params: Posted Data $post
     * Return: Json
     */
    function login() {

        $post_data = array();
        $data = array();
        $user_data = array();
        if ($_POST['email'] <> '' && $_POST['password'] <> '') {
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);
            $response = $this->api_model->ajaxLogin($email, $password);

            if ($response <> 0 && $response <> -1) {

                $data = $this->api_model->get_user_data($response);

                if ($data['is_verified'] == 0) {
                    $send_data['status'] = 1;
                    $send_data['user_id'] = $data['user_id'];
                    $send_data['is_verified'] = 0;
                    $send_data['message'] = 'Your email address is not verified. Kindly verify your email.';
                    $this->makeLog($data['user_id'], "User login failed", NULL, NULL, "User login failed, email address not verified");
                    header('Content-Type: application/json');
                    echo json_encode($send_data, JSON_NUMERIC_CHECK);
                    exit;
                }
                $post_data['last_sign_in'] = date('Y-m-d H:i:s');
                $post_data['is_signed_in'] = '1';
                $results = $this->api_model->update('users', $post_data, array('user_id' => $data['user_id']));
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['fb_url'] = $data['fb_url'];
                $data['tw_url'] = $data['tw_url'];
                $data['soundcloud_url'] = $data['soundcloud_url'];
                $data['web_url'] = $data['web_url'];
                $data['cover_photo'] = $data['cover_photo'];
                $data['is_verified'] = $data['is_verified'];
                $data['following_count'] = getCount('following_user_id', 'following_count', 'follower', 'follower_user_id', $data['user_id']);
                $data['followers_count'] = getCount('following_user_id', 'followers_count', 'follower', 'following_user_id', $data['user_id']);
                $data['posts_count'] = getCount('post_id', 'posts_count', 'posts', 'user_id', $data['user_id']);
                $user_data = getValArray('secret_key,is_premium,token', 'users', 'user_id', $data['user_id']);
                $data['secret_key '] = $user_data['secret_key'];
                $data['tokens_count'] = (int) $user_data['token'];
                $data['is_premium'] = $user_data['is_premium'];
                $data['username '] = getVal('username', 'users', 'user_id', $data['user_id']);
                $data['status'] = 1;

                $this->makeLog($data['user_id'], "User logged in", NULL, NULL, "User logged in using email address");
            } else if ($response == -1) {
                $data['status'] = 0;
                $data['error'] = 205;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['error'] = 205;
                $data['message'] = 'The email or password you entered is incorrect. Please try again.';
            }
        } else if ($_POST['user_fbId'] <> '' && $_POST['user_fbId'] <> 0) {

            $verify = $this->api_model->verify_user('user_fbId', $_POST['user_fbId']);

            if ($verify == 1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'You have not created an account, Please create account first.';
            } else {
                $insert_id = getVal('user_id', 'users', 'user_fbId', $_POST['user_fbId']);

                $data = $this->api_model->get_user_data($insert_id);


                $post_data['last_sign_in'] = date('Y-m-d H:i:s');
                $post_data['is_signed_in'] = '1';
                $results = $this->api_model->update('users', $post_data, array('user_id' => $data['user_id']));

                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['fb_url'] = $data['fb_url'];
                $data['tw_url'] = $data['tw_url'];
                $data['soundcloud_url'] = $data['soundcloud_url'];
                $data['web_url'] = $data['web_url'];
                $data['cover_photo'] = $data['cover_photo'];
                $data['is_verified'] = $data['is_verified'];
                $data['following_count'] = getCount('following_user_id', 'following_count', 'follower', 'follower_user_id', $data['user_id']);
                $data['followers_count'] = getCount('following_user_id', 'followers_count', 'follower', 'following_user_id', $data['user_id']);
                $data['posts_count'] = getCount('post_id', 'posts_count', 'posts', 'user_id', $data['user_id']);
                $user_data = getValArray('secret_key,is_premium,token', 'users', 'user_id', $data['user_id']);
                $data['secret_key '] = $user_data['secret_key'];
                $data['tokens_count'] = $user_data['token'];
                $data['is_premium'] = $user_data['is_premium'];
                $data['username '] = getVal('username', 'users', 'user_id', $data['user_id']);
                $data['status'] = 1;

                $this->makeLog($insert_id, "User logged in", NULL, NULL, "User logged in using FB");
            }
        } else if ($_POST['user_twid'] <> '' && $_POST['user_twid'] <> 0) {
            $verify = $this->api_model->verify_user('user_twid', $_POST['user_twid']);
            if ($verify == 1) {
                $data['status'] = 0;
                $data['error'] = 203;
                $data['message'] = 'You have not created an account, Please create account first.';
            } else {
                $insert_id = getVal('user_id', 'users', 'user_twid', $_POST['user_twid']);
                $data = $this->api_model->get_user_data($insert_id);
                $post_data['last_sign_in'] = date('Y-m-d H:i:s');
                $post_data['is_signed_in'] = '1';
                $results = $this->api_model->update('users', $post_data, array('user_id' => $data['user_id']));
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['fb_url'] = $data['fb_url'];
                $data['tw_url'] = $data['tw_url'];
                $data['soundcloud_url'] = $data['soundcloud_url'];
                $data['web_url'] = $data['web_url'];
                $data['cover_photo'] = $data['cover_photo'];
                $data['is_verified'] = $data['is_verified'];
                $data['following_count'] = getCount('following_user_id', 'following_count', 'follower', 'follower_user_id', $data['user_id']);
                $data['followers_count'] = getCount('following_user_id', 'followers_count', 'follower', 'following_user_id', $data['user_id']);
                $data['posts_count'] = getCount('post_id', 'posts_count', 'posts', 'user_id', $data['user_id']);
                $user_data = getValArray('secret_key,is_premium,token', 'users', 'user_id', $data['user_id']);
                $data['secret_key '] = $user_data['secret_key'];
                $data['tokens_count'] = $user_data['token'];
                $data['is_premium'] = $user_data['is_premium'];
                $data['username '] = getVal('username', 'users', 'user_id', $data['user_id']);
                $data['status'] = 1;
                $this->makeLog($insert_id, "User logged in", NULL, NULL, "User logged in using twitter");
            }
        } else if ($_POST['user_inid'] <> '' && $_POST['user_inid'] <> 0) {
            $verify = $this->api_model->verify_user('user_inid', $_POST['user_inid']);
            if ($verify == 1) {
                $data['status'] = 0;
                $data['error'] = 202;
                $data['message'] = 'You have not created an account, Please create account first.';
            } else {
                $insert_id = getVal('user_id', 'users', 'user_inid', $_POST['user_inid']);
                $data = $this->api_model->get_user_data($insert_id);
                $post_data['last_sign_in'] = date('Y-m-d H:i:s');
                $post_data['is_signed_in'] = '1';
                $results = $this->api_model->update('users', $post_data, array('user_id' => $data['user_id']));
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['fb_url'] = $data['fb_url'];
                $data['tw_url'] = $data['tw_url'];
                $data['soundcloud_url'] = $data['soundcloud_url'];
                $data['web_url'] = $data['web_url'];
                $data['cover_photo'] = $data['cover_photo'];
                $data['is_verified'] = $data['is_verified'];
                $data['following_count'] = getCount('following_user_id', 'following_count', 'follower', 'follower_user_id', $data['user_id']);
                $data['followers_count'] = getCount('following_user_id', 'followers_count', 'follower', 'following_user_id', $data['user_id']);
                $data['posts_count'] = getCount('post_id', 'posts_count', 'posts', 'user_id', $data['user_id']);
                $user_data = getValArray('secret_key,is_premium,token', 'users', 'user_id', $data['user_id']);
                $data['secret_key '] = $user_data['secret_key'];
                $data['tokens_count'] = $user_data['token'];
                $data['is_premium'] = $user_data['is_premium'];
                $data['username '] = getVal('username', 'users', 'user_id', $data['user_id']);
                $data['status'] = 1;

                $this->makeLog($insert_id, "User logged in", NULL, NULL, "User logged in using twitter");
            }
        } else if ($_POST['user_gid'] <> '' && $_POST['user_gid'] <> 0) {
            $verify = $this->api_model->verify_user('user_gid', $_POST['user_gid']);
            if ($verify == 1) {
                $data['status'] = 0;
                $data['error'] = 201;
                $data['message'] = 'You have not created an account, Please create account first.';
            } else {
                $insert_id = getVal('user_id', 'users', 'user_gid', $_POST['user_gid']);
                $data = $this->api_model->get_user_data($insert_id);
                $post_data['last_sign_in'] = date('Y-m-d H:i:s');
                $post_data['is_signed_in'] = '1';
                $results = $this->api_model->update('users', $post_data, array('user_id' => $data['user_id']));
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['fb_url'] = $data['fb_url'];
                $data['tw_url'] = $data['tw_url'];
                $data['soundcloud_url'] = $data['soundcloud_url'];
                $data['web_url'] = $data['web_url'];
                $data['cover_photo'] = $data['cover_photo'];
                $data['is_verified'] = $data['is_verified'];
                $data['following_count'] = getCount('following_user_id', 'following_count', 'follower', 'follower_user_id', $data['user_id']);
                $data['followers_count'] = getCount('following_user_id', 'followers_count', 'follower', 'following_user_id', $data['user_id']);
                $data['posts_count'] = getCount('post_id', 'posts_count', 'posts', 'user_id', $data['user_id']);
                $user_data = getValArray('secret_key,is_premium,token', 'users', 'user_id', $data['user_id']);
                $data['secret_key '] = $user_data['secret_key'];
                $data['tokens_count'] = $user_data['token'];
                $data['is_premium'] = $user_data['is_premium'];
                $data['username '] = getVal('username', 'users', 'user_id', $data['user_id']);
                $data['status'] = 1;
                $this->makeLog($insert_id, "User logged in", NULL, NULL, "User logged in using twitter");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        if ($data['status'] == 1) {
            $this->resetBadgeNumber($data['user_id']);
        }

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    /*     * *
     * Method: register
     * params: Posted Data $post
     * Return: Json
     */

    function register() {
        $post_data = array();
        $data = array();

        if ($_POST['user_fbId'] <> '' && $_POST['user_fbId'] <> 0) {
            $verify = $this->api_model->verify_user('user_fbId', $_POST['user_fbId']);

            if ($verify == 1) {
                $post_data['user_fbId'] = $_POST['user_fbId'];

              

                $post_data['name'] = $_POST['name'];
                if ($_POST['email'] <> '') {
                    $post_data['email'] = $_POST['email'];
                } else {
                    $post_data['email'] = '';
                }

                $post_data['is_active'] = 1;
                $post_data['avatar'] = $this->common->do_upload_FBpicture($_POST['user_fbId']);
                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $post_data['is_verified'] = 1;

                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                if ($results) {

                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['user_id'] = $data['user_id'];
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['is_verified'] = $data['is_verified'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
					$data['status'] = 1;
                    $data['message'] = 'Congratulation! Your account has been created successfully.';
                    $this->makeLog($insert_id, "FB User Signup", NULL, NULL, "User created new account using facebook");
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $insert_id = getVal('user_id', 'users', 'user_fbId', $_POST['user_fbId']);
                $data = $this->api_model->get_user_data($insert_id);
                unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['is_verified'] = $data['is_verified'];
                $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);

                $data['status'] = 1;
                $data['message'] = 'Congratulation! Your account has been created successfully.';
                $this->makeLog($insert_id, "FB User Signup", NULL, NULL, "User already have fb associated account, returning same account");
            }
        } else if ($_POST['user_gid'] <> '' && $_POST['user_gid'] <> 0) {
            $verify = $this->api_model->verify_user($_POST['user_gid']);
            if ($verify == 1) {
                $post_data['user_gid'] = $_POST['user_gid'];

    

                $post_data['name'] = $_POST['name'];
                if ($_POST['email'] <> '') {
                    $post_data['email'] = $_POST['email'];
                } else {
                    $post_data['email'] = '';
                }

                $post_data['is_active'] = 1;
                $post_data['avatar'] = $this->common->do_upload_FBpicture($_POST['user_gid']);
               
                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['is_verified'] = 1;
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                if ($results) {

                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['user_id'] = $data['user_id'];
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['is_verified'] = $data['is_verified'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
					$data['status'] = 1;
                    $data['message'] = 'Congratulation! Your account has been created successfully.';
                    $this->makeLog($insert_id, "Google plus User Signup", NULL, NULL, "User created new account using facebook");
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $insert_id = getVal('user_id', 'users', 'user_gid', $_POST['user_gid']);
                $data = $this->api_model->get_user_data($insert_id);
                unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['is_verified'] = $data['is_verified'];
                $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
				$data['status'] = 1;
                $data['message'] = 'Congratulation! Your account has been created successfully.';
                $this->makeLog($insert_id, "Google Plus User Signup", NULL, NULL, "User already have Google plus associated account, returning same account");
            }
        } else if ($_POST['user_inid'] <> '' && $_POST['user_inid'] <> 0) {
            $verify = $this->api_model->verify_user($_POST['user_inid']);
            if ($verify == 1) {
                $post_data['user_inid'] = $_POST['user_inid'];
				$post_data['name'] = $_POST['name'];
                if ($_POST['email'] <> '') {
                    $post_data['email'] = $_POST['email'];
                } else {
                    $post_data['email'] = '';
                }

                $post_data['is_active'] = 1;
                $post_data['avatar'] = $this->common->do_upload_FBpicture($_POST['user_inid']);
                //$post_data['created'] = time();
                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['is_verified'] = 1;
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                if ($results) {

                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['user_id'] = $data['user_id'];
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['is_verified'] = $data['is_verified'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);

                    $data['status'] = 1;
                    $data['message'] = 'Congratulation! Your account has been created successfully.';
                    $this->makeLog($insert_id, "Instagram User Signup", NULL, NULL, "User created new account using facebook");
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $insert_id = getVal('user_id', 'users', 'user_inid', $_POST['user_inid']);
                $data = $this->api_model->get_user_data($insert_id);
                unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['is_verified'] = $data['is_verified'];
                $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
				$data['status'] = 1;
                $data['message'] = 'Congratulation! Your account has been created successfully.';
                $this->makeLog($insert_id, "Instagram User Signup", NULL, NULL, "User already have Instagram associated account, returning same account");
            }
        } else if ($_POST['user_twid'] <> '' && $_POST['user_twid'] <> 0) {
            $verify = $this->api_model->verify_user_twitter($_POST['user_twid']);
            if ($verify == 1) {
                $post_data['user_twid'] = $_POST['user_twid'];
				$post_data['name'] = $_POST['name'];

                if ($_POST['tw_img'] <> '') {
                    $post_data['avatar'] = $_POST['tw_img'];
                }

                if ($_POST['email'] <> '') {
                    $post_data['email'] = $_POST['email'];
                } else {
                    $post_data['email'] = '';
                }

                $post_data['is_active'] = 1;

                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['is_verified'] = 1;
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                if ($results) {

                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['user_id'] = $data['user_id'];
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['is_verified'] = $data['is_verified'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
					$data['status'] = 1;
                    $data['message'] = 'Congratulation! Your account has been created successfully.';
                    $this->makeLog($insert_id, "Twitter User Signup", NULL, NULL, "User created new account using twitter");
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $insert_id = getVal('user_id', 'users', 'user_twid', $_POST['user_twid']);
                $data = $this->api_model->get_user_data($insert_id);
                unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                $data['user_id'] = $data['user_id'];
                $data['name'] = $data['name'];
                $data['email'] = $data['email'];
                $data['phone_no'] = $data['phone_no'];
                $data['avatar'] = $data['avatar'];
                $data['is_verified'] = $data['is_verified'];
                $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);
				$data['status'] = 1;
                $data['message'] = 'Congratulation! Your account has been created successfully.';
                $this->makeLog($insert_id, "Twitter User Signup", NULL, NULL, "User account associated with twitter already exist, returning same account.");
            }
        } else if ($_POST['email'] <> '' && $_POST['phone_no'] == '') {

            $verify = $this->api_model->verify_email($_POST['email']);
            if ($verify == 1) {
                if ($_FILES['avatar']['name'] != '') {
                    $extension = $this->common->getExtension($_FILES ['avatar'] ['name']);
                    $extension = strtolower($extension);
                    if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                        return false;
                    }
                    $path = 'uploads/users/avatar/';
                    $allow_types = 'gif|jpg|jpeg|png';
                    $max_height = '8000';
                    $max_width = '8000';
                    $avatar = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['avatar']['tmp_name'], $_FILES ['avatar']['name']);
                    $post_data['avatar'] = $photo = base_url('uploads/users/avatar/medium/' . $avatar);
                }
                $post_data['email'] = $_POST['email'];
                $post_data['username'] = $_POST['username'];
                $post_data['name'] = $_POST['name'];
                $post_data['password'] = md5($_POST['password']);
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $digits = 4;
                $post_data['pin'] = rand(pow(10, $digits - 1), pow(10, $digits) - 1);
                $post_data['is_active'] = 1;
                
                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                
                if ($results) {



                    $email = $_POST['email'];
                    $e_data['receiver_name'] = $post_data['name'];
                    $e_data['email_content'] = "To verify your email address " . $email . " Please Click on the below link. 
                                <br /><br />
                                Email verification Link: <a href=" . base_url() . "home/email_verification/" . encode($insert_id) . "><b>Click Here</b></a>
                                <br /><br />
                                if you did not request this verification, please ignore this email. If you feel something is wrong, please contact our support team: info@tagalongmusic.com.
                                ";


                    $e_data['title'] = 'Verify Email Address';
                    $e_data['content'] = $data['email_content'];
                    $e_data['welcome_content'] = "Greetings " . $e_data['receiver_name'];
                    $e_data['footer'] = "Regards";
                    $subject = $e_data['title'];
                    $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
                    $this->emailutility->send_email_user($email_content, $email, $subject);

                    unset($e_data);





                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);


                    $this->makeLog($insert_id, "User Email Signup", NULL, NULL, "User signup using email");

                    $data['status'] = 1;
                    $data['user_id'] = $insert_id;
                    $data['is_verified'] = 0;
                    $data['message'] = 'Congratulation! Your account has been created successfully. Now please verify your email address by click the link sent to your email address.';
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 202;
                $data['message'] = 'Email already exists. Please try another one.';
            }
        } else if ($_POST['email'] == '' && $_POST['phone_no'] <> '') {

            $verify = $this->api_model->verify_phone($_POST['phone_no']);

            if ($verify == 1) {

              
                $post_data['name'] = $_POST['name'];
                $post_data['username'] = $_POST['username'];
                $post_data['phone_no'] = $_POST['phone_no'];
                $post_data['password'] = md5($_POST['password']);
                $post_data['email'] = '';
                $post_data['is_active'] = 1;
                $post_data['is_verified'] = 1;
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->api_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();
                if ($results) {

                    $data = $this->api_model->get_user_data($insert_id);
                    unset($data['fb_url'], $data['tw_url'], $data['soundcloud_url'], $data['web_url']);
                    $data['name'] = $data['name'];
                    $data['email'] = $data['email'];
                    $data['phone_no'] = $data['phone_no'];
                    $data['avatar'] = $data['avatar'];
                    $data['is_verified'] = $data['is_verified'];
                    $data['username '] = getVal('username', 'users', 'user_id', $insert_id);
                    $data['secret_key '] = getVal('secret_key', 'users', 'user_id', $insert_id);

                    $data['status'] = 1;
                    $data['user_id'] = $insert_id;
                    $data['message'] = 'Congratulation! Your account has been created successfully.';
                } else {
                    $data['status'] = 0;
                    $data['error'] = 201;
                    $data['message'] = 'Not able to register. Try again later.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 202;
                $data['message'] = 'Phone Number already exists. Please try another one.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	/** *
     * Method: makeLog
     * params: Posted Data $post
     * Return: Json
     */
    function makeLog($user_id, $action, $class_id, $target_user_id, $description) {
        $post_data = array();
        if ($user_id) {
            $post_data['user_id'] = $user_id;
        }
        if ($action) {
            $post_data['action'] = $action;
        }
        if ($class_id) {
            $post_data['class_id'] = $class_id;
        }
        if ($target_user_id) {
            $post_data['target_user_id'] = $target_user_id;
        }
        if ($description) {
            $post_data['description'] = $description;
        }
        $this->api_model->create("activity_logs", $post_data);
    }

	/** *
     * Method: verifyUserPin
     * params: Posted Data $post
     * Return: Json
     */
    function verifyUserPin() {
        $data = array();
        $post_data = array();
        if ($_POST['user_id'] <> '' && $_POST['pin'] <> '') {
            $user_id = $_POST['user_id'];
            $pin = $_POST['pin'];
            $check = $this->api_model->verifyUserPin($user_id, $pin);
            if ($check == 0) {
                $data['status'] = 0;
                $data['error'] = 404;
                $data['message'] = 'Sorry, you have entered wrong pin code.';
                $this->makeLog($_POST['user_id'], "Verify email address", NULL, NULL, "User provided wrong PIN");
                header('Content-Type: application/json');
                echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
                exit;
            } else if ($check == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            }

            $cond = array();
            $cond['user_id'] = $user_id;
            $cond['pin'] = $pin;
            $post_data['is_verified'] = 1;
            $up = $this->api_model->update('users', $post_data, $cond);


            $data = array();
            $data = $this->api_model->get_user_data($user_id);
            $data['user_id'] = $data['user_id'];
            $data['name'] = $data['name'];
            $data['email'] = $data['email'];
            $data['phone_no'] = $data['phone_no'];
            $data['avatar'] = $data['avatar'];
            $data['fb_url'] = $data['fb_url'];
            $data['tw_url'] = $data['tw_url'];
            $data['soundcloud_url'] = $data['soundcloud_url'];
            $data['web_url'] = $data['web_url'];
            $data['cover_photo'] = $data['cover_photo'];
            $data['is_verified'] = $data['is_verified'];
            $data['status'] = 1;

            $data['message'] = 'Congratulation! Your account has been verified successfully.';
            $this->makeLog($_POST['user_id'], "Verify email address", NULL, NULL, "User successfully verifed email address");

        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/***
     * Method: resendEmailVerification
     * params: Posted Data $post
     * Return: Json
     */

    function resendEmailVerification() {
        $data = array();
        if ($_POST['userEmail'] <> '') {
            $checkStatus = $this->api_model->verify_email($_POST['userEmail']);

            if ($checkStatus == 0) {
                if (getVal('is_verified', 'users', 'email', $_POST['userEmail']) == 0) {
                    $user_email = $_POST['userEmail'];
                    $data = $this->api_model->get_user_data_by_email($user_email);

                   
                    $email = $data['email'];
                    $e_data['receiver_name'] = $data['name'];
                    $e_data['email_content'] = "To verify your email address " . $email . " Please Click on the below link. 
                                <br /><br />
                                
                                Email verification Link: <a href=" . base_url() . "home/email_verification/" . encode($data['user_id']) . "><b>Click Here </b></a>
                                <br /><br />
                                if you did not request this verification, please ignore this email. If you feel something is wrong, please contact our support team: info@tagalongmusic.com.
                                ";


                    $e_data['title'] = 'Verify Email Address';
                    $e_data['content'] = $e_data['email_content'];
                    $e_data['welcome_content'] = "Greetings " . $e_data['receiver_name'];
                    $e_data['footer'] = "Regards";
                    $subject = $e_data['title'];
                    $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
                    $this->emailutility->send_email_user($email_content, $email, $subject);

                    unset($e_data);
                    unset($data);

                    $data['status'] = 1;
                    $data['message'] = 'Verification email sent successfully.';
                    $this->makeLog($_POST['user_id'], "Verification email resent", NULL, NULL, "Verification email sent to user again");
                } else {
                    $data['status'] = 0;
                    $data['error'] = 402;
                    $data['message'] = 'User already verified.';
                }
            } else if ($checkStatus == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['error'] = 403;
                $data['message'] = 'No associated account found.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	 /** *
     * Method: send_notification
     * params: Posted Data $post
     * Return: Json
     */
	
    function send_notification($registration_ids, $message, $notification_title, $notification_text, $user_id, $notificationFlag) {
        

        $badge = 0;
        $badge_message = 0;
        $notification['body'] = $notification_text;
        $notification['title'] = $notification_title;

        if ($notificationFlag == 1) {
            $badge = $this->api_model->getBadgeIncremented($user_id);
            $badge_message = getVal('message_badge', 'users', 'user_id', $user_id);
        } else if ($notificationFlag == 2) {
            $badge = getVal('badge', 'users', 'user_id', $user_id);
            $badge = $this->api_model->getBadgeIncremented($user_id);
            $badge_message = $this->api_model->getMessageBadgeIncremented($user_id);
            $notification['sound'] = "default";
        } else if ($notificationFlag == 3) {
            $badge = getVal('badge', 'users', 'user_id', $user_id);
            $badge_message = getVal('message_badge', 'users', 'user_id', $user_id);
            $notification['sound'] = "default";
        }

        $notification['badge'] = $badge + $badge_message;
        $message['badge'] = $badge + $badge_message;

        foreach ($registration_ids as $arr) {
            $fields = array(
                'registration_ids' => array($arr),
                'data' => $message,
                'notification' => $notification,
                'priority' => "high"
            );

            $headers = array(
                'Authorization: key=AAAAVp0lUf0:APA91bFdGhfe3M0ADZTdCdM8fA2x843wvz4jdlaqfsgQ9b6aXPPj1LZEMTAXYG30NC8leErhDJqWn9dA6-KbmYkq3hHu7o2J4B7B5EQbr_2m4S_vaFmK707PrqRjmLlqYrQ1PzyWPxY7zOO-tvoTJTkR6vtq6sIfhQ',
                'Content-Type: application/json'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            $result = curl_exec($ch);

            if ($result === false) {
                die('Curl failed:' . curl_errno($ch));
            }

            curl_close($ch);
            
        }
        
        
    }

	 /** *
     * Method: exitIfInactive
     * params: Posted Data $post
     * Return: Json
     */
	 
    function exitIfInactive($user_id) {

        $is_inative = $this->api_model->isUserInactive($user_id);

        if ($is_inative == 1) {
            $data['status'] = 0;
            $data['error'] = 204;
            $data['message'] = 'The user you are trying to access is inactive.';
            header('Content-Type: application/json');
            echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
            exit;
        }
    }
	
	/** *
     * Method: resetBadgeNumber
     * params: Posted Data $post
     * Return: Json
     */
	 
    function resetBadgeNumber($user_id) {
        $post_data = array();
        $cond_array = array();
        $post_data['badge'] = 0;
        $cond_array['user_id'] = $user_id;
        $up = $this->api_model->update('users', $post_data, $cond_array);
    }
	
	/** *
     * Method: resetMessageBadgeNumber
     * params: Posted Data $post
     * Return: Json
     */
	 
	 
    function resetMessageBadgeNumber($user_id) {
        $post_data = array();
        $cond_array = array();
        $post_data['message_badge'] = 0;
        $cond_array['user_id'] = $user_id;
        $up = $this->api_model->update('users', $post_data, $cond_array);
    }
	
	/** *
     * Method: getUserNotification
     * params: Posted Data $post
     * Return: Json
     */

    function getUserNotification() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['unread_count'] = getVal('badge', 'users', 'user_id', $_POST['user_id']);
            $data['notifications'] = $this->api_model->getUserNotification($_POST['user_id'], $_POST['index'], $_POST['count']);
            $this->resetBadgeNumber($_POST['user_id']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/** *
     * Method: myProfile
     * params: Posted Data $post
     * Return: Json
     */
	 
    function myProfile() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['profile'] = $this->api_model->getMyProfile($_POST['user_id']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/** *
     * Method: fetchMessageThreads
     * params: Posted Data $post
     * Return: Json
     */

    function fetchMessageThreads() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);

            $data['status'] = 1;
            $data['unread_count'] = getVal('message_badge', 'users', 'user_id', $_POST['user_id']);
            $data['threads'] = $this->api_model->fetchMessageThreads($_POST['user_id'], $_POST['index'], $_POST['count']);
            

            for ($x = 0; $x < count($data['messages']); $x++) {
                $data['threads'][$x]["message"] = '|||' . $data['threads'][$x]["message"];
            }
           
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo str_replace("|||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/** *
     * Method: fetchMessages
     * params: Posted Data $post
     * Return: Json
     */
	
    function fetchMessages() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if (($_POST['user_id'] <> '' && $_POST['thread_id'] <> '' && $_POST['count'] <> '')) {

            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['messages'] = array_values($this->api_model->fetchMessages($_POST['user_id'], $_POST['thread_id'], $_POST['count'], $_POST['before'], $_POST['after']));

            for ($x = 0; $x < count($data['messages']); $x++) {
                $data['messages'][$x]["message"] = '|||' . $data['messages'][$x]["message"];
                $data['messages'][$x]["from_name"] = getVal('name', 'users', 'user_id', $_POST['user_id']);
                $data['messages'][$x]["from_img_url"] = getVal('avatar', 'users', 'user_id', $_POST['user_id']);
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo str_replace("|||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/** *
     * Method: sendMessage
     * params: Posted Data $post
     * Return: Json
     */
	 
    function sendMessage() {
        $data = array();
        $post_data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '' && ($_POST['thread_id'] <> '' || $_POST['to_id'] <> '') && $_POST['message'] <> '') {

            $this->exitIfInactive($_POST['user_id']);

            if ($_POST['thread_id'] <> '') {
                $from_id = getVal('from_id', 'thread', 'id', $_POST['thread_id']);
                $to_id = getVal('to_id', 'thread', 'id', $_POST['thread_id']);

                $this->exitIfInactive($from_id);

                $this->exitIfInactive($to_id);

                $post_data['thread_id'] = $_POST['thread_id'];
                $post_data['message'] = $_POST['message'];
                $post_data['from_user_id'] = $_POST['user_id'];

                if ($from_id == $_POST['user_id']) {
                    $post_data['to_user_id'] = $to_id;
                } else if ($to_id == $_POST['user_id']) {
                    $post_data['to_user_id'] = $from_id;
                }

                $message_id = $this->api_model->create('messages', $post_data);
                if ($message_id > 0) {
                    $to_id = $post_data['to_user_id'];
                    $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);

                    $message = array();
                    $message['sender_user_id'] = $_POST['user_id'];
                    $message['thread_id'] = $_POST['thread_id'];
                    $message['sender_user_pic'] = getVal('avatar', 'users', 'user_id', $_POST['user_id']);
                    $message['sender_user_name'] = getVal('name', 'users', 'user_id', $_POST['user_id']);

                    $flag = $this->api_model->shouldIncrementMessageBadge($to_id, $_POST['thread_id'], $message_id);

                    if ($flag == 0) {
                        $this->send_notification($regIds, $message, "New message received", $message['sender_user_name'] . " has sent you a message.", $to_id, 3);
                    } else if ($flag == 1) {
                        $this->send_notification($regIds, $message, "New message received", $message['sender_user_name'] . " has sent you a message.", $to_id, 2);
                    }
                    $data['status'] = 1;
                    $data['message_id'] = $message_id;
                    $data['thread_id'] = $_POST['thread_id'];

                    $post_data = array();
                    $post_data['last_update'] = date("Y-m-d h:i:sa");
                    $this->api_model->update('thread', $post_data, array('id' => $_POST['thread_id']));
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to send message.';
                }
            } else if ($_POST['to_id'] <> '' && $_POST['to_id'] <> 0) {
                $this->exitIfInactive($_POST['user_id']);
                $this->exitIfInactive($_POST['to_id']);
                $thread_check = $this->api_model->verifyThreadExist($_POST['user_id'], $_POST['to_id']);
                if ($thread_check == 0) {

                    $post['from_id'] = $_POST['user_id'];
                    $post['to_id'] = $_POST['to_id'];
                    $post['last_update'] = date("Y-m-d h:i:s");
                    $thread_id = $this->api_model->create('thread', $post);
                    $thread_check = $thread_id;
                }

                if ($thread_check > 0) {
                    $data['thread_id'] = $thread_check;
                    $post_data = array();
                    $post_data['thread_id'] = $thread_check;
                    $post_data['message'] = $_POST['message'];
                    $post_data['from_user_id'] = $_POST['user_id'];
                    $post_data['to_user_id'] = $_POST['to_id'];
                    $message_id = $this->api_model->create('messages', $post_data);
                    if ($message_id > 0) {

                        $to_id = $post_data['to_user_id'];
                        $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                        $message = array();
                        $message['sender_user_id'] = $_POST['user_id'];
                        $message['thread_id'] = $thread_check;
                        $message['sender_user_pic'] = getVal('avatar', 'users', 'user_id', $_POST['user_id']);
                        $message['sender_user_name'] = getVal('name', 'users', 'user_id', $_POST['user_id']);

                        $flag = $this->api_model->shouldIncrementMessageBadge($to_id, $thread_check, $message_id);
                        if ($flag == 0) {
                            $this->send_notification($regIds, $message, "New message received", $message['sender_user_name'] . " has sent you a message.", $to_id, 3);
                        } else if ($flag == 1) {
                            $this->send_notification($regIds, $message, "New message received", $message['sender_user_name'] . " has sent you a message.", $to_id, 2);
                        }

                        $data['status'] = 1;
                        $data['message_id'] = $message_id;
                        $post_data = array();
                        $post_data['last_update'] = date("Y-m-d h:i:s");
                        $this->api_model->update('thread', $post_data, array('id' => $thread_check));
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'Failed to send message.';
                    }
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to send message.';
                }
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/* * *
     * Method: markAsRead
     * params: Posted Data $post
     * Return: Json
     */
	 
    function markAsRead() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['message_ids'] <> '') {


            $this->exitIfInactive($_POST['user_id']);
            $messageIdArrays = array();

            $markids = $markids = array_filter(explode(',', $_POST['message_ids']));
            if (!empty($markids) && is_array($markids)) {
                foreach ($markids as $_id) {
                    if (strpos($_id, '[') !== false) {
                        $string = mb_strimwidth($_id, 1, strlen($_id));
                        $post_data = array();
                        $post_data['is_read'] = 1;
                        $messageIdArrays[count($messageIdArrays)] = $string;
                        $this->api_model->update('messages', $post_data, array('message_id' => $string));
                    } else if (strpos($_id, ']') !== false) {
                        $string = mb_strimwidth($_id, 0, strlen($_id) - 1);
                        $post_data = array();
                        $post_data['is_read'] = 1;
                        $messageIdArrays[count($messageIdArrays)] = $string;
                        $this->api_model->update('messages', $post_data, array('message_id' => $string));
                    } else {
                        $post_data = array();
                        $post_data['is_read'] = 1;
                        $messageIdArrays[count($messageIdArrays)] = $_id;
                        $this->api_model->update('messages', $post_data, array('message_id' => $_id));
                    }
                }
                $this->api_model->updateMessageBadgeIfRequired($_POST['user_id'], $messageIdArrays);
                $data['status'] = 1;
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }
	
	/* * *
     * Method: markAllRead
     * params: Posted Data $post
     * Return: Json
     */
	 
	 
    function markAllRead() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['thread_id'] <> '') {


            $this->exitIfInactive($_POST['user_id']);

            $result = $this->api_model->getMessageIdsToUser($_POST['user_id'], $_POST['thread_id']);

            for ($x = 0; $x < count($result); $x++) {
                $post_data = array();
                $post_data['is_read'] = 1;
                $this->api_model->update('messages', $post_data, array('message_id' => $result[$x]['message_id']));
            }
            $this->api_model->getMessageBadgeDecremented($_POST['user_id']);
            $data['status'] = 1;
            $data['message'] = 'Messages marked read successfully.';
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/* * *
     * Method: markAllReadCustom
     * params: Posted Data $post
     * Return: Json
     */
	 
	 
    function markAllReadCustom($user_id, $thread_id) {
        if ($this->api_model->verifyShouldDecrementBadge($user_id, $thread_id)) {
            $this->api_model->getMessageBadgeDecremented($user_id);
        }
    }

	/* * *
     * Method: deleteMessages
     * params: Posted Data $post
     * Return: Json
     */
	 
    function deleteMessages() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['message_ids'] <> '') {

            $this->exitIfInactive($_POST['user_id']);

            $delids = $delids = array_filter(explode(',', $_POST['message_ids']));
            $badgeFlag = true;
            if (!empty($delids) && is_array($delids)) {
                foreach ($delids as $_id) {
                    if (strpos($_id, '[') !== false) {
                        $string = mb_strimwidth($_id, 1, strlen($_id));
                        $from_id = getVal('from_user_id', 'messages', 'message_id', $string);
                        $post_data = array();
                        if ($from_id == $_POST['user_id']) {
                            $post_data['sender_status'] = 0;
                        } else {
                            $post_data['receiver_status'] = 0;
                        }
                        $this->api_model->update('messages', $post_data, array('message_id' => $string));
                    } else if (strpos($_id, ']') !== false) {
                        $string = mb_strimwidth($_id, 0, strlen($_id) - 1);
                        $from_id = getVal('from_user_id', 'messages', 'message_id', $string);
                        $post_data = array();
                        if ($from_id == $_POST['user_id']) {
                            $post_data['sender_status'] = 0;
                        } else {
                            $post_data['receiver_status'] = 0;
                        }
                        $this->api_model->update('messages', $post_data, array('message_id' => $string));
                    } else {
                        $from_id = getVal('from_user_id', 'messages', 'message_id', $_id);
                        $post_data = array();
                        if ($from_id == $_POST['user_id']) {
                            $post_data['sender_status'] = 0;
                        } else {
                            if ($badgeFlag == true) {
                                $decFlag = getVal('is_read', 'messages', 'message_id', $_id);
                                if ($decFlag == 0) {
                                    $badgeFlag = false;
                                    $this->api_model->getMessageBadgeDecremented($_POST['user_id']);
                                }
                            }
                            $post_data['receiver_status'] = 0;
                        }
                        $this->api_model->update('messages', $post_data, array('message_id' => $_id));
                    }
                }
                $data['status'] = 1;
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/* * *
     * Method: deleteThread
     * params: Posted Data $post
     * Return: Json
     */
	 
    function deleteThread() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['thread_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);
            $this->markAllReadCustom($_POST['user_id'], $_POST['thread_id']);
            $thread_id = $_POST['thread_id'];
            $updated = 0;
            $message_ids = $this->api_model->getMessageIds($thread_id);
            for ($x = 0; $x < count($message_ids); $x++) {
                $id = $message_ids[$x]['message_id'];
                $from_id = getVal('from_user_id', 'messages', 'message_id', $id);
                $post_data = array();
                if ($from_id == $_POST['user_id']) {
                    $post_data['sender_status'] = 0;
                } else {
                    $post_data['receiver_status'] = 0;
                }
                $updated = $this->api_model->update('messages', $post_data, array('message_id' => $id));
                $checkDeleteMsg = getValArray('sender_status,receiver_status', 'messages', 'message_id', $id);

                if ($checkDeleteMsg[sender_status] == 0 && $checkDeleteMsg[receiver_status] == 0) {

                    $result = $this->api_model->delete('messages', array('message_id' => $id));
                }
            }

            if ($updated > 0) {
                $data['status'] = 1;
                $data['message'] = 'Thread deleted';
            } else {
                $data['status'] = 0;
                $data['message'] = 'Failed to delete thread';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: updateProfile
     * params: Posted Data $post
     * Return: Json
     */
    function updateProfile() {
        $data = array();

        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        $post_data = array();
        if ($_POST['user_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);

            $verify = $this->api_model->verify_user_id($_POST['user_id']);

            if ($verify == 1) {


                $verifyEmail = $verifyPhone = 1;

                if ($verifyEmail == 1 || $verifyPhone == 1) {


                    $user_id = $_POST['user_id'];
                    $post_data = $this->api_model->get_user_data($user_id);

                    if ($_POST['name'])
                        $post_data['name'] = $_POST['name'];
                    if ($_POST['username'])
                        $post_data['username'] = $_POST['username'];

                    if ($_POST['fb_url'])
                        $post_data['fb_url'] = $_POST['fb_url'];
                    if ($_POST['tw_url'])
                        $post_data['tw_url'] = $_POST['tw_url'];

                    if ($_POST['soundcloud_url'])
                        $post_data['soundcloud_url'] = $_POST['soundcloud_url'];

                    if ($_POST['web_url'])
                        $post_data['web_url'] = $_POST['web_url'];

                    $post_data['updated_at'] = date('Y-m-d H:i:s');
                    $results = $this->api_model->update('users', $post_data, array('user_id' => $user_id));
                    if ($results > 0) {
//                               
                        $data = $this->api_model->get_user_data($user_id);
                        $data['user_id'] = '||' . $data['user_id'];
                        $data['name'] = '||' . $data['name'];
                        $data['email'] = '||' . $data['email'];
                        $data['phone_no'] = '||' . $data['phone_no'];
                        $data['avatar'] = '||' . $data['avatar'];
                        $data['fb_url'] = '||' . $data['fb_url'];
                        $data['tw_url'] = '||' . $data['tw_url'];
                        $data['soundcloud_url'] = '||' . $data['soundcloud_url'];
                        $data['web_url'] = '||' . $data['web_url'];
                        $data['cover_photo'] = '||' . $data['cover_photo'];
                        $data['is_verified'] = '||' . $data['is_verified'];
                        $data['status'] = 1;
                        $this->makeLog($_POST['user_id'], "Update profile", NULL, NULL, "User has updated profile.");
                    } else {
                        $data['status'] = 0;
                        $data['message'] = 'Profile not updated. Please try again later.';
                    }
                } else {
                    
                    $data['status'] = 0;
                    $data['error'] = 202;
                    $data['message'] = $r . ' already exists. Please try another one.';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['error'] = 203;
                $data['message'] = 'User not exist.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 204;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    /**
     * Method: updatePhoto
     * params: Posted Data $post
     * Return: Json
     */
    function updatePhoto() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        $post_data = array();
        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $verify = $this->api_model->verify_user_id($_POST['user_id']);
            if ($verify == 1) {
                $user_id = $_POST['user_id'];
                $old_photo = end(explode('/', getVal('avatar', 'users', 'user_id', $user_id)));
                $old_photo_cover = end(explode('/', getVal('cover_photo', 'users', 'user_id', $user_id)));
                if ($_FILES['avatar']['name'] != '') {
                    unlink('uploads/users/avatar/pic/' . $old_photo);
                    unlink('uploads/users/avatar/small/' . $old_photo);
                    unlink('uploads/users/avatar/medium/' . $old_photo);
                    $extension = $this->common->getExtension($_FILES ['avatar'] ['name']);
                    $extension = strtolower($extension);
                    if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                        return false;
                    }
                    $path = 'uploads/users/avatar/';
                    $allow_types = 'gif|jpg|jpeg|png';
                    $max_height = '8000';
                    $max_width = '8000';
                    $avatar = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['avatar']['tmp_name'], $_FILES ['avatar']['name']);
                    $post_data['avatar'] = $photo = base_url('uploads/users/avatar/medium/' . $avatar);
                }
                if ($_FILES['cover_photo']['name'] != '') {
                    unlink('uploads/users/cover_photo/pic/' . $old_photo_cover);
                    unlink('uploads/users/cover_photo/small/' . $old_photo_cover);
                    unlink('uploads/users/cover_photo/medium/' . $old_photo_cover);
                    $extension = $this->common->getExtension($_FILES ['cover_photo'] ['name']);
                    $extension = strtolower($extension);
                    if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                        return false;
                    }
                    $path = 'uploads/users/cover_photo/';
                    $allow_types = 'gif|jpg|jpeg|png';
                    $max_height = '8000';
                    $max_width = '8000';
                    $cover_photo = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['cover_photo']['tmp_name'], $_FILES ['cover_photo']['name']);
                    $post_data['cover_photo'] = $photo_cover = base_url('uploads/users/cover_photo/pic/' . $cover_photo);
                }

                $results = $this->api_model->update('users', $post_data, array('user_id' => $user_id));

                if ($results) {
                    $data['status'] = 1;
                    if ($avatar <> '') {
                        $data['avatar'] = $photo;
                        $this->makeLog($_POST['user_id'], "Update photo", NULL, NULL, "User has updated photo.");
                    }
                    if ($cover_photo <> '') {
                        $data['cover_photo'] = $photo_cover;
                        $this->makeLog($_POST['user_id'], "Update photo", NULL, NULL, "User has updated photo.");
                    }
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Photo not updated. Please try again later.';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not Exists.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: getUserProfile
     * params: Posted Data $post
     * Return: Json
     */
    function getUserProfile() {
        $data = array();
        $this->common->matchSecretKey($_GET['user_id'], $this->secret_key);
        if ($_GET['user_id'] <> '' || $_GET['user_id'] <> 0) {
            $this->exitIfInactive($_GET['user_id']);
            $user_id = $_GET['user_id'];
            $verify = $this->api_model->verify_user_id($user_id);
            if ($verify == 1) {
                $data['status'] = 1;
                $data['user'] = $this->api_model->get_user_data($user_id);
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not exist.';
            }
        } else {
            $data['status'] = 0;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: forgotPassword
     * params: Posted Data
     * Retruns: Json
     */
    function forgotPassword() {
        $data = array();


        if ($_POST['email'] <> '') {

            $email = $_POST['email'];
            if ($email <> '') {

                $res = $this->api_model->verify_email($email);

                if ($res == 0) {

                    $email = $_POST['email'];
                    $user_id = getVal('user_id', 'users', 'email', $email);
                    $digits = 4;
                    $verfication_code = rand(pow(10, $digits - 1), pow(10, $digits) - 1);
                    $e_data['receiver_name'] = "Tag a Long User";
                    $e_data['email_content'] = "It looks like you requested to reset password. 
                                <br />
                                
                                Your 4 digit code: <b> $verfication_code</b>
                                <br /><br />
                                if you did not request to reset password, please ignore this email. If you feel something is wrong, please contact our support team: info@tagalongmusic.com.
                                ";

                    $e_data['title'] = 'Reset Password';
                    $e_data['content'] = $data['email_content'];
                    $e_data['welcome_content'] = "Greetings " . $data['receiver_name'];
                    $e_data['footer'] = "Regards";
                    $subject = $e_data['title'];


                    $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);

                    $this->emailutility->send_email_user($email_content, $email, $subject);


                    unset($e_data);
                    $cond = array();
                    $post_data['verfication_code'] = $verfication_code;
                    $cond['email'] = $email;
                    $result = $this->api_model->update('users', $post_data, $cond);
                    $this->makeLog($user_id, "Forgot password", NULL, NULL, "User has forgot password.");
                    $data['verfication_code'] = $verfication_code;
                    $data['status'] = 1;
                    $data['message'] = 'Please Check your email for a message with your code.';

//                    }
                } else if ($res == -1) {
                    $data['status'] = 0;
                    $data['error'] = 204;
                    $data['message'] = 'The user you are trying to access is inactive.';
                } else {
                    $data['status'] = 0;
                    $data['error'] = 202;
                    $data['message'] = 'Email "' . $_POST['email'] . '" not exists. Please try another email.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 404;
                $data['message'] = 'Invalid data provided.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: deleteAccount
     * params: Posted Data $post
     * Return: Json
     */
    function deleteAccount() {
        $data = array();
        if ($_POST['user_id'] <> '') {

            $this->exitIfInactive($_POST['user_id']);

            $verify = $this->api_model->verify_user_id($_POST['user_id']);
            if ($verify == 1) {

                $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
                $post_data = array();
                $post_data['user_id'] = $_POST['user_id'];
                $result = $this->api_model->delete('users', $post_data);
                if ($result) {
                    $this->makeLog($_POST['user_id'], "Delete Account", NULL, NULL, "User has deleted his account.");
                    $data['status'] = 1;
                    $data['message'] = "successfully deleted user account ";
                } else {
                    $this->makeLog($_POST['user_id'], "Delete Account Denied", NULL, NULL, "Failed to delete user account.");
                    $data['status'] = 0;
                    $data['message'] = 'Failed to delete user account, Please try again.';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not Exists.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: deactiviateAccount
     * params: Posted Data $post
     * Return: Json
     */
    function deactiviateAccount() {
        $data = array();
        if ($_POST['user_id'] <> '') {
            $_POST['user_id'];

            $this->exitIfInactive($_POST['user_id']);

            $verify = $this->api_model->verify_user_id($_POST['user_id']);
            if ($verify == 1) {
                $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
                $post_data = array();
                $cond = array();
                $post_data['is_active'] = 0;
                $cond['user_id'] = $_POST['user_id'];
                $result = $this->api_model->update('users', $post_data, $cond);

                if ($result) {

                    $del_data = array();
                    $del_data['user_id'] = $_POST['user_id'];
                    $result = $this->api_model->delete('user_firebase_tokens', $del_data);
                    $this->makeLog($_POST['user_id'], "Deactivate Account", NULL, NULL, "User has deactivated his account.");
                    $data['status'] = 1;
                    $data['message'] = "successfully deactivated user account ";
                } else {
                    $this->makeLog($_POST['user_id'], "Deactivate Account Denied", NULL, NULL, "Failed to deactivat user account.");
                    $data['status'] = 0;
                    $data['message'] = 'Failed to deactivat user account, Please try again.';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not Exists.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: getCountries
     * params: Posted Data $post
     * Return: Json
     */
    function getCountries() {
        $data = array();

        $results = $this->api_model->getCountries();
        if ($results) {
            $data['status'] = 1;
            $data['countries'] = $results;
        } else {
            $data['status'] = 1;
            $data['countries'] = array();
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

   

    /**
     * Method: getAllNotifications
     * params: Posted Data
     * Return: Json
     */
    function getAllNotifications() {
        $data = array();
        $offset = $_GET['offset'];
        $limit = $_GET['limit'];
        $user_id = $_GET['user_id'];
        $this->common->matchSecretKey($_GET['user_id'], $this->secret_key);

        if ($_GET['user_id'] <> '') {
            $this->resetBadgeNumber($_GET['user_id']);
            $this->exitIfInactive($_GET['user_id']);
            $results = $this->api_model->getAllNotifications($offset, $limit, $user_id);
            if ($results <> null) {
                $data['status'] = 1;
                $data['notifications'] = $results;
            } else {
                $data['status'] = 0;
                $data['message'] = 'No notifications found';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: updateNotificationToken
     * params: Posted Data
     * Retruns: Json
     */
    function updateNotificationToken() {

        $data = array();
        $post_data = array();
        if ($_POST['user_id'] <> '' && $_POST['firebase_token'] <> '' && $_POST['device_id'] <> '') {

            if ($_POST['user_id'] == 0 || $_POST['user_id'] == '0') {
                $cond = array();
                $cond['device_id'] = $_POST['device_id'];
                $result = $this->api_model->delete('user_firebase_tokens', $cond);
                $data['status'] = 1;
                $data['message'] = 'Firebase Notification Id removed';
                header('Content-Type: application/json');
                echo json_encode($data, JSON_NUMERIC_CHECK);
                exit;
            }

            $cond = array();
            $cond['device_id'] = $_POST['device_id'];

            $result = $this->api_model->delete('user_firebase_tokens', $cond);

            $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
            $verify = $this->api_model->verify_user_id($_POST['user_id']);
            if ($verify == 1) {

                $post_data['user_id'] = $_POST['user_id'];
                $post_data['firebase_token'] = $_POST['firebase_token'];
                $post_data['device_id'] = $_POST['device_id'];
                $result = $this->api_model->create('user_firebase_tokens', $post_data);


                if ($result > 0) {
                    $data['status'] = 1;
                    $data['message'] = 'Firebase Notification Id successfully updated';
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to update firebase notification id';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not Exists.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: logout
     * params: Posted Data
     * Retruns: Json
     */
    function logout() {

        $data = array();
        $post_data = array();
        if ($_POST['user_id'] <> '' && $_POST['device_id'] <> '') {
            $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
            $this->resetBadgeNumber($_POST['user_id']);
            $this->exitIfInactive($_POST['user_id']);

            $verify = $this->api_model->verify_user_id($_POST['user_id']);
            if ($verify == 1) {
                $post_data['user_id'] = $_POST['user_id'];
                $post_data['device_id'] = $_POST['device_id'];
                $result = $this->api_model->delete('user_firebase_tokens', $post_data);
                if ($result) {
                    $this->makeLog($_POST['user_id'], "Log out", NULL, NULL, "User has logged out.");
                    $data['status'] = 1;
                    $data['message'] = "Successfully logged out ";
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to logout.';
                }
            } else if ($verify == -1) {
                $data['status'] = 0;
                $data['error'] = 204;
                $data['message'] = 'The user you are trying to access is inactive.';
            } else {
                $data['status'] = 0;
                $data['message'] = 'User not Exists.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /**
     * Method: getClientToken
     * params: Posted Data
     * Retruns: Json
     */

    function getClientToken() {
        $data = array();

        $this->load->library("braintree_lib");

        $data['token'] = $this->braintree_lib->create_client_token();
        if ($data['token'] <> '') {
            $data['status'] = 1;
            header('Content-Type: application/json');
            echo json_encode($data, JSON_NUMERIC_CHECK);
            exit;
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
            header('Content-Type: application/json');
            echo json_encode($data, JSON_NUMERIC_CHECK);
            exit;
        }
    }

   /**
     * Method: searchFavouriteTrack
     * params: Posted Data
     * Retruns: Json
     */
    
    function searchFavouriteTrack() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['index'] <> '' && $_POST['count'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $results = $this->api_model->favouriteTracks($_POST['user_id'], $_POST['query_text'], $_POST['index'], $_POST['count']);
            $data['tracks'] = $results;
            for ($x = 0; $x < count($results); $x++) {
                $filename = $results[$x]['file_name'];
                $data['tracks'][$x]['url'] = base_url() . "uploads/tracks/track_thumb/" . $filename;
                unset($data['tracks'][$x]['file_name']);
            }

            $data['status'] = 1;
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	 /**
     * Method: trackDetail
     * params: Posted Data
     * Retruns: Json
     */
    
	
    function trackDetail() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['track_id'] <> '' && $_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['track'] = $this->api_model->getTrackDetail($_POST['track_id']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	 /**
     * Method: getGenre
     * params: Posted Data
     * Retruns: Json
     */
	
    function getGenre() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $this->exitIfInactive($_POST['user_id']);
            $results = $this->api_model->getGenres();
            if ($results) {
                $data['status'] = 1;
                $data['genres'] = $results;
            } else {
                $data['error'] = 402;
                $data['status'] = 0;
                $data['message'] = 'Failed to get Genres, Please try again.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	 /**
     * Method: updateMyGenre
     * params: Posted Data
     * Retruns: Json
     */
	 
    function updateMyGenre() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['genres'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $genre_id = implode(',', json_decode($_POST['genres']));
            $post_data = array();
            $post_data['genres'] = $genre_id;
            $cond = array();
            $cond['user_id'] = $_POST['user_id'];
            $update = $this->api_model->update('users', $post_data, $cond);
            if ($update > 0) {
                unset($post_data);
                $post_data = array();
                unset($cond);
                $cond = array();
                $this->makeLog($_POST['user_id'], "Update Users", NULL, NULL, "User has successfully updated genre");
                $data['message'] = 'User has successfully updated genre.';
                $data['status'] = 1;
            } else {

                $this->makeLog($_POST['user_id'], "Failed to update genre", $_POST['user_id'], "user failed to update genre");
                $data['error'] = 402;
                $data['status'] = 0;
                $data['message'] = 'User failed to update genre';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/**
     * Method: addCreditCard
     * params: Posted Data
     * Retruns: Json
     */
	 
    function addCreditCard() {
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $update_data = array();
            $update_data['is_primary'] = 0;
            $cond_update = array();
            $cond_update['user_id'] = $_POST['user_id'];
            $this->api_model->update('billing_address', $update_data, $cond_update);

            $post_data['user_id'] = $_POST['user_id'];
            $post_data['holder_name'] = $_POST['holder_name'];
            $post_data['card_number'] = $_POST['card_number'];
            $post_data['cvv'] = $_POST['cvv'];
            $post_data['expiry_month'] = $_POST['expiry_month'];
            $post_data['expiry_year'] = $_POST['expiry_year'];
            $post_data['is_primary'] = 1;
            $post_data['created'] = time();
            $results = $this->api_model->create('billing_address', $post_data);
            if ($results) {
                $this->makeLog($results, "Credit Card information", NULL, NULL, "Credit Card information  has been saved successfully");
                $data['cards'] = $this->api_model->getcards($_POST['user_id']);
                $i = 0;
                foreach ($data['cards'] as $card) {
                    $data['cards'][$i]['last_digits'] = '|||' . $card['last_digits'];
                    $i++;
                }

                $data['status'] = 1;
                $data['message'] = 'Credit Card information  has been saved successfully.';
            } else {
                $data['status'] = 1;
                $data['error'] = 402;
                $data['message'] = 'Failed to add Credit Card information, Please try again.';
            }
        } else {
            $data['status'] = 1;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("|||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/**
     * Method: deleteCreditCard
     * params: Posted Data
     * Retruns: Json
     */
	 
	 
    function deleteCreditCard() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['card_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $result = $this->api_model->delete('billing_address', array('id' => $_POST['card_id']));
            if ($result) {
                $data['status'] = 1;
                $data['message'] = 'card has been deleted successfully';
                $this->makeLog($_POST['card_id'], "Card Deleted", NULL, NULL, "Card  has been deleted");
            } else {
                $data['status'] = 0;
                $data['message'] = 'Failed to delete card.';
                $this->makeLog($_POST['post_id'], "Card Deleted", NULL, NULL, "Failded to delete card");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/**
     * Method: setPrimaryCard
     * params: Posted Data
     * Retruns: Json
     */
	 
    function setPrimaryCard() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['card_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $update_data = array();
            $update_data['is_primary'] = 0;
            $cond_update = array();
            $cond_update['user_id'] = $_POST['user_id'];
            $this->api_model->update('billing_address', $update_data, $cond_update);

            $post_data = array();
            $post_data['is_primary'] = 1;
            $cond = array();
            $cond['id'] = $_POST['card_id'];
            $update = $this->api_model->update('billing_address', $post_data, $cond);


            if ($update > 0) {
                $this->makeLog($_POST['user_id'], " primary card", NULL, NULL, "Primary card set sucsessfully");
                $data['cards'] = $this->api_model->getcards($_POST['user_id']);
                $i = 0;
                foreach ($data['cards'] as $card) {
                    $data['cards'][$i]['last_digits'] = '|||' . $card['last_digits'];
                    $i++;
                }
                $data['message'] = 'Primary card set sucsessfully.';
                $data['status'] = 1;
            } else {

                $this->makeLog($_POST['user_id'], "primary card", $_POST['user_id'], "Failed to set primary card");
                $data['error'] = 402;
                $data['status'] = 0;
                $data['message'] = 'User failed to update Primary card';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("|||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/**
     * Method: getCreditCards
     * params: Posted Data
     * Retruns: Json
     */
	 
    function getCreditCards() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $this->exitIfInactive($_POST['user_id']);
            $data['message'] = 'successfully get card information';
            $data['status'] = 1;
            $data['cards'] = $this->api_model->getcards($_POST['user_id']);
            $i = 0;
            foreach ($data['cards'] as $card) {
                $data['cards'][$i]['last_digits'] = '|||' . $card['last_digits'];
                $i++;
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("|||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/**
     * Method: usernameAvailability
     * params: Posted Data
     * Retruns: Json
     */

    function usernameAvailability() {
        $data = array();
        if ($_POST['username'] <> '' || $_POST['username'] <> 0) {
            $username = $_POST['username'];

            $result = $this->api_model->checkUsername($username);
            if ($result == 1) {
                $data['status'] = 0;
                $data['message'] = 'Username already exists. Please use a different username.';
            } else {
                $data['status'] = 1;
                $data['message'] = 'Username is available';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

    /* * *
     * Method: createPost
     * params: Posted Data $post
     * Return: Json
     */

    function createPost() {

        $data = array();
        $post_data = array();
        $bar = array();
        $participant = array();
        $update_participant = array();
        $is_initiator = 0;

        $params = $_POST;
        if(isset($params['draft_id']) && $params['draft_id']!=""):
        $delete_draft = array();
        $delete_draft['id'] = $params['draft_id'];
        $del = $this->api_model->delete('draftPost', $delete_draft);
        unset($params['draft_id']);
        endif;
        $participant = json_decode($_POST['participant'], TRUE);
        $this->common->matchSecretKey($params['user_id'], $this->secret_key);
        if (($params['user_id'] <> '' || $params['user_id'] <> 0) && ($_FILES['recording']['name'] != '')) {
            $participant = json_decode($params['participant'], TRUE);
            unset($params['participant']);
            $extension = $this->common->getExtension($_FILES ['recording'] ['name']);
            $extension = strtolower($extension);

            $path = 'uploads/recording/' . $params['user_id'];

            $old_file = "";
            if ($params['post_id'] <> '') {

                $old_file = getVal('filename', 'posts', 'post_id', $params['post_id']);
                $user_id = getVal('user_id', 'posts', 'post_id', $params['post_id']);
                $old_file = explode('/', $old_file);
                $old_file = end($old_file);
                $path = 'uploads/recording/' . $user_id;
            }

            $filename = $this->common->uploadRecord_mp3($path, $extension, $_FILES['recording']['tmp_name'], $_FILES['recording']['name'], $old_file);

            if ($filename) {
                
            } else {
                $data['status'] = 0;
                $data['error'] = 400;
                $data['message'] = 'Sorry fail to create recording';
                header('Content-Type: application/json');
                echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
                exit;
            }
            if ((empty($params['post_id']) || !isset($params['post_id'])) && $params['post_type'] == 0) {
                if ($params['post_title'] <> '' || $params['post_description'] <> '' || $params['track_id'] <> '' || $_FILES['post_avatar']['name'] != '') {


                    $extension = $this->common->getExtension($_FILES['post_avatar']['name']);

                    $extension = strtolower($extension);
                    if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                        return false;
                    }
                    unset($params['is_initiator']);
                    $path = 'uploads/post/';
                    $allow_types = 'gif|jpg|jpeg|png';
                    $max_height = '8000';
                    $max_width = '8000';

                    $avatar = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['post_avatar']['tmp_name'], $_FILES ['post_avatar']['name']);
                    unset($params['post_avatar']);
                    foreach ($params as $k => $v) {
                        $post_data[$k] = $v;
                    }

                    $post_data['post_avatar'] = base_url('uploads/post/pic/' . $avatar);
                    $post_data['filename'] = base_url('uploads/recording/' . $params['user_id'] . '/' . $filename);
                    $post_data['recorded'] = 1;
                    $post_data['is_locked'] = 1;
                    $post_data['is_active'] = 1;
                    $post_data['publish'] = date('Y-m-d');
                    $post_data['created'] = date('Y-m-d H:i:s');
                    $post_id = $this->api_model->create('posts', $post_data);
                    if ($post_id > 0) {
                        $post = $this->api_model->getPost($post_id);
                        foreach ($post as $key => $val) {
                            $data[$key] = '||' . $val;
                        }

                        $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                        $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
                        $bar = $this->api_model->get_single_bar($post_id);
                        $data['Bar '] = $bar;
                        $data['participant'] = array();
                        $data['status'] = 1;
                        $data['message'] = 'Post  has been saved successfully.';
                        $this->makeLog($results, "post created", NULL, NULL, "Post has been saved successfully");
                        unset($data['recorded']);
                        unset($data['user_id']);
                    } else {
                        $data['status'] = 0;
                        $data['error'] = 403;
                        $data['message'] = 'Sorry failed to create Post, Please try again later.';
                    }
                } else {
                    $data['status'] = 0;
                    $data['error'] = 403;
                    $data['message'] = 'Sorry Invalid data provided';
                }
            } else if ((empty($params['post_id']) || !isset($params['post_id'])) && $params['post_type'] == 1 && !empty($participant) && $params['duration'] <> '') {

                if ($params['post_title'] <> '' || $params['post_description'] <> '' || $params['track_id'] <> '' || $_FILES['post_avatar']['name'] != '') {

                    $extension = $this->common->getExtension($_FILES['post_avatar'] ['name']);
                    $extension = strtolower($extension);
                    if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                        return false;
                    }
                    $path = 'uploads/post/';
                    $allow_types = 'gif|jpg|jpeg|png';
                    $max_height = '8000';
                    $max_width = '8000';

                    $avatar = $this->common->do_upload_profile($path, $allow_types, $max_height, $max_width, $_FILES ['post_avatar']['tmp_name'], $_FILES ['post_avatar']['name']);

                    $is_initiator = $params['is_initiator'];
                    $start_time = "00:00:00";
                    $end_time = $params['duration'];

                    unset($params['is_initiator'], $params['duration'], $params['post_avatar']);
                    foreach ($params as $k => $v) {
                        $post_data[$k] = $v;
                    }
                    $post_data['filename'] = base_url('uploads/recording/' . $params['user_id'] . '/' . $filename);
                    $post_data['post_avatar'] = base_url('uploads/post/pic/' . $avatar);
                    $post_data['is_active'] = 1;
                    $post_data['created'] = date('Y-m-d H:i:s');

                    $post_id = $this->api_model->create('posts', $post_data);

                    if ($post_id > 0) {
                        for ($x = 0; $x < count($participant); $x++) {
                            $participantData = array();
                            $postparticipantData = array();
                            $participantData = $participant[$x];
                            $postparticipantData['participant_id'] = $participantData['participant_id'];
                            $postparticipantData['assign_bars'] = $participantData['assign_bars'];
                            $postparticipantData['participant_index'] = $participantData['participant_index'];
                            $postparticipantData['user_id'] = $params['user_id'];
                            $postparticipantData['post_id'] = $post_id;
                            $postparticipantData['is_active'] = 1;
                            $postparticipantData['created'] = time();
                            $results = $this->api_model->create('participant', $postparticipantData);
                            if ($results > 0) {
                                $to_id = $participantData['participant_id'];
                                if ($participantData['participant_id'] != $params['user_id']) {

                                    $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                                    /** Collab request notification* */
                                    $message = array();
                                    $message['user_id'] = $params['user_id'];
                                    $message['post_id'] = $post_id;
                                    $message['user_avatar'] = getVal('avatar', 'users', 'user_id', $params['user_id']);
                                    $message['user_name'] = getVal('name', 'users', 'user_id', $params['user_id']);
                                    $desc = $message['user_name'] . " has sent you a Collab Request.";
                                    $this->send_notification($regIds, $message, "A User has sent you Collab Request.", $desc, $to_id, 1);
                                    $not_logs['user_id'] = $to_id;
                                    $not_logs['sender_id'] = $params['user_id'];
                                    $not_logs['post_id'] = $post_id;
                                    $not_logs['action'] = 'Collab Request';

                                    $not_logs['description'] = $desc;
                                    $insert = $this->api_model->create('notifications_logs', $not_logs);
                                }
                            }
                        }
                        if ($results > 0) {

                            $update_participant['recorded'] = 1;
                            $update_participant['is_initiator'] = $is_initiator;
                            $update_participant['start_time'] = $start_time;
                            $update_participant['end_time'] = $end_time;
                            $params['user_id'];

                            $results = $this->api_model->update('participant', $update_participant, array('participant_id' => $params['user_id'], 'post_id' => $post_id));
                            $update_post['filename'] = base_url('uploads/recording/' . $params['user_id'] . '/' . $filename);

                            $result_update = $this->api_model->update('posts', $update_post, array('post_id' => $post_id));
                            if ($result_update) {
                                /** Collab request sung notification* */
                                for ($x = 0; $x < count($participant); $x++) {
                                    $participant_arr = $participant[$x];
                                    $to_id = $participant_arr['participant_id'];
                                    if ($to_id != $params['user_id']) {
                                        $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                                        $message2 = array();
                                        $message2['user_id'] = $params['user_id'];
                                        $message2['post_id'] = $post_id;
                                        $message2['user_avatar'] = getVal('avatar', 'users', 'user_id', $params['user_id']);
                                        $message2['user_name'] = getVal('name', 'users', 'user_id', $params['user_id']);
                                        $desc2 = $message2['user_name'] . " has sung there part";
                                        $this->send_notification($regIds, $message2, "A User has sung its part.", $desc2, $to_id, 1);
                                        $not_logs2['user_id'] = $to_id;
                                        $not_logs2['sender_id'] = $params['user_id'];
                                        $not_logs2['action'] = 'Collab Sung';
                                        $not_logs2['post_id'] = $post_id;
                                        $not_logs2['description'] = $desc2;
                                        $insert2 = $this->api_model->create('notifications_logs', $not_logs2);
                                    }
                                }
                                $post = $this->api_model->getPost($post_id);
                                foreach ($post as $key => $val) {
                                    $data[$key] = '||' . $val;
                                }

                                $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                                $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
                                $bar = $this->api_model->getBars($post_id);
                                $data['Bar '] = $bar;
                                $data['participant'] = $this->api_model->getparticipant($post_id);
                                $data['status'] = 1;
                                $data['message'] = 'Post  has been saved successfully.';
                                $this->makeLog($results, "post created", NULL, NULL, "Post has been saved successfully");
                                unset($data['recorded']);
                                unset($data['user_id']);
                            } else {
                                $data['status'] = 0;
                                $data['error'] = 401;
                                $data['message'] = 'Sorry failed to update recording';
                            }
                        } else {
                            $data['status'] = 0;
                            $data['error'] = 402;
                            $data['message'] = 'Sorry failed to Add participant';
                        }
                    } else {
                        $data['status'] = 0;
                        $data['error'] = 403;
                        $data['message'] = 'Sorry failed to create Post, Please try again later.';
                    }
                } else {
                    $data['status'] = 0;
                    $data['error'] = 404;
                    $data['message'] = 'Invalid Data provided.';
                }
            } else if ($params['post_id'] <> '' && !empty($participant) && $params['duration'] <> '') {

                $is_initiator = isset($params['is_initiator']) ? $params['is_initiator'] : "0";
                if ($is_initiator == 1) {
                    $start_time = "00:00:00";
                    $end_time = $duration;
                } else {

                    $participant_index = getValWithMultipleWhereClause('participant_index', 'participant', array('participant_id', 'post_id'), array($params['user_id'], $params['post_id']));
                    $start_time = $this->api_model->getLastRecordingDuration($params['post_id'], $participant_index);
                    $time2 = $params['duration'];
                    $secs = strtotime($time2) - strtotime("00:00:00");
                    $end_time = date("H:i:s", strtotime($start_time) + $secs);

                    unset($params['duration']);
                }


                for ($x = 0; $x < count($participant); $x++) {
                    $participantData = array();
                    $postparticipantData = array();
                    $participantData = $participant[$x];
                    $postparticipantData['participant_id'] = $participantData['participant_id'];
                    $postparticipantData['assign_bars'] = $participantData['assign_bars'];
                    $postparticipantData['participant_index'] = $participantData['participant_index'];
                    $postparticipantData['user_id'] = $params['user_id'];
                    $postparticipantData['post_id'] = $params['post_id'];
                    $postparticipantData['is_active'] = 1;
                    $postparticipantData['created'] = time();
                    $results = $this->api_model->create('participant', $postparticipantData);
                    if ($results > 0) {
                        $to_id = $participantData['participant_id'];
                        if ($to_id != $params['user_id']) {
                            $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                            $message = array();
                            $message['user_id'] = $params['user_id'];
                            $message['post_id'] = $params['post_id'];
                            $message['user_avatar'] = getVal('avatar', 'users', 'user_id', $params['user_id']);
                            $message['user_name'] = getVal('name', 'users', 'user_id', $params['user_id']);
                            $desc = $message['user_name'] . " has sent you a Collab Request.";
                            $this->send_notification($regIds, $message, "A User has sent you Collab Request.", $desc, $to_id, 1);
                            $not_logs['user_id'] = $to_id;
                            $not_logs['sender_id'] = $params['user_id'];
                            $not_logs['action'] = 'Collab Request';
                            $not_logs['post_id'] = $params['post_id'];
                            $not_logs['description'] = $desc;
                            $insert = $this->api_model->create('notifications_logs', $not_logs);
                        }
                    }
                }
                if ($results > 0) {
                    $update_participant['recorded'] = 1;
                    $update_participant['is_initiator'] = 0;
                    $update_participant['start_time'] = $start_time;
                    $update_participant['end_time'] = $end_time;
                    $results_update = $this->api_model->update('participant', $update_participant, array('participant_id' => $params['user_id'], 'post_id' => $params['post_id']));
                    $user_id = getVal('user_id', 'posts', 'post_id', $params['post_id']);
                    $update_post['filename'] = base_url('uploads/recording/' . $user_id . '/' . $filename);


                    $result_update = $this->api_model->update('posts', $update_post, array('post_id' => $params['post_id']));
                    if ($result_update) {
                        /** Collab request sung notification* */
                        for ($x = 0; $x < count($participant); $x++) {
                            $participant_arr = $participant[$x];
                            $to_id = $participant_arr['participant_id'];
                            if ($to_id != $params['user_id']) {
                                $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                                $message2 = array();
                                $message2['user_id'] = $params['user_id'];
                                $message2['post_id'] = $params['post_id'];
                                $message2['user_avatar'] = getVal('avatar', 'users', 'user_id', $params['user_id']);
                                $message2['user_name'] = getVal('name', 'users', 'user_id', $params['user_id']);
                                $desc2 = $message2['user_name'] . " has sung there part";
                                $this->send_notification($regIds, $message2, "A User has sung its part.", $desc2, $to_id, 1);
                                $not_logs2['user_id'] = $to_id;
                                $not_logs2['sender_id'] = $params['user_id'];
                                $not_logs2['post_id'] = $params['post_id'];
                                $not_logs2['action'] = 'Collab Sung';
                                $not_logs2['description'] = $desc2;
                                $insert2 = $this->api_model->create('notifications_logs', $not_logs2);
                            }
                        }

                        $post = $this->api_model->getPost($params['post_id']);
                        foreach ($post as $key => $val) {
                            $data[$key] = '||' . $val;
                        }

                        $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                        $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
                        $bar = $this->api_model->getBars($params['post_id']);
                        $data['Bar'] = $bar;
                        $data['participant'] = $this->api_model->getparticipant($params['post_id']);
                        $data['status'] = 1;
                        $data['message'] = 'Post  has been saved successfully.';
                        $this->makeLog($results, "post created", NULL, NULL, "Post has been saved successfully");
                        unset($data['recorded']);
                        unset($data['user_id']);
                    } else {
                        $data['status'] = 0;
                        $data['error'] = 401;
                        $data['message'] = 'Sorry failed to update recording';
                    }
                } else {
                    $data['status'] = 0;
                    $data['error'] = 403;
                    $data['message'] = 'Sorry failed to Add Participant.';
                }
            } else if ($params['post_id'] <> '' && empty($participant) && $params['duration'] <> '') {

                $is_initiator = isset($params['is_initiator']) ? $params['is_initiator'] : "0";
                if ($is_initiator == 1) {
                    $start_time = "00:00:00";
                    $end_time = $duration;
                } else {
                    $participant_index = getValWithMultipleWhereClause('participant_index', 'participant', array('participant_id', 'post_id'), array($params['user_id'], $params['post_id']));

                    $start_time = $this->api_model->getLastRecordingDuration($params['post_id'], $participant_index);

                    $time2 = $params['duration'];
                    $secs = strtotime($time2) - strtotime("00:00:00");
                    $end_time = date("H:i:s", strtotime($start_time) + $secs);
                }


                $update_participant['recorded'] = 1;
                $update_participant['is_initiator'] = $is_initiator;
                $update_participant['start_time'] = $start_time;
                $update_participant['end_time'] = $end_time;
                $results = $this->api_model->update('participant', $update_participant, array('participant_id' => $params['user_id'], 'post_id' => $params['post_id']));
                $user_id = getVal('user_id', 'posts', 'post_id', $params['post_id']);
                $update_post['filename'] = base_url('uploads/recording/' . $user_id . '/' . $filename);

                $result_update = $this->api_model->update('posts', $update_post, array('post_id' => $params['post_id']));
                if ($result_update) {
                    $participants = $this->api_model->getparticipant($params['post_id']);
                    foreach ($participants as $participant) {
                        $to_id = $participant['participant_id'];
                        if ($to_id != $params['user_id']) {
                            $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                            $message2 = array();
                            $message2['user_id'] = $params['user_id'];
                            $message2['post_id'] = $params['post_id'];
                            $message2['user_avatar'] = getVal('avatar', 'users', 'user_id', $params['user_id']);
                            $message2['user_name'] = getVal('name', 'users', 'user_id', $params['user_id']);
                            $desc2 = $message2['user_name'] . " has sung there part";
                            $this->send_notification($regIds, $message2, "A User has sung its part.", $desc2, $to_id, 1);
                            $not_logs2['user_id'] = $to_id;
                            $not_logs2['sender_id'] = $params['user_id'];
                            $not_logs2['post_id'] = $params['post_id'];
                            $not_logs2['action'] = 'Collab Sung';
                            $not_logs2['description'] = $desc2;
                            $insert2 = $this->api_model->create('notifications_logs', $not_logs2);
                        }
                    }
                    $post = $this->api_model->getPost($params['post_id']);
                    foreach ($post as $key => $val) {
                        $data[$key] = '||' . $val;
                    }

                    $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                    $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
                    $bar = $this->api_model->getBars($params['post_id']);
                    $data['Bar '] = $bar;
                    $data['participant'] = $this->api_model->getparticipant($params['post_id']);
                    $data['status'] = 1;
                    $data['message'] = 'Post  has been saved successfully.';
                    $this->makeLog($results, "post created", NULL, NULL, "Post has been saved successfully");
                    unset($data['recorded']);
                    unset($data['user_id']);
                } else {
                    $data['status'] = 0;
                    $data['error'] = 401;
                    $data['message'] = 'Sorry failed to update recording';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 404;
                $data['message'] = 'Sorry Invalid data provided';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Sorry Invalid data provided';
        }

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	  /* * *
     * Method: postDetails
     * params: Posted Data $post
     * Return: Json
     */

	 
    function postDetails() {
        $data = array();
        $post_data = array();
        $bar = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if (($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) && ($_POST['post_id'] <> '' || $_POST['post_id'] <> 0)) {

            $post = $this->api_model->getPost($_POST['post_id']);
            foreach ($post as $key => $val) {

                $data[$key] = $val;
            }
            $data['share_message'] = "Lorem ipsum dolor sit amet";
            $data['share_url'] = "http://tagalongmusic.com";
            $data['initiator_id'] = getVal('user_id', 'posts', 'post_id', $_POST['post_id']);
            $data['post_image'] = getVal('post_avatar', 'posts', 'post_id', $_POST['post_id']);
            $data['initiator_id'] = getVal('user_id', 'posts', 'post_id', $_POST['post_id']);
            $data['post_image'] = getVal('post_avatar', 'posts', 'post_id', $_POST['post_id']);
            $data['audio_url'] = getVal('filename', 'posts', 'post_id', $_POST['post_id']);
            $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
            $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
            $data['participant'] = $this->api_model->getParticipantDetails($_POST['post_id']);
            if ($post['post_type'] == 1) {
                $bar = $this->api_model->getBars($_POST['post_id']);
                $data['bars'] = $bar;
            } else {
                $bar['user_id'] = $post['user_id'];
                $bar['name'] = getVal('name', 'users', 'user_id', $post['user_id']);
                $bar['photo_url'] = getVal('avatar', 'users', 'user_id', $post['user_id']);
                $bar['bar_length'] = getVal('b_length', 'setting', 'id', '1');
                $bar['recorded'] = $data['recorded'];
                $data['bar'] = $bar;
            }
            $data['audio_url'] = getVal('filename', 'posts', 'post_id', $_POST['post_id']);
            $data['status'] = 1;
            $this->makeLog($data, "post received", NULL, NULL, "Post received successfully");
            unset($data['recorded']);
            unset($data['user_id']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: addParticipant
     * params: Posted Data $post
     * Return: Json
     */
	 
    function addParticipant() {
        $data = array();
        $post_data = array();
        $bar = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if (($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) && ($_POST['post_id'] <> '' || $_POST['post_id'] <> 0) && ($_POST['participant_id'] <> '' || $_POST['participant_id'] <> 0) && ($_POST['assign_bars'] <> '' || $_POST['assign_bars'] <> 0)) {

            $this->exitIfInactive($_POST['participant_id']);
            $assign_bars = $_POST['assign_bars'];
            $post = $this->api_model->getPost($_POST['post_id']);

            if ($this->api_model->verifyParticipant($_POST['post_id'], $_POST['participant_id']) == 0) {
                $data['status'] = 0;
                $data['message'] = 'Sorry Participant already exists.';
                $this->makeLog($_POST['participant'], "Add Participent failed", NULL, NULL, "Add Participent failed, Participant already exits");
                header('Content-Type: application/json');
                echo json_encode($data, JSON_NUMERIC_CHECK);
                exit;
            } else if ($assign_bars > $post['bar_count']) {
                $data['status'] = 0;
                $data['message'] = 'Sorry failed to add Participent, Assign bar is greater then bar count.';
                $this->makeLog($_POST['participant'], "Add Participent failed", NULL, NULL, "Add Participent failed, asssign bar is greater then bar count");
                header('Content-Type: application/json');
                echo json_encode($data, JSON_NUMERIC_CHECK);
                exit;
            }

            if ($this->api_model->is_follow($_POST['user_id'], $_POST['participant_id']) == 1) {

                if ($this->api_model->is_locked($_POST['post_id']) == 1) {
                    foreach ($_POST as $k => $v) {
                        $post_data[$k] = $v;
                    }
                    $post_data['is_active'] = 1;
                    $post_data['created'] = time();
                    $results = $this->api_model->create('participant', $post_data);
                    if ($results) {
                        foreach ($post as $key => $val) {
                            $data[$key] = '||' . $val;
                        }

                        $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                        $data['assignable_bars'] = get_assignable_bars($post['bar_count']);
                        $bar = $this->api_model->getBars($_POST['post_id']);
                        $data['bars'] = $bar['bar'];
                        $data['status'] = 1;
                        $data['message'] = 'participant  has been saved successfully.';
                        $this->makeLog($results, "Participant created", NULL, NULL, "Participant has been saved successfully");
                        unset($data['recorded']);
                        unset($data['user_id']);
                    } else {
                        $data['status'] = 0;
                        $data['error'] = 402;
                        $data['message'] = 'Failed to add participant , Please try again.';
                    }
                } else {
                    $data['status'] = 0;
                    $data['error'] = 402;
                    $data['message'] = 'Sorry Failed to add participant ,This post is locked.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 402;
                $data['message'] = 'Sorry Failed to add participant ,This participant does not follow you.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: followUser
     * params: Posted Data $post
     * Return: Json
     */
	 
    function followUser() {
        $data_post = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $follow = getValWithMultipleWhereClause('follow', 'follower', array('follower_user_id', 'following_user_id'), array($_POST['my_id'], $_POST['user_id']));
            if ($follow == $_POST['follow']) {
                $data['status'] = 0;
                $data['error'] = 401;
                $data['message'] = 'Sorry you are following same person';
                header('Content-Type: application/json');
                echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
                exit;
            }
            $data_post['follower_user_id'] = $_POST['my_id'];
            $data_post['following_user_id'] = $_POST['user_id'];
            $data_post['follow'] = $_POST['follow'];
            if ($_POST['follow'] == 1) {
                $results = $this->api_model->create('follower', $data_post);
            } else if ($_POST['follow'] == 0) {
                unset($data_post['follow']);
                $results = $this->api_model->delete('follower', $data_post);
            }
            if ($results > 0) {
                $data['status'] = 1;
                $following_name = getVal('name', 'users', 'user_id', $_POST['user_id']);
                if ($_POST['follow'] == 1) {
                    $to_id = $_POST['user_id'];
                    $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                    $message = array();
                    $message['user_id'] = $_POST['my_id'];
                    $message['user_avatar'] = getVal('avatar', 'users', 'user_id', $_POST['my_id']);
                    $message['user_name'] = getVal('name', 'users', 'user_id', $_POST['my_id']);

                    $desc = $message['user_name'] . " has Follow you.";
                    $this->send_notification($regIds, $message, "A User has Follow you.", $desc, $to_id, 1);
                    $not_logs['user_id'] = $to_id;
                    $not_logs['sender_id'] = $_POST['my_id'];
                    $not_logs['action'] = 'Follow';
                    $not_logs['description'] = $desc;
                    $insert = $this->api_model->create('notifications_logs', $not_logs);
                    $data['message'] = 'Thanks for following,  ' . $following_name . '.';
                    $data['is_following'] = 1;
                } else {
                    $data['message'] = $following_name . ' ' . 'removed from your follower list';
                    $data['is_following'] = 0;
                }
                $this->makeLog($results, "data created", NULL, NULL, "data has been saved successfully");
            } else {
                $data['status'] = 0;
                $data['error'] = 402;
                $data['message'] = 'Sorry Failed to add or delete data';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: discover
     * params: Posted Data $post
     * Return: Json
     */
	 
	 
    function discover() {
        $data = array();
        $track = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if (($_POST['type'] <> '' || $_POST['type'] <> 0)) {
            $post = $this->api_model->getTrack($_POST['type'], $_POST['index'], $_POST['count'], $_POST['my_id']);
            for ($x = 0; $x <= count($post); $x++) {
                unset($post[$x]['type']);
            }
            $data['track'] = $post;
            $data['status'] = 1;
            $this->makeLog($data, "post received", NULL, NULL, "Post received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: discover
     * params: Posted Data $post
     * Return: Json
     */
	 
	
    function profile() {
        $data = array();
        $recentPosts = array();
        $recentCollabs = array();
        $recentPostLikes = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {

            $user = $this->api_model->get_user_data($_POST['user_id']);

            unset($user['user_id'], $user['email'], $user['phone_no'], $user['is_verified']);
            foreach ($user as $key => $val) {
                $data[$key] = '||' . $val;
            }

            $data['no_of_posts'] = $this->api_model->totalPosts($_POST['user_id']);
            $data['no_of_following'] = getCount('following_user_id', 'no_of_following', 'follower', 'follower_user_id', $_POST['user_id']);
            $data['no_of_followers'] = getCount('following_user_id', 'no_of_followers', 'follower', 'following_user_id', $_POST['user_id']);
            $recentPosts = $this->api_model->recentPosts($_POST['user_id'], $_POST['my_id']);
            if (count($recentPosts) > 0)
                $data['posts'] = $recentPosts['posts'];
            else
                $data['posts'] = array();
            $recentCollabs = $this->api_model->recentCollabs($_POST['user_id'], $_POST['my_id']);
            if (count($recentCollabs) > 0)
                $data['collabs'] = $recentCollabs['collabs'];
            else
                $data['collabs'] = array();

            $recentPostLikes = $this->api_model->recentPostLikes($_POST['user_id'], $_POST['my_id']);
            if (count($recentCollabs) > 0)
                $data['likes'] = $recentPostLikes['likes'];
            else
                $data['likes'] = array();

            if ($_POST['user_id'] == $_POST['my_id']) {
                $draft = $this->api_model->draftPosts($_POST['user_id'], $_POST['my_id']);
                if (count($draft) > 0)
                    $data['draft'] = $draft;
                else
                    $data['draft'] = array();
            }
            if ($_POST['user_id'] == $_POST['my_id'])
                $data['is_following'] = 0;
            else
                $data['is_following'] = $this->api_model->userfollowing($_POST['my_id'], $_POST['user_id']);


            $data['status'] = 1;
            $this->makeLog($data, "Profile received", NULL, NULL, "Profile received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: posts
     * params: Posted Data $post
     * Return: Json
     */
	 
    function posts() {
        $data = array();
        $recentPosts = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $recentPosts = $this->api_model->recentPosts($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);
            if (count($recentPosts) > 0) {
                $data['posts'] = $recentPosts['posts'];
                for ($x = 0; $x < count($data['posts']); $x++) {
                    unset($data['posts'][$x]['post_description']);
                }
            } else {
                $data['posts'] = array();
            }
            $data['status'] = 1;
            $this->makeLog($data, "recent Post received", NULL, NULL, "Top Recent Post received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: collabs
     * params: Posted Data $post
     * Return: Json
     */
	 
    function collabs() {
        $data = array();
        $recentCollabs = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $recentCollabs = $this->api_model->recentCollabs($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);
            if (count($recentCollabs) > 0) {
                $data['collabs'] = $recentCollabs['collabs'];
                for ($x = 0; $x < count($data['collabs']); $x++) {
                    unset($data['collabs'][$x]['post_description']);
                }
            } else {
                $data['collabs'] = array();
            }
            $data['status'] = 1;
            $this->makeLog($data, "recent collabs received", NULL, NULL, "Top Recent collabs received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	/* * *
     * Method: likes
     * params: Posted Data $post
     * Return: Json
     */
	 
    function likes() {
        $data = array();
        $recentPostLikes = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $recentPostLikes = $this->api_model->recentPostLikes($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);
            if (count($recentPostLikes) > 0) {
                $data['likes'] = $recentPostLikes['likes'];
                for ($x = 0; $x < count($data['likes']); $x++) {
                    unset($data['likes'][$x]['post_description']);
                }
            } else {
                $data['likes'] = array();
            }
            $data['status'] = 1;
            $this->makeLog($data, "recent likes received", NULL, NULL, "Top Recent Likes received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: is_locked
     * params: Posted Data $post
     * Return: Json
     */
	 
    function is_locked() {
        $data = array();
        $up = $this->api_model->post_locked();
        if ($up == 1) {
            $data['status'] = 1;
            $data['message'] = "posts locked sucessfully";
        } else {
            $data['status'] = 0;
            $data['message'] = "Failed to locked sucessfully";
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: uploadRecording
     * params: Posted Data $post
     * Return: Json
     */
	 
    function uploadRecording() {
        $data = array();
        $old_record = array();
        $post_data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_FILES['recording']['name'] != '') {
            $user_id = $_POST['user_id'];
            $post_id = $_POST['post_id'];
            $old_record = getValArray('filename,post_type,is_locked', 'posts', 'post_id', $post_id);
            if ($old_record['is_locked'] == 1) {

                $verify = $this->api_model->verifyUserUploading($user_id, $post_id, $old_record['post_type']);

                if ($verify == 0) {
                    $old_file = end(explode('/', $old_record['filename']));
                    $extension = $this->common->getExtension($_FILES ['recording'] ['name']);
                    $extension = strtolower($extension);
                    if ($extension != "mp3") {
                        return false;
                    }
                    $path = 'uploads/recording/';
                    $allow_types = 'mp3';
                    $filename = $this->common->uploadRecord_mp3($path, $allow_types, $_FILES ['recording']['tmp_name'], $_FILES ['recording']['name'], $old_file);
                    $post_data['filename'] = base_url('uploads/recording/' . $filename);

                    if ($old_record['post_type'] == 0) {
                        $post_data['recorded'] = 1;
                    } else {
                        $participant_data['recorded'] = 1;
                        $results = $this->api_model->update('participant', $participant_data, array('participant_id' => $user_id, 'post_id' => $post_id));
                    }

                    $results = $this->api_model->update('posts', $post_data, array('post_id' => $post_id));
                    if ($results) {
                        unlink('uploads/recording/' . $old_file);
                        $data['recoding'] = $filename;
                        $post = $this->api_model->getPost($post_id);
                        foreach ($post as $key => $val) {
                            $data[$key] = '||' . $val;
                        }
                        $data['can_invite'] = $post['post_type'] == 1 ? "true" : "false";
                        $data['assignable_bars'] = get_assignable_bars($post['bar_count']);

                        if ($post['post_type'] == 1) {
                            $bar = $this->api_model->getBars($post_id);
                            $data['bars'] = $bar['bar'];
                        } else {
                            $bar['user_id'] = $post['user_id'];
                            $bar['name'] = getVal('name', 'users', 'user_id', $post['user_id']);
                            $bar['photo_url'] = getVal('avatar', 'users', 'user_id', $post['user_id']);
                            $bar['bar_length'] = getVal('b_length', 'setting', 'id', '1');
                            $bar['recorded'] = $data['recorded'];
                            $data['bar'] = $bar;
                        }
                        $data['status'] = 1;
                        $this->makeLog($_POST['user_id'], "Update recording", NULL, NULL, "User has updated recording.");
                        unset($data['recorded']);
                        unset($data['user_id']);
                    } else {
                        $data['status'] = 0;
                        $data['error'] = 402;
                        $data['message'] = 'Sorry failed to upload Recording, Please try again later.';
                    }
                } else if ($verify == -1) {
                    $data['status'] = 0;
                    $data['error'] = 403;
                    $data['message'] = 'Sorry you are not allowed to upload Recording';
                } else {
                    $data['status'] = 0;
                    $data['error'] = 403;
                    $data['message'] = 'Sorry failed to upload Recording, you already uploaded.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 403;
                $data['message'] = 'Sorry failed to upload Recording, post is not locked';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: premiumplans
     * params: Posted Data $post
     * Return: Json
     */
	 
    function premiumplans() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['plans'] = $this->api_model->getPremiumPlans();
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: tokenplans
     * params: Posted Data $post
     * Return: Json
     */
    function tokenplans() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['plans'] = $this->api_model->gettokenPlans();
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: buypremium
     * params: Posted Data $post
     * Return: Json
     */
	 
    function buypremium() {

        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['plan_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $post_data = array();
            $post_data['user_id'] = $_POST['user_id'];
            $post_data['plan_id'] = $_POST['plan_id'];
            $post_data['created_date'] = date('Y-m-d H:i:s');
            $insert_id = $this->api_model->create("premium_history", $post_data);
            if ($insert_id > 0) {
                $update_data = array();
                $update_data['is_premium'] = 1;
                $result = $this->api_model->update('users', $update_data, array('user_id' => $_POST['user_id']));
                $data['plans'] = getValArray('plan_id,months,price', 'premium_plans', 'plan_id', $post_data['plan_id']);
                $data['is_premium '] = getVal('is_premium', 'users', 'user_id', $post_data['user_id']);
                $data['message'] = 'Congratulation you successfully purchased Premium Plan.';
                $data['status'] = 1;
                $this->makeLog($_POST['user_id'], "Premium plan purchased", NULL, "successfully purchased Premium plan");
            } else {
                $data['status'] = 0;
                $data['error'] = 402;
                $data['message'] = 'Sorry failed to purchased Premium Plan.';
                $this->makeLog($_POST['user_id'], "Premium Plan purchased Failed", NULL, "Failed to purchased Premium Plan");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: getusers
     * params: Posted Data $post
     * Return: Json
     */
	 
    function getusers() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['users'] = $this->api_model->getusers($_POST['user_id'], $_POST['index'], $_POST['count']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: searchuser
     * params: Posted Data $post
     * Return: Json
     */
	 
    function searchuser() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        $this->exitIfInactive($_POST['user_id']);
        if ($_POST['user_id'] <> '') {
            $data['status'] = 1;
            $data['users'] = $this->api_model->searchUsers($_POST['user_id'], $_POST['searchtext']);
            $this->makeLog($_POST['user_id'], "Search users", NULL, NULL, "User Searched: " . $_POST['query']);
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/* * *
     * Method: feeds
     * params: Posted Data $post
     * Return: Json
     */
	 
    function feeds() {
        $data = array();
        $track = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if (($_POST['type'] <> '' || $_POST['type'] <> 0)) {
            $post = $this->api_model->getTrack($_POST['type'], $_POST['index'], $_POST['count'], $_POST['my_id']);
            for ($x = 0; $x <= count($post); $x++) {
                unset($post[$x]['type']);
            }
            $data['track'] = $post;
            $data['status'] = 1;
            $this->makeLog($data, "post received", NULL, NULL, "Post received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: changepassword
     * params: Posted Data $post
     * Return: Json
     */
	 
    function changepassword() {
        $data = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['my_id'] <> '' && $_POST['my_id'] <> '') {
            $this->exitIfInactive($_POST['my_id']);
            $post_data = array();
            $post_data['password'] = md5($_POST['newpassword']);
            $cond = array();
            $cond['user_id'] = $_POST['my_id'];
            $cond['password'] = trim(md5($_POST['oldpassword']));

            $old_password = getVal('password', 'users', 'user_id', $_POST['my_id']);
            if ($old_password == trim(md5($_POST['oldpassword']))) {
                $update = $this->api_model->update('users', $post_data, $cond);
                if ($update > 0) {
                    $data['status'] = 1;
                    $data['message'] = 'The password has been updated successfully';
                    $this->makeLog($_POST['user_id'], "Update Skill", NULL, NULL, "User has updated skill");
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to update skill.';
                    $this->makeLog($_POST['user_id'], "Sorry password is not updated!");
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 403;
                $data['message'] = 'Sorry old password is incorrect.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: alltracks
     * params: Posted Data $post
     * Return: Json
     */
	 
    function alltracks() {
        $data = array();
        $track = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        $post = $this->api_model->getallTrack($_POST['index'], $_POST['count'], $_POST['my_id']);
        if (($post > 0)) {
            $data['track'] = $post;

            $data['status'] = 1;
            $this->makeLog($data, "All Track received", NULL, NULL, "All Track received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: addfavourite
     * params: Posted Data $post
     * Return: Json
     */
	 
    function addfavourite() {
        $data = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['my_id'] <> '' && $_POST['post_id'] <> '' && $_POST['addfavourite'] <> '') {
            $this->exitIfInactive($_POST['my_id']);
            $result = $this->api_model->isPostAlreadyLiked($_POST['my_id'], $_POST['post_id']);
            if ($result == 1) {
                if ($_POST['addfavourite'] == 1) {
                    $data['message'] = "post is already liked";
                    $this->makeLog($_POST['my_id'], 'Like post', NULL, $_POST['guru_id'], "User has already liked post");
                } else {
                    $post_like = array();
                    $post_like['user_id'] = $_POST['my_id'];
                    $post_like['post_id'] = $_POST['post_id'];
                    $del = $this->api_model->delete('post_likes', $post_like);
                    if ($del > 0) {

                        $this->makeLog($_POST['user_id'], 'Dislike post', NULL, $_POST['guru_id'], "User has disliked post");
                        $data['message'] = "post is disliked";
                    } else {
                        $this->makeLog($_POST['user_id'], 'Failed to dislike post', NULL, $_POST['guru_id'], "User has failed to dislike post");
                        $data['message'] = "post can't be disliked at this moment";
                    }
                }
            } else {
                if ($_POST['addfavourite'] == 1) {
                    $post_like = array();
                    $post_like['user_id'] = $_POST['my_id'];
                    $post_like['post_id'] = $_POST['post_id'];
                    $ins = $this->api_model->create('post_likes', $post_like);
                    if ($ins > 0) {

						$this->makeLog($_POST['my_id'], 'Like post', NULL, $_POST['guru_id'], "User has liked post");

                        $data['message'] = "post is liked";
                    } else {
                        $this->makeLog($_POST['my_id'], 'Failed to like guru', NULL, $_POST['guru_id'], "User failed to like  guru");

                        $data['message'] = "post can't be liked at this moment";
                    }
                } else {
                    $this->makeLog($_POST['my_id'], 'Failed to like guru', NULL, $_POST['my_id'], "User failed to like  guru");

                    $data['message'] = "post is already not liked";
                }
            }
            $data['status'] = 1;

        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	/* * *
     * Method: followers
     * params: Posted Data $post
     * Return: Json
     */

    function followers() {
        $data = array();
        $followers = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        $followers = $this->api_model->getAllFollowers($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);
        if (($followers > 0)) {
            $data['followers'] = $followers;
            $data['status'] = 1;
            $this->makeLog($data, "follower", NULL, NULL, "All follower list");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: following
     * params: Posted Data $post
     * Return: Json
     */
	 
    function following() {

        $data = array();
        $following = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        $following = $this->api_model->getAllFollollowing($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);
        if (($following > 0)) {
            $data['following'] = $following;
            $data['status'] = 1;
            $this->makeLog($data, "following", NULL, NULL, "All following list");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: likePost
     * params: Posted Data $post
     * Return: Json
     */
    function likePost() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['post_id'] <> '' && $_POST['like_post'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $total_like = getVal('total_like', 'posts', 'post_id', $_POST['post_id']);
            $result = $this->api_model->isPostAlreadyLiked($_POST['user_id'], $_POST['post_id']);
            if ($result == 1) {
                if ($_POST['like_post'] == 1) {
                    $data['message'] = "Post is already liked";
                    $this->makeLog($_POST['user_id'], 'Like post', NULL, $_POST['guru_id'], "User has already liked post");
                } else {
                    $post_like = array();
                    $post_like['post_id'] = $_POST['post_id'];
                    $post_like['user_id'] = $_POST['user_id'];
                    $del = $this->api_model->delete('post_likes', $post_like);
                    if ($del > 0) {
                        $post_data = array();
                        $post_data['total_like'] = $total_like - 1;
                        $cond = array();
                        $cond['post_id'] = $_POST['post_id'];
                        $update = $this->api_model->update('posts', $post_data, $cond);
                        $this->makeLog($_POST['user_id'], 'Dislike post', NULL, $_POST['guru_id'], "User has disliked post");
                        $data['message'] = "Post is disliked";
                    } else {
                        $this->makeLog($_POST['user_id'], 'Failed to dislike post', NULL, $_POST['guru_id'], "User has failed to dislike post");
                        $data['message'] = "post can't be disliked at this moment";
                    }
                }
            } else {
                if ($_POST['like_post'] == 1) {

                    $post_like['post_id'] = $_POST['post_id'];
                    $post_like['user_id'] = $_POST['user_id'];
                    $ins = $this->api_model->create('post_likes', $post_like);
                    if ($ins > 0) {
                        $post_data = array();
                        $post_data['total_like'] = $total_like + 1;
                        $cond = array();
                        $cond['post_id'] = $_POST['post_id'];
                        $update = $this->api_model->update('posts', $post_data, $cond);
                        $to_id = getVal('user_id', 'posts', 'post_id', $_POST['post_id']);

                        $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);

                        $message = array();
                        $message['user_id'] = $_POST['user_id'];
                        $message['user_avatar'] = getVal('avatar', 'users', 'user_id', $_POST['user_id']);
                        $message['user_name'] = getVal('name', 'users', 'user_id', $_POST['user_id']);
                        $message['post_id'] = $_POST['post_id'];
                        $desc = $message['user_name'] . " has liked your Post.";
                        $this->send_notification($regIds, $message, "A User has liked you Post.", $desc, $to_id, 1);
                        $not_logs['user_id'] = $to_id;
                        $not_logs['sender_id'] = $_POST['user_id'];
                        $not_logs['post_id'] = $_POST['post_id'];
                        $not_logs['action'] = 'Like';
                        $not_logs['description'] = $desc;
                        $insert = $this->api_model->create('notifications_logs', $not_logs);


                        $this->makeLog($_POST['user_id'], 'Like post', NULL, $_POST['post_id'], "User has liked post");

                        $data['message'] = "Post is liked";
                    } else {
                        $this->makeLog($_POST['user_id'], 'Failed to like post', NULL, $_POST['post_id'], "User failed to like  post");

                        $data['message'] = "Post can't be liked at this moment";
                    }
                } else {
                    $this->makeLog($_POST['user_id'], 'Failed to like guru', NULL, $_POST['post_id'], "User failed to like  post");

                    $data['message'] = "Post is already not liked";
                }
            }
            $data['status'] = 1;

        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/* * *
     * Method: publishPost
     * params: Posted Data $post
     * Return: Json
     */

    function publishPost() {

        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['post_id'] <> '') {
            $user_id = getVal('user_id', 'posts', 'post_id', $_POST['post_id']);
            if ($user_id == $_POST['user_id']) {
                $this->exitIfInactive($_POST['user_id']);
                $post_data = array();
                $post_data['is_locked'] = 1;
                $post_data['publish'] = date('Y-m-d');
                $cond = array();
                $cond['user_id'] = $_POST['user_id'];
                $cond['post_id'] = $_POST['post_id'];
                $update = $this->api_model->update('posts', $post_data, $cond);

                if ($update > 0) {


                    $post_type = getVal('post_type', 'posts', 'post_id', $_POST['post_id']);
                    if ($post_type == 1) {
                        $delete_data = array();
                        $delete_data[0]['post_id'] = $_POST['post_id'];
                        $delete_data[1]['recorded'] = 0;
                        $result = $this->api_model->multiple_where_delete('participant', $delete_data);
                        $participants = $this->api_model->getAllParticipant($_POST['post_id']);

                        for ($x = 0; $x < count($participants); $x++) {

                            if ($participants[$x]['participant_id'] != $_POST['user_id']) {
                                $to_id = $participants[$x]['participant_id'];
                                $regIds = $this->api_model->getFirebaseRegistrationIds($to_id);
                                $message = array();
                                $message['user_id'] = $_POST['user_id'];
                                $message['user_avatar'] = getVal('avatar', 'users', 'user_id', $_POST['user_id']);
                                $message['user_name'] = getVal('name', 'users', 'user_id', $_POST['user_id']);
                                $message['post_id'] = $_POST['post_id'];
                                $desc = $message['user_name'] . " has Publish Post.";
                                $this->send_notification($regIds, $message, "A User has Publish Post.", $desc, $to_id, 1);
                                $not_logs['user_id'] = $to_id;
                                $not_logs['sender_id'] = $_POST['user_id'];
                                $not_logs['post_id'] = $_POST['post_id'];
                                $not_logs['action'] = 'Post Publish';
                                $not_logs['description'] = $desc;
                                $insert = $this->api_model->create('notifications_logs', $not_logs);
                            }
                        }
                    }

                    $data['status'] = 1;
                    $data['message'] = 'Post has been Locked successfully';
                    $this->makeLog($_POST['post_id'], "Post Locked", NULL, NULL, "Post  has been locked");
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to lock post.';
                    $this->makeLog($_POST['post_id'], "Post Lock", NULL, NULL, "Failded to lock post");
                }
            } else {
                $data['status'] = 0;
                $data['message'] = 'Sorry you are not allowed to lock Post.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: deletePost
     * params: Posted Data $post
     * Return: Json
     */
	 
    function deletePost() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['post_id'] <> '') {
            $user_id = getVal('user_id', 'posts', 'post_id', $_POST['post_id']);
            if ($user_id == $_POST['user_id']) {
                $this->exitIfInactive($_POST['user_id']);
                $old_file = getVal('filename', 'posts', 'post_id', $_POST['post_id']);
                $old_file = explode('/', $old_file);
                $old_file = end($old_file);
                unlink('uploads/recording/' . $_POST['user_id'] . '/' . $old_file);


                $result = $this->api_model->delete('posts', array('post_id' => $_POST['post_id']));
                if ($result) {
                    $result = $this->api_model->delete('participant', array('post_id' => $_POST['post_id']));
                    $data['status'] = 1;
                    $data['message'] = 'Post has been deleted successfully';
                    $this->makeLog($_POST['post_id'], "Post Locked", NULL, NULL, "Post  has been deleted");
                } else {
                    $data['status'] = 0;
                    $data['message'] = 'Failed to delete post.';
                    $this->makeLog($_POST['post_id'], "Post Lock", NULL, NULL, "Failded to delete post");
                }
            } else {
                $data['status'] = 0;
                $data['message'] = 'Sorry you are not allowed to delete Post.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	/* * *
     * Method: draftPost
     * params: Posted Data $post
     * Return: Json
     */
    function draftPost() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '' && $_POST['track_id'] <> '' && $_POST['title'] <> '' && $_POST['bar_count'] <> '' && ($_FILES['recording']['name'] <> '')) {
            $this->exitIfInactive($_POST['user_id']);
            $extension = $this->common->getExtension($_FILES ['recording'] ['name']);
            $extension = strtolower($extension);

            $path = 'uploads/draft_post/';
            //$filename = $this->common->uploadRecording($path, $allow_types = "mp3", $_FILES ['recording']['tmp_name'], $_FILES ['recording']['name']);
            $filename = $this->common->uploadRecord_mp3($path, $extension, $_FILES['recording']['tmp_name'], $_FILES['recording']['name']);

            $post_data['avatar'] = $photo = base_url('uploads/users/avatar/medium/' . $avatar);
            $draft_post = array();
            $draft_post['user_id'] = $_POST['user_id'];
            $draft_post['track_id'] = $_POST['track_id'];
            $draft_post['title'] = $_POST['title'];
            $draft_post['bar_count'] = $_POST['bar_count'];
            $draft_post['post_recording'] = base_url('uploads/draft_post/' . $filename);
            $draft_post['is_active'] = 1;

            $post_id = $this->api_model->create('draftPost', $draft_post);
            if ($post_id > 0) {
                $data['status'] = 1;
                $data['post_id'] = $post_id;
                $this->makeLog($_POST['user_id'], 'Draft Post', NULL, $post_id, "draft post created successfully");
            } else {
                $data['status'] = 0;
                $data['error'] = 402;
                $this->makeLog($_POST['user_id'], 'Failed to create draft', NULL, NULL, "User failed to create draft");
                $data['message'] = "Sorry Draft post can't be created";
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: drafts
     * params: Posted Data $post
     * Return: Json
     */
	 
    function drafts() {
        $data = array();
        $draftPosts = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $draftPosts = $this->api_model->draftPosts($_POST['user_id'], $_POST['my_id'], $_POST['index'], $_POST['count']);

            if (count($draftPosts) > 0)
                $data['drafts'] = $draftPosts;
            else
                $data['drafts'] = array();
            $data['status'] = 1;
            $this->makeLog($data, "Draft Post received", NULL, NULL, "Draft Post received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: postPlayed
     * params: Posted Data $post
     * Return: Json
     */
	 
    function postPlayed() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['post_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $total_played = getVal('total_playes', 'posts', 'post_id', $_POST['post_id']);

            $post_data = array();
            $post_data['total_playes'] = $total_played + 1;
            $cond = array();
            $cond['post_id'] = $_POST['post_id'];
            $update = $this->api_model->update('posts', $post_data, $cond);
            if ($update) {
                $this->makeLog($_POST['user_id'], 'Played Post', NULL, $_POST['post_id'], "User has played post");
                $data['message'] = "Post is Played";
                $data['status'] = 1;
            } else {
                $data['error'] = 402;
                $data['message'] = "Sorry Failed to increase played count";
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: usersForTag
     * params: Posted Data $post
     * Return: Json
     */
	 
    function usersForTag() {
        $data = array();

        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $users = $this->api_model->usersForTag($_POST['user_id'], $_POST['index'], $_POST['count']);
            if (count($users) > 0)
                $data['users'] = $users['users'];
            else
                $data['users'] = array();
            $data['status'] = 1;
            $this->makeLog($data, "users for tag received", NULL, NULL, "users for tag received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: appInviteDetails
     * params: Posted Data $post
     * Return: Json
     */
	 
    function appInviteDetails() {
        $data = array();

        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {

            $data['invie_message'] = "Check out Tagalong for your smartphone. Download it today";
            $data['invite_url'] = "https://tagalong.com";
            $data['status'] = 1;
            $this->makeLog($data, "App Invite", NULL, NULL, "Sent App invite message");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: newsFeed
     * params: Posted Data $post
     * Return: Json
     */
	 
    function newsFeed() {
        $data = array();
        $newsFeeds = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {

            $newsFeeds = $this->api_model->following_newsFeed($_POST['user_id'], $_POST['index'], $_POST['count']);
            if (count($newsFeeds) > 0)
                $data['posts'] = $newsFeeds['posts'];
            else
                $data['posts'] = array();
            $data['status'] = 1;
            $this->makeLog($data, "recent NewS Feed received", NULL, NULL, "Recent News Feed received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	/* * *
     * Method: searchtracks
     * params: Posted Data $post
     * Return: Json
     */
	 

    function searchtracks() {
        $data = array();
        $track = array();
        $this->common->matchSecretKey($_POST['my_id'], $this->secret_key);
        $post = $this->api_model->searchTracks($_POST['search_text'], $_POST['index'], $_POST['count'], $_POST['my_id']);
        if (($post > 0)) {
            $data['track'] = $post;
            $data['status'] = 1;
            $this->makeLog($data, "All Track received", NULL, NULL, "All Track received successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/* * *
     * Method: deleteDraft
     * params: Posted Data $post
     * Return: Json
     */

    function deleteDraft() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' && $_POST['post_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $old_file = getVal('post_recording', 'draftPost', 'id', $_POST['post_id']);
            $old_file = explode('/', $old_file);
            $old_file = end($old_file);
            unlink('uploads/draft_post/' . $old_file);


            $result = $this->api_model->delete('draftPost', array('id' => $_POST['post_id']));
            if ($result) {
                $data['status'] = 1;
                $data['message'] = 'Draft Post has been deleted successfully';
                $this->makeLog($_POST['post_id'], "Draft Post", NULL, NULL, "Draft Post  has been deleted");
            } else {
                $data['status'] = 0;
                $data['message'] = 'Failed to delete draft post.';
                $this->makeLog($_POST['post_id'], "Draft Post", NULL, NULL, "Failded to delete draft post");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: paymentClientToken
     * params: Posted Data $post
     * Return: Json
     */
	 
    function paymentClientToken() {
        $this->load->library('braintree-php-3.38.0/lib/Braintree');
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        $data = array();
        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $braintree = $this->api_model->get_braintree_data();
            $gateway = new Braintree_Gateway([
                'environment' => $braintree['braintree_environment'],
                'merchantId' => $braintree['braintree_merchant_id'],
                'publicKey' => $braintree['braintree_public_key'],
                'privateKey' => $braintree['braintree_private_key']
            ]);
            $clientToken = $gateway->clientToken()->generate();
            $data['status'] = 1;
            $data['client_token'] = $clientToken;
            $data['message'] = 'client token has been received successfully';
            $this->makeLog($_POST['post_id'], "client token", NULL, NULL, "Client token has been received");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: buytokens
     * params: Posted Data $post
     * Return: Json
     */

    function buytokens() {

        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['plan_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $post_data = array();
            $post_data['user_id'] = $_POST['user_id'];
            $post_data['plan_id'] = $_POST['plan_id'];
            $post_data['created_date'] = date('Y-m-d H:i:s');
            $insert_id = $this->api_model->create("token_history", $post_data);
            if ($insert_id > 0) {
                $update_data = array();
                $data['plans'] = getValArray('plan_id,tokens,price', 'tokenplans', 'plan_id', $post_data['plan_id']);
                $prev_token = getVal('token', 'users', 'user_id', $post_data['user_id']);
                $update_data['token'] = $prev_token + $data['plans']['tokens'];
                $result = $this->api_model->update('users', $update_data, array('user_id' => $_POST['user_id']));
                $data['status'] = 1;
                $data['message'] = 'Congratulation you successfully purchased token';
                $data['tokens_count '] = $update_data['token'];
                $this->makeLog($_POST['user_id'], "Token purchased", NULL, "successfully purchased token");
            } else {
                $data['status'] = 0;
                $data['error'] = 402;
                $data['message'] = 'Sorry failed to purchased token.';
                $this->makeLog($_POST['user_id'], "Token purchased Failed", NULL, "Failed to purchased token");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/* * *
     * Method: spaceplans
     * params: Posted Data $post
     * Return: Json
     */


    function spaceplans() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['plans'] = $this->api_model->getSpacePlans();
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/* * *
     * Method: getUserItems
     * params: Posted Data $post
     * Return: Json
     */

    function getUserItems() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data = $this->api_model->user_Plan_Items($_POST['user_id']);
            $admin_space = convertToMBs(FREE_SPACE, STORAGE_TYPE);
            $data['remaining_space'];

            $total_space = $admin_space + $data['remaining_space'];

            $folder_path = 'uploads/recording/' . $_POST['user_id'];
            $folder_space = sizeFormat(folderSize($folder_path), 'MB');
            $user_space = $total_space - $folder_space;
            $data['remaining_space'] = round($user_space);
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
	
	/* * *
     * Method: purchaseTrack
     * params: Posted Data $post
     * Return: Json
     */

    function purchaseTrack() {
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        if ($_POST['user_id'] <> '' || $_POST['user_id'] <> 0) {
            $token = getVal('token', 'users', 'user_id', $_POST['user_id']);
            $required_token = getVal('required_tag_tokens', 'tracks', 'track_id', $_POST['track_id']);
            if ($required_token <= $token) {
                $post_data['user_id'] = $_POST['user_id'];
                $post_data['track_id'] = $_POST['track_id'];
                $post_data['token'] = $required_token;
                $results = $this->api_model->create('purchase_tracks', $post_data);
                if ($results) {

                    $update_data['token'] = $token - $required_token;
                    $results = $this->api_model->update('users', $update_data, array('user_id' => $_POST['user_id']));
                    $this->makeLog($results, "Purchase Track", NULL, NULL, "Track Purchase information  has been saved successfully");
                    $data['status'] = 1;
                    $data['token'] = $update_data['token'];
                    $data['is_purchased'] = 1;
                    $data['message'] = 'Track Purchase information  has been saved successfully.';
                } else {
                    $data['status'] = 0;
                    $data['error'] = 402;
                    $data['message'] = 'Failed to Purchase Track, Please try again.';
                }
            } else {
                $data['status'] = 0;
                $data['error'] = 403;
                $data['message'] = 'Sorry you don,t have enough token to purchase track.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo json_encode($data, JSON_NUMERIC_CHECK);
        exit;
    }

	/* * *
     * Method: updatepassword
     * params: Posted Data $post
     * Return: Json
     */
	 
    function updatepassword() {
        $data = array();
        if ($_POST['email'] <> '' && $_POST['verfication_code'] <> '') {
            $post_data = array();
            $post_data['password'] = md5($_POST['newpassword']);
            $cond['email'] = $_POST['email'];
            $cond['verfication_code'] = $_POST['verfication_code'];
            $update = $this->api_model->update('users', $post_data, $cond);
            if ($update > 0) {
                $data['status'] = 1;
                $data['message'] = 'The password has been updated successfully';
                $this->makeLog($_POST['user_id'], "Update Skill", NULL, NULL, "User has updated skill");
            } else {
                $data['status'] = 0;
                $data['message'] = 'Failed to update skill.';
                $this->makeLog($_POST['user_id'], "Sorry password is not updated!");
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }

        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    function overlapAudioFiles() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '' && $_POST['track_id'] <> '' && ($_FILES['recording_file']['name'] != '')) {
            $this->exitIfInactive($_POST['user_id']);
            $track = getVal('audio_url', 'tracks', 'track_id', $_POST['track_id']);

            $path = 'uploads/overlapping_files';

            $filename = $this->common->overlap_audio_file($path, $_FILES['recording_file']['tmp_name'], $_FILES['recording_file']['name'], $track);
            if ($filename) {

                $data['audio'] = base_url($filename);
                $data['status'] = 1;
                $data['message'] = 'File marge successfully';
            } else {
                $data['status'] = 0;
                $data['error'] = 403;
                $data['message'] = 'Sorry Fail to marge file.';
            }
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
    }
	/* * *
     * Method: packagePurchased
     * params: Posted Data $post
     * Return: Json
     */
	 
    function packagePurchased() {
        $data = array();
        $update_data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);
        $this->exitIfInactive($_POST['user_id']);
        if ($_POST['user_id'] <> '' && $_POST['purchase_type'] <> '' && $_POST['plan_id'] <> '') {
            $post_data = array();
            $post_data['user_id'] = $_POST['user_id'];
            $post_data['plan_id'] = $_POST['plan_id'];
            $post_data['purchase_type'] = $_POST['purchase_type'];

            if ($post_data['purchase_type'] == 1) {
                
                $result = getValArray('tokens,price', 'tokenplans', 'plan_id', $post_data['plan_id']);
                $post_data['token']=$result['tokens'];
                $post_data['price']=$result['price'];
                $prev_token = getVal('token', 'users', 'user_id', $post_data['user_id']);
                $update_data['token'] = $prev_token + $post_data['token'];
                $data['tag_tokens'] = $update_data['token'];
            } else if ($post_data['purchase_type'] == 2) {

                $result = getValArray('months,price', 'premium_plans', 'plan_id', $post_data['plan_id']);
                $post_data['months']=$result['months'];
                $post_data['price']=$result['price'];
                $update_data['premium_expiry'] = date("y-m-d", strtotime("+" . $post_data['months'] . " months", strtotime(date("y-m-d"))));
                $data['premium_expiry'] = $update_data['premium_expiry'];
                $data['is_premium'] = 1;
            } else {
                $result = getValArray('space,space_type,price', 'additional_space', 'plan_id', $post_data['plan_id']);
                $post_data['space'] = $result['space'];
                $post_data['space_type'] = $result['space_type'];
                $post_data['price'] = $result['price'];
                $prev_space = getVal('additional_space', 'users', 'user_id', $post_data['user_id']);
                $converted_value = convertToMBs($post_data['space'], $post_data['space_type']);
                $update_data['additional_space'] = $prev_space + $converted_value;
                $data['remaining_space'] = $update_data['additional_space'];
            }

            $insert_id = $this->api_model->create("payment_history", $post_data);
            $result = $this->api_model->update('users', $update_data, array('user_id' => $_POST['user_id']));
            $data['message'] = 'Payment updated successfully.';
            $data['status'] = 1;
            $this->makeLog($_POST['user_id'], "token Nonce", NULL, "Token Nonce updated successfully");
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

	/* * *
     * Method: getPackages
     * params: Posted Data $post
     * Return: Json
     */
    
     function getPackages() {
        $data = array();
        $this->common->matchSecretKey($_POST['user_id'], $this->secret_key);

        if ($_POST['user_id'] <> '') {
            $this->exitIfInactive($_POST['user_id']);
            $data['status'] = 1;
            $data['token_plans'] = $this->api_model->gettokenPlans();
            $data['space_plans'] = $this->api_model->getSpacePlans();
            $data['premium_plans'] = $this->api_model->getPremiumPlans();
        } else {
            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }


        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }
    
   
}
