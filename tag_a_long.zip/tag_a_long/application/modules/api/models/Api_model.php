<?php

if (!defined('BASEPATH'))
exit('No direct script access allowed');

class Api_model extends CI_Model {

var $tbl_users = 'users';
var $tbl_locations = 'location';
var $tbl_messages = "messages";
var $tbl_thread = "thread";
var $tbl_notifications_logs = "notifications_logs";
var $tbl_activity_logs = "activity_logs";
var $tbl_notifications = "notifications";
var $tbl_tracks = "tracks";
var $tbl_genre = "genre";
var $tbl_track_likes = "track_likes";
var $tbl_billing_address = "billing_address";
var $tbl_post = "posts";
var $tbl_follower = "follower";
var $tbl_participant = "participant";
var $tbl_postLikes = "post_likes";
var $tbl_setting = "setting";
var $tbl_premium_plans = "premium_plans";
var $tbl_token_plans = "tokenplans";
var $tbl_draftPost = "draftPost";
var $tbl_user_firebase_tokens = "user_firebase_tokens";
var $tbl_additional_space = "additional_space";
public function __construct() {
parent::__construct();
}

//End __construct

/**
 * Method: insert
 * Return: id
 */
function create($table, $data) {
$this->db->insert($table, $data);

return $this->db->insert_id();
}

/**
 * Method: update
 * Return:
 */
function update($table, $data, $where) {
$this->db->where($where);
return $this->db->update($table, $data);
}



/**
 * Method: delete
 * Return:
 */
function delete($table, $where) {
$this->db->where($where);
return $this->db->delete($table);
}

function multiple_where_delete($table, $where) {
    
$this->db->where($where[0]);  
$this->db->where($where[1]);
return $this->db->delete($table);
}

/**
 * Method: ajaxLogin
 * params: $_POST
 * Retruns:
 */
public function ajaxLogin($email, $passwrd) {
$password = md5($passwrd);
$this->db->select('*');

$this->db->where('email', $email);
$this->db->where('password', $password);
$this->db->limit(1);
$qry = $this->db->get($this->db->dbprefix($this->tbl_users));
if ($qry->num_rows() > 0) {
foreach ($qry->result() as $result) {
if ($result->is_active == 0) {
return -1;
}
$user_session['user_id'] = $result->user_id;
}


$data = array(
'last_activity_time' => time());
$this->db->where('user_id', $user_session['user_id']);
$this->db->update($this->db->dbprefix($this->tbl_users), $data);
return $user_session['user_id'];
} else {
return 0;
}
}

/**
 * Method: ajaxLoginPhone
 * params: $_POST
 * Retruns:
 */
public function ajaxLoginPhone($phone, $passwrd) {
$password = md5($passwrd);
$this->db->select('*');
$this->db->where('is_active', 1);
$this->db->where('phone_no', $phone);
$this->db->where('password', $password);
$this->db->limit(1);
$qry = $this->db->get($this->db->dbprefix($this->tbl_users));
if ($qry->num_rows() > 0) {
foreach ($qry->result() as $result) {
$user_session['user_id'] = $result->user_id;
}
$data = array(
'last_activity_time' => time());
$this->db->where('user_id', $user_session['user_id']);
$this->db->update($this->db->dbprefix($this->tbl_users), $data);
return $user_session['user_id'];
} else {
return 0;
}
}

/**
 * Method: verify_email
 * Params: $email
 * Return: True
 */
function verify_email($email) {

 $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.email = '" . $email . "' ";

$result = $this->db->query($query);
if ($result->num_rows() > 0) {
$resultArray = $result->row_array();
if ($this->isUserInactive($resultArray['user_id']) == 1) {
return -1;
}
return 0;
} else {
return 1;
}
}

/**
 * Method: verifyUserEmail
 * Params: $email
 * Return: True
 */
function verifyUserEmail($email, $user_id) {
$query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.email = '" . $email . "' AND user_id <> " . $user_id;
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: verifyUserNo
 * Params: $verify_no
 * Return: True
 */
function verifyUserNo($verify_no, $user_id) {
$query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.phone_no = '" . $verify_no . "'  AND user_id <> " . $user_id;
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: verify_phone
 * Params: $fb_identifier_id
 * Return: True
 */
function verify_phone($phone_no) {
$query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.phone_no = '" . $phone_no . "' ";
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: verify_user
 * Params: $fb_identifier_id
 * Return: True
 */
function verify_user($media, $media_id) {
$query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u." . $media . " = " . $media_id . " ";
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: isUserInactive
 * Params: $user_id
 * Return: True
 */
function isUserInactive($user_id) {
$query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
$result = $this->db->query($query);
$resultArray = $result->row_array();
if ($resultArray['is_active'] == 0) {
return 1;
} else if ($resultArray['is_active'] == 1) {
return 0;
}
}

/**
 * Method: getBadgeIncremented
 * Params: $user_id
 * Return: badge
 */
function getBadgeIncremented($user_id) {
$query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
$result = $this->db->query($query);
$resultArray = $result->row_array();
$badge = $resultArray['badge'];
$badge++;
$post_data = array();
$post_data['badge'] = $badge;
$this->update($this->tbl_users, $post_data, array('user_id' => $user_id));
return $badge;
}

/**
 * Method: getMessageBadgeIncremented
 * Params: $user_id
 * Return: badge
 */
function getMessageBadgeIncremented($user_id) {
$query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
$result = $this->db->query($query);
$resultArray = $result->row_array();
$badge = $resultArray['message_badge'];

$badge++;
$post_data = array();
$post_data['message_badge'] = $badge;
$this->update($this->tbl_users, $post_data, array('user_id' => $user_id));
return $badge;
}

/**
 * Method: getMessageBadgeDecremented
 * Params: $user_id
 * Return: badge
 */
function getMessageBadgeDecremented($user_id) {
$query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
$result = $this->db->query($query);
$resultArray = $result->row_array();
$badge = $resultArray['message_badge'];
$badge--;
if ($badge < 0) {
$badge = 0;
}
$post_data = array();
$post_data['message_badge'] = $badge;
$this->update($this->tbl_users, $post_data, array('user_id' => $user_id));
return $badge;
}

/**
 * Method: verify_user
 * Params: $fb_identifier_id
 * Return: True
 */
function verify_user_twitter($user_twId) {
$query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.user_twid  = " . $user_twId . " ";
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: verify_user_id
 * Params: $fb_identifier_id
 * Return: True
 */
function verify_user_id($user_id) {
$query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";

$result = $this->db->query($query);
$resultArray = $result->row_array();
if ($result->num_rows() > 0 && $resultArray['is_active'] == 1) {
return 1;
} else if ($result->num_rows() > 0 && $resultArray['is_active'] == 0) {
return -1;
} else {
return 0;
}
}

/**
 * Method: ifExistUserDevice
 * Params: $user_id,$device_id
 * Return: True
 */
function ifExistUserDevice($user_id, $device_id) {
$query = " SELECT  *
                     FROM user_firebase_tokens  AS u 
                     WHERE  u.device_id = '" . $device_id . "'";
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return true;
} else {
return false;
}
}

/**
 * Method: get_user_data
 * Params: $user_id
 * Return: array
 */
function get_user_data($user_id) {
$query = " SELECT
                u.user_id,
                u.name,
                u.email,
                u.phone_no,
                u.avatar,
                u.fb_url,
                u.tw_url,
                u.soundcloud_url,
                u.web_url,
                u.cover_photo,
                u.is_verified

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.is_active = 1 AND  u.user_id = " . $user_id . " limit 1 ";
            $result = $this->db->query($query);

            //if ($result->num_rows() > 0) {
            $results = $result->row_array();
            foreach ($results as $key => $value) {
                if (is_null($value)) {
                     $results[$key] = " ";
                }
            }
            if ($results['avatar'] <> '') {
            $results['avatar'] = $results['avatar'];
            }
            return $results;
            //        }
}

/**
 * Method: get_user_data_by_email
 * Params: $user_id
 * Return: array
 */
 
function get_user_data_by_email($user_email) {
   $query = " SELECT
                u.user_id,
                u.name,
                u.email,
                u.is_verified

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.is_active = 1 AND  u.email = '" . $user_email . "' limit 1 ";

            $result = $this->db->query($query);
            $results = $result->row_array();
            foreach ($results as $key => $value) {
                if (is_null($value)) {
                     $results[$key] = " ";
                }
            }
            
            return $results;
           
}
/**
 * Method: getFirebaseRegistrationIds
 * Params: $user_id
 * Return: array
 */
function getFirebaseRegistrationIds($user_id) {
$query = " SELECT u.firebase_token "
. "FROM " . $this->db->dbprefix($this->tbl_user_firebase_tokens) . " AS u "
. " WHERE u.user_id = " . $user_id;

$result = $this->db->query($query);
$result = $result->result_array();
$results = array();
for ($x = 0;
$x < count($result);
$x++) {
$temp = $result[$x];
$results[$x] = $temp['firebase_token'];
}
return $results;
}

/**
 * Method: getBillingInfo
 * Params: $user_id
 * Return: array
 */
function getBillingInfo($user_id) {
$query = " SELECT
                b.first_name,
                b.last_name,
                b.card_number,
                b.cvv,
                b.expiry_month,
                b.expiry_year,
                b.address_line1,
                b.address_line2,
                b.city,
                b.state,
                b.zip,
                b.country 

            FROM " . $this->db->dbprefix($this->tbl_billing_address) . " AS b
            WHERE b.is_active = 1 AND  b.user_id = " . $user_id . " limit 1 ";
$result = $this->db->query($query);
$results = $result->row_array();
return $results;
}

/**
 * Method: getUserNotification
 * Params: $user_id
 * Return: array
 */

function getUserNotification($user_id, $offset, $limit) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}



$query = "Select c.*, n.avatar as sender_avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_notifications_logs) . " AS c "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS n"
. " ON n.user_id = c.sender_id  "
. " WHERE c.user_id = " . $user_id . "   ORDER BY c.id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
$result = $query->result_array();
for ($x = 0;
$x < count($result);
$x++) {
$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " WHERE f.follower_user_id=" . $user_id . " and f.following_user_id = " . $result[$x]['sender_id'];

$query = $this->db->query($query);

if ($query->num_rows() > 0) {
$result[$x]['is_following'] = 1;
} else {
$result[$x]['is_following'] = 0;
}
}
return $result;
}


/**
 * Method: verifyShouldDecrementBadge
 * Params: $user_id
 * Return: array
 */
function verifyShouldDecrementBadge($user_id, $thread_id) {
$result = $this->getMessageIdsToUserIsNotRead($user_id, $thread_id);
if (count($result) > 0) {
return true;
}
return false;
}

/**
 * Method: verifyShouldDecrementBadge
 * Params: $user_id
 * Return: array
 */
 
function fetchMessageThreads($user_id, $offset, $limit) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}

$query = " SELECT DISTINCT  m.thread_id,m.message as latest_message,m.from_user_id as lastest_from_id ,m.to_user_id as lastest_to_id,m.is_read as read_status,m.created as date_time  " .
"FROM " . $this->db->dbprefix($this->tbl_thread) . " AS t "
. "  INNER JOIN ( select DISTINCT thread_id,message_id,message,from_user_id,to_user_id,is_read,created from messages "
. " where ((from_user_id =  " . $user_id . " and sender_status= 1 ) or ( to_user_id = "
. $user_id . " and receiver_status = 1 )) " .
"  ORDER BY message_id DESC ) "
. "   as m"
. " ON m.thread_id = t.id  "
. " WHERE t.from_id = " . $user_id . " or t.to_id = " . $user_id
. " Group by m.thread_id ORDER BY t.last_update DESC "
. " LIMIT " . $offset . ", " . $limit . " "
;

$query = $this->db->query($query);
$result = $query->result_array();

for ($x = 0;
$x < count($result);
$x++) {
$tmp = $result[$x];
if ($tmp['lastest_from_id'] == $user_id) {
$with_id = getVal('user_id', 'users', 'user_id', $tmp['lastest_to_id']);
$with_name = getVal('name', 'users', 'user_id', $tmp['lastest_to_id']);
$with_url = getVal('avatar', 'users', 'user_id', $tmp['lastest_to_id']);
$result[$x]['with_id'] = $with_id;
$result[$x]['with_name'] = $with_name;
$result[$x]['with_url'] = $with_url;
} else if ($tmp['lastest_to_id'] == $user_id) {
$with_id = getVal('user_id', 'users', 'user_id', $tmp['lastest_from_id']);
$with_name = getVal('name', 'users', 'user_id', $tmp['lastest_from_id']);
$with_url = getVal('avatar', 'users', 'user_id', $tmp['lastest_from_id']);
$result[$x]['with_id'] = $with_id;
$result[$x]['with_name'] = $with_name;
$result[$x]['with_url'] = $with_url;
}
}

return $result;
}

/**
 * Method: shouldIncrementMessageBadge
 * Params: $user_id
 * Return: array
 */

function shouldIncrementMessageBadge($reciever, $thread_id, $message_id) {
$query = "Select m.message_id,m.from_user_id,m.message,m.created,m.is_read"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE  m.thread_id = " . $thread_id . " and m.to_user_id = " . $reciever . " and m.receiver_status = 1";
$query = $this->db->query($query);
$result = $query->result_array();
if (count($result) == 1) {
return 1;
} else {
if ($result[count($result) - 2]['is_read'] == 1) {
return 1;
}
}
return 0;
}

/**
 * Method: updateMessageBadgeIfRequired
 * Params: $user_id
 * Return: array
 */

 
function updateMessageBadgeIfRequired($receiver, $ids) {
$max = 0;
foreach ($ids as $id) {
if ((int) $id > $max) {
$max = $id;
}
}

if (count($ids) == 0) {
return;
}

$thread_id = getVal('thread_id', 'messages', 'message_id', $ids[0]);

$query = "Select m.message_id "
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE  m.thread_id = " . $thread_id . " and m.to_user_id = " . $receiver . " and m.receiver_status = 1 "
. " ORDER BY m.message_id DESC LIMIT 1 ";
$query = $this->db->query($query);
$result = $query->result_array();
if (count($result) == 0) {
return;
} else {
if ($max == $result[0]) {
$this->getMessageBadgeDecremented($receiver);
}
}
}

/**
 * Method: fetchMessages
 * Params: $user_id
 * Return: array
 */
 
function fetchMessages($user_id, $thread_id, $count, $before, $after) {
if ($count == 0 || $count == "") {
$count = 10;
}

if (($before == '' || $before == 0) && ($after == '' || $after == 0)) {
$query = "Select m.message_id,m.from_user_id as from_id,m.message,m.created as date_time,m.is_read as read_status "
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE ( m.thread_id = " . $thread_id . " )"
. " and ((m.from_user_id =  " . $user_id . " and m.sender_status= 1 ) or ( m.to_user_id = "
. $user_id . " and m.receiver_status = 1 )) "
. " ORDER BY m.message_id DESC LIMIT " . $count . " "
;


$query = $this->db->query($query);
$result = $query->result_array();
$result = array_reverse($result, true);

return $result;
} else if ($after <> '') {
$query = "Select m.message_id,m.from_user_id as from_id,m.message,m.created,m.is_read"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE m.thread_id = " . $thread_id . " and m.message_id > " . $after
. " and ((m.from_user_id =  " . $user_id . " and m.sender_status= 1 ) or ( m.to_user_id = "
. $user_id . " and m.receiver_status = 1 )) "
. "  LIMIT " . $count . " "
;
$query = $this->db->query($query);
$result = $query->result_array();
return $result;
} else if ($before <> '') {
$query = "Select m.message_id,m.from_user_id as from_id,m.message,m.created,m.is_read"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE m.thread_id = " . $thread_id . " and m.message_id  < " . $before
. " and ((m.from_user_id =  " . $user_id . " and m.sender_status= 1 ) or ( m.to_user_id = "
. $user_id . " and m.receiver_status = 1 )) "
. " ORDER BY m.message_id DESC LIMIT " . $count . " "
;

$query = $this->db->query($query);
$result = $query->result_array();
$result = array_reverse($result, true);

return $result;
}
}

/**
 * Method: getMessageIdsToUser
 * Params: $user_id
 * Return: array
 */
 
function getMessageIdsToUser($user_id, $thread_id) {
$query = "Select message_id"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE m.thread_id = " . $thread_id . " and m.to_user_id = " . $user_id
;

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}


/**
 * Method: getMessageIdsToUserIsNotRead
 * Params: $user_id
 * Return: array
 */
 
function getMessageIdsToUserIsNotRead($user_id, $thread_id) {
$query = "Select message_id"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE m.thread_id = " . $thread_id . " and m.is_read = 0 and m.receiver_status = 1 and m.to_user_id = " . $user_id
;

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: verifyThreadExist
 * Params: $user_id
 * Return: array
 */
 
function verifyThreadExist($user1, $user2) {
$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_thread) . " AS t "
. "WHERE ( t.from_id = " . $user1 . " and t.to_id  = " . $user2 . " ) OR "
. "( t.from_id = " . $user2 . " and t.to_id  = " . $user1 . " ) "
;

$query = $this->db->query($query);
if ($query->num_rows() > 0) {
$result = $query->result_array()[0]['id'];
return $result;
} else {
return 0;
}
}

/**
 * Method: getMessageIds
 * Params: $user_id
 * Return: array
 */
 
function getMessageIds($thread_id) {
$query = "Select message_id"
. " FROM "
. $this->db->dbprefix($this->tbl_messages) . " AS m "
. "WHERE m.thread_id = " . $thread_id
;

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: get_braintree_data
 * Params: $slug
 * Return: True
 * */
function get_braintree_data() {

$query = "SELECT  braintree_merchant_id,"
. "braintree_public_key ,"
. "braintree_private_key ,"
. "braintree_environment "
. " FROM "
. " payment_integration AS pg "
. " WHERE  is_active = 1 "
. " ORDER BY id DESC limit 1";

$query = $this->db->query($query);
return $query->row_array();
}

/**
 * Method: favouriteTracks
 * Params: $user_id
 * Return: array
 */

function favouriteTracks($user_id, $query_text = "", $offset, $limit) {
$track = array();
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$this->db->SELECT('track.title,track.file_name,track.is_free');
$this->db->from($this->tbl_tracks . "  AS track ");
$this->db->join($this->tbl_track_likes . "  As track_like", 'track_like.track_id=track.id', 'inner');
$this->db->join($this->tbl_users . "  As user", 'track_like.user_id= user.user_id', 'inner');
$this->db->where("track.is_active !=", '0');
$this->db->where("track_like.user_id =", $user_id);
if ($query_text != "") {
$this->db->where("track_name LIKE '%$query_text%'");
}
$this->db->limit($offset, $limit);
//$this->db->get_compiled_select();

$query = $this->db->get();

$result = $query->result_array();

return $result;
}

/**
 * Method: getTrackDetail
 * Params: $user_id
 * Return: array
 */
 

function getTrackDetail($track_id) {
$query = $this->db->get_where($this->db->dbprefix($this->tbl_tracks), array('id' => $track_id));
return $query->row_array();
}

/**
 * Method: getGenres
 * Params: $user_id
 * Return: array
 */
 
function getGenres() {
$this->db->SELECT('id,name,image_url');
$this->db->from('genre');
$this->db->where("is_active !=", '0');
$query = $this->db->get();
$results = $query->result_array();
return $results;
}

/**
 * Method: checkUsername
 * Params: $user_id
 * Return: array
 */

function checkUsername($username) {
$this->db->select('username');
$this->db->from($this->tbl_users);
$this->db->where("username =", $username);
//echo $this->db->get_compiled_select();
$query = $this->db->get();
if ($query->num_rows() > 0) {
return 1;
} else {
return 0;
}
}

/**
 * Method: getPost
 * Params: $user_id
 * Return: array
 */
 

function getPost($post_id) {
$query = " SELECT
                p.user_id,
                p.post_id,
                p.post_title,
                p.post_description,
                p.track_id,
                p.bar_count,
                p.post_type,
                p.is_locked ,
                p.recorded 
                FROM " . $this->db->dbprefix($this->tbl_post) . " AS p
                WHERE p.is_active = 1 AND  p.post_id = " . $post_id . " limit 1 ";
$result = $this->db->query($query);
$results = $result->row_array();
$results['post_type'] = (int) $results['post_type'];
$results['post_type'] = "||". $results['post_type'];
return $results;
}

/**
 * Method: is_follow
 * Params: $user_id
 * Return: array
 */
 
function is_follow($user_id, $participant_id) {
$query = "SELECT f.follower_user_id,f.following_user_id ,fd.follower_user_id,fd.following_user_id  
                FROM  " . $this->db->dbprefix($this->tbl_follower) . " AS f
                inner  JOIN " . $this->db->dbprefix($this->tbl_follower) . " AS fd
                ON f.follower_user_id = " . $user_id . "
                AND f.following_user_id = " . $participant_id . "
                WHERE fd.follower_user_id = " . $participant_id . "
                and fd.following_user_id=" . $user_id;

$result = $this->db->query($query);
if (($result->num_rows() > 0) || ($user_id == $participant_id))
return 1;

else

return 0;

}

/**
 * Method: getTrack
 * Params: $user_id
 * Return: array
 */
 
function getTrack($type, $offset, $limit,$user_id) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select t.track_id,t.image_url,t.title,t.duration,t.audio_url,IF(t.user_id='" . $user_id . "' AND t.approve=1, '0', t.required_tag_tokens)as required_tag_tokens,IF(t.is_free=1, 'free', 'paid') as type,g.name as genre,"
. " (SELECT EXISTS(SELECT id FROM purchase_tracks WHERE track_id=t.track_id and user_id='" . $user_id . "'))as is_purchased "        
. " FROM "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g"
. " ON t.genre=g.id "
. " WHERE t.genre = " . $type . "   ORDER BY t.track_id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: getallTrack
 * Params: $user_id
 * Return: array
 */

function getallTrack($offset, $limit,$user_id) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
 $query = "select t.track_id,t.image_url,t.title,t.duration,t.audio_url,g.name as genre,"
 . "IF(t.user_id='" . $user_id . "' AND t.approve=1, '0', t.required_tag_tokens)as required_tag_tokens, (SELECT EXISTS(SELECT id FROM purchase_tracks WHERE track_id=t.track_id and user_id='" . $user_id . "'))as is_purchased "       
 . " FROM "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " LEFT JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g"
. " ON t.genre=g.id "
. "ORDER BY t.track_id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
$result = $query->result_array();


return $result;
}


/**
 * Method: totalPosts
 * Params: $user_id
 * Return: array
 */
 
 
function totalPosts($user_id) {
$as = "no_of_posts";
 $query = "SELECT count(p.post_id) as "
. $as . " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. "where (p.user_id=" . $user_id . " or p.post_id IN (select  pt.post_id from participant pt "
. "where pt.participant_id=" . $user_id . " and pt.user_id <> " . $user_id . "))AND is_locked=1;";


$query = $this->db->query($query);
$results = $query->row();
return $results->$as;
}

/**
 * Method: recentPosts
 * Params: $user_id
 * Return: array
 */
 
function recentPosts($userid, $myid, $offset = 0, $limit = "") {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}

$query = "select p.post_id,p.post_description,p.user_id as initiator_id,p.filename as audio_url,u.name as initiator_name,u.avatar as initiator_avatar,p.post_title as title,p.post_title as title,p.total_playes,p.total_like as total_likes,p.total_like as total_likes,"
. "DATE(p.created) as post_since,p.is_locked as is_published,p.post_avatar as image_url,g.name as genre,"
. "(SELECT EXISTS(SELECT user_id FROM post_likes WHERE post_id=p.post_id and user_id='" . $myid . "'))as is_liked"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_tracks) . " AS t"
. " ON t.track_id=p.track_id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g "
. " ON t.genre=g.id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u"
. " ON p.user_id=u.user_id "
. " WHERE p.post_type=0 and p.user_id = " . $userid . "   ORDER BY p.post_id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
if ($query->num_rows() > 0) {
$result['posts'] = $query->result_array();
for ($x = 0;
$x < count($result['posts']);
$x++) {

$result['posts'][$x]['participant_avatars'] = array();
$result['posts'][$x]['post_since'] = $result['posts'][$x]['post_since'] != "" ? $result['posts'][$x]['post_since'] : "";
$result['posts'][$x]['share_message'] = "Lorem ipsum dolor sit amett";
$result['posts'][$x]['share_url'] = " http://tagalongmusic.com";

}
}
return $result;
}

/**
 * Method: recentCollabs
 * Params: $user_id
 * Return: array
 */
 
function recentCollabs($userid, $myid, $offset = 0, $limit = "") {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select p.post_id,p.post_description,p.user_id as initiator_id,p.filename as audio_url,u.name as initiator_name,u.avatar as initiator_avatar,p.post_title as title,"
. "p.post_title as title,p.total_playes,p.total_like as total_likes,p.total_like as total_likes,DATE(p.created) as post_since,"
. "p.is_locked as is_published,p.post_avatar as image_url,g.name as genre,"
. "(SELECT EXISTS(SELECT user_id FROM post_likes WHERE post_id=p.post_id and user_id='" . $myid . "'))as is_liked"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " ON t.track_id=p.track_id "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_participant) . " AS pt "
. "ON p.post_id=pt.post_id"
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g "
. " ON t.genre=g.id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u"
. " ON p.user_id=u.user_id "
. " WHERE p.post_type=1 and pt.participant_id = " . $userid . "  ORDER BY p.post_id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
if ($query->num_rows() > 0) {
$result['collabs'] = $query->result_array();

for ($x = 0;
$x < count($result['collabs']);
$x++) {
$query = "select avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_participant) . " AS p"
. " on p.participant_id=u.user_id"
. " WHERE  p.post_id = " . $result['collabs'][$x]['post_id'] . "  ORDER BY p.post_id DESC; ";

$query = $this->db->query($query);
$result['collabs'][$x]['participant_avatars'] = $query->result_array();
$result['collabs'][$x]['post_since'] = $result['collabs'][$x]['post_since'] != "" ? $result['collabs'][$x]['post_since'] : "";
$result['collabs'][$x]['share_message'] = "Lorem ipsum dolor sit amet";
$result['collabs'][$x]['share_url'] = " http://tagalongmusic.com";
}
}
return $result;
}

/**
 * Method: recentPostLikes
 * Params: $user_id
 * Return: array
 */

function recentPostLikes($userid, $myid, $offset = 0, $limit = "") {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select p.post_id,p.post_description,p.user_id as initiator_id,p.filename as audio_url,u.name as initiator_name,u.avatar as initiator_avatar,p.post_title as title,p.post_title as title,p.total_playes,p.total_like as total_likes,p.total_like as total_likes,"
. "DATE(p.created) as post_since,p.is_locked as is_published,p.post_avatar as image_url,g.name as genre,"
. "(SELECT EXISTS(SELECT user_id FROM post_likes WHERE post_id=p.post_id and user_id='" . $myid . "'))as is_liked"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " ON t.track_id=p.track_id "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_postLikes) . " AS lik "
. "ON p.post_id=lik.post_id"
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g "
. " ON t.genre=g.id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u"
. " ON p.user_id=u.user_id "
. " WHERE  lik.user_id = " . $userid . "    ORDER BY p.post_id DESC  LIMIT " . $offset . ", " . $limit . " ;";

$query = $this->db->query($query);
if ($query->num_rows() > 0) {
$result['likes'] = $query->result_array();

for ($x = 0;
$x < count($result['likes']);
$x++) {

$query = "select avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_participant) . " AS p"
. " on p.participant_id=u.user_id"
. " WHERE  p.post_id = " . $result['likes'][$x]['post_id'] . "  ORDER BY p.post_id DESC; ";

$query = $this->db->query($query);
$result['likes'][$x]['participant_avatars'] = $query->result_array();
$result['likes'][$x]['post_since'] = $result['likes'][$x]['post_since'] != "" ? $result['likes'][$x]['post_since'] : "";
$result['likes'][$x]['share_message'] = "Lorem ipsum dolor sit amet";
$result['likes'][$x]['share_url'] = "http://tagalongmusic.com";
}
}

return $result;
}


/**
 * Method: getBars
 * Params: $user_id
 * Return: array
 */
 
function getBars($postid) {
$query = "select pt.participant_id as user_id,u.name,u.avatar as photo_url,s.b_length as bar_length,pt.recorded"
. " FROM "
. $this->db->dbprefix($this->tbl_participant) . " AS pt "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. " ON pt.participant_id=u.user_id "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_setting) . " AS  s "
. " WHERE  pt.post_id = " . $postid . "   ORDER BY  pt.id";

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}


/**
 * Method: get_single_bar
 * Params: $user_id
 * Return: array
 */
 
function get_single_bar($postid) {
$query = "select p.user_id as user_id,u.name,u.avatar as photo_url,s.b_length as bar_length,p.recorded"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. " ON p.user_id=u.user_id "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_setting) . " AS  s "
. " WHERE  p.post_id = " . $postid . "   ORDER BY  p.post_id";

$query = $this->db->query($query);
$result = $query->result_array();

return $result;
}


/**
 * Method: getparticipant
 * Params: $user_id
 * Return: array
 */
 
function getparticipant($postid) {
$query = "select participant_id ,assign_bars,participant_index"
. " FROM "
. $this->db->dbprefix($this->tbl_participant)
. " WHERE  post_id = " . $postid . "   ORDER BY  id";

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: post_locked
 * Params: $user_id
 * Return: array
 */

public function post_locked() {
$duration = getVal('duration', 'setting', 'id', '1');
$this->db->select('post_id,created');
$this->db->where('is_locked', 0);
$qry = $this->db->get($this->db->dbprefix($this->tbl_post));
if ($qry->num_rows() > 0) {
foreach ($qry->result() as $result) {
$post['created'] = $result->created;
$post['id'] = $result->post_id;
$startdate = date("d-m-Y H:i:s", $post['created']);
$expire = strtotime($startdate . ' + ' . $duration);
$today = time();
if ($today >= $expire) {
$data = array(
'is_locked' => 1);
$this->db->where('post_id', $post['id']);
$this->db->update($this->db->dbprefix($this->tbl_post), $data);
}
}

return 1;
} else {
return 0;
}
}

/**
 * Method: is_locked
 * Params: $post_id
 * Return: 1
 * */
function is_locked($post_id) {
$query = "SELECT post_id  
                FROM  " . $this->db->dbprefix($this->tbl_post) . " AS p
                WHERE p.is_locked = 0 and p.is_active=1 and post_id=" . $post_id;
$result = $this->db->query($query);
if ($result->num_rows() > 0)
return 1;
else
return 0;
}

/**
 * Method: verifyParticipant
 * Params: $user_id
 * Return: array
 */
 
function verifyParticipant($post, $participant) {
$query = " SELECT  p.post_id
                     FROM " . $this->db->dbprefix($this->tbl_participant) . " AS p
                     WHERE p.post_id = '" . $post . "' AND p.participant_id= " . $participant;
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 0;
} else {
return 1;
}
}

/**
 * Method: userfollowing
 * Params: $user_id
 * Return: array
 */
 
function userfollowing($user_id, $following_id) {
$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " WHERE f.follower_user_id=" . $user_id . " and f.following_user_id = " . $following_id;

$query = $this->db->query($query);
if ($query->num_rows() > 0)
$result = 1;
else
$result = 0;
return $result;
}

/**
 * Method: verifyUserUploading
 * Params: post_id,user_id,posttype
 * Return: 1,0,-1
 * */
function verifyUserUploading($user_id, $post_id, $posttype) {
if ($posttype == 1) {
$query = "select *"
. " FROM "
. $this->db->dbprefix($this->tbl_participant) . " AS p "
. " WHERE p.post_id=" . $post_id . " and p.participant_id=" . $user_id;
$query = $this->db->query($query);
if ($result->num_rows() == 0) {
return -1;
}
}
if ($posttype == 0) {
$query = "select recorded"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. " WHERE p.post_id=" . $post_id . " and p.post_type = " . $posttype . " and p.user_id=" . $user_id . " and recorded=1";
} else {
$query = "select recorded"
. " FROM "
. $this->db->dbprefix($this->tbl_participant) . " AS p "
. " WHERE p.post_id=" . $post_id . " and p.participant_id=" . $user_id . " and recorded=1";
}
$query = $this->db->query($query);
if ($result->num_rows() > 0)
return 1;
else
return 0;
}

/**
 * Method: getPremiumPlans
 * Params: $user_id
 * Return: array
 */
 
function getPremiumPlans() {
$query = "Select plan_id,price,months,price*months as total_price,store_id as appstore_id "
. " FROM "
. $this->db->dbprefix($this->tbl_premium_plans)
. " WHERE is_active = 1"
. " ORDER BY plan_id DESC";


$query = $this->db->query($query);
return $query->result_array();
}

/**
 * Method: gettokenPlans
 * Params: $user_id
 * Return: array
 */
 
function gettokenPlans() {
$query = "Select plan_id,tokens,price,store_id as appstore_id"
. " FROM "
. $this->db->dbprefix($this->tbl_token_plans)
. " WHERE is_active = 1"
. " ORDER BY plan_id DESC";


$query = $this->db->query($query);
return $query->result_array();
}

/**
 * Method: getusers
 * Params: $user_id
 * Return: array
 */
 
function getusers($user_id, $offset, $limit) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "Select user_id,name,avatar as image_url"
. " FROM "
. $this->db->dbprefix($this->tbl_users)
. " WHERE is_active = 1"
. " and user_id !=" . $user_id . ""
. " ORDER BY user_id"
. " LIMIT " . $offset . ", " . $limit;

$query = $this->db->query($query);
return $query->result_array();
}

/**
 * Method: searchUsers
 * Params: $user_id
 * Return: array
 */

function searchUsers($user_id, $searchtext) {

$query = "Select user_id,name,avatar as image_url"
. " From "
. $this->db->dbprefix($this->tbl_users)
. " where is_active = 1 and user_id !=" . $user_id . "";

if ($searchtext != "") {
$query = $query . " and ( name LIKE '%" . $searchtext . "%' " . " or email LIKE '%" . $searchtext . "%' " . " or username LIKE '%" . $searchtext . "%' ) ";
}
$query = $query . " ORDER BY user_id DESC  ";

$query = $this->db->query($query);
$result = $query->result_array();
for ($x = 0;
$x < count($result);
$x++) {

$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " WHERE f.follower_user_id=" . $user_id . " and f.following_user_id = " . $result[$x]['user_id'];

$query = $this->db->query($query);

if ($query->num_rows() > 0) {
$result[$x]['is_following'] = 1;
} else {
$result[$x]['is_following'] = 0;
}
}

return $result;
}

/**
 * Method: isPostAlreadyLiked
 * Params: $user_id
 * Return: array
 */
 
function isPostAlreadyLiked($user_id, $post_id) {
$query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_postLikes) . " AS lik
                     WHERE lik.user_id = " . $user_id . " and lik.post_id = " . $post_id;
$result = $this->db->query($query);
if ($result->num_rows() > 0) {
return 1;
} else {
return 0;
}
}

/**
 * Method: getLastRecordingDuration
 * Params: $user_id
 * Return: array
 */
 
public function getLastRecordingDuration($post_id,$participant_index) {
$query = "SELECT end_time from " . $this->db->dbprefix($this->tbl_participant) . "  where post_id=".$post_id." and participant_index <".$participant_index." order by participant_index desc limit 1";

$query = $this->db->query($query);
$results = $query->row();

return $results = $results->end_time;
}

/**
 * Method: getParticipantDetails
 * Params: $user_id
 * Return: array
 */

function getParticipantDetails($postid) {
$query = "Select p.participant_id as participant_id,p.assign_bars,p.participant_index,p.start_time,p.end_time,u.name as participant_name,u.avatar as participant_avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_participant) . " AS p "
. " inner join "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  on u.user_id=p.participant_id"
. "  WHERE p.post_id = " . $postid . " ORDER BY  p.id";

$query = $this->db->query($query);
$result = $query->result_array();
for ($x = 0;
$x < count($result);
$x++) {

$result[$x]['start_time'] = $result[$x]['start_time'] != "" ? $result[$x]['start_time'] : "";
$result[$x]['end_time'] = $result[$x]['end_time'] != "" ? $result[$x]['end_time'] : "";
}
return $result;
}

/**
 * Method: getAllFollowers
 * Params: $user_id
 * Return: array
 */
function getAllFollowers($userid, $myid, $offset, $limit) {

if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select f.follower_user_id as follower_id,u.name,u.avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " left join "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  on f.follower_user_id=u.user_id"
. "  WHERE f.following_user_id = " . $userid . " ORDER BY  f.id"
. " LIMIT " . $offset . ", " . $limit;


$query = $this->db->query($query);
$result = $query->result_array();
for ($x = 0;
$x < count($result);
$x++) {

$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " WHERE f.follower_user_id=" . $myid . " and f.following_user_id = " . $result[$x]['follower_id'];

$query = $this->db->query($query);

if ($query->num_rows() > 0) {
$result[$x]['is_following'] = 1;
} else {
$result[$x]['is_following'] = 0;
}
}

return $result;
}

/**
 * Method: getAllFollollowing
 * Params: $user_id
 * Return: array
 */

function getAllFollollowing($userid, $myid, $offset, $limit) {

if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select f.following_user_id as follower_id,u.name,u.avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " left join "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  on f.following_user_id=u.user_id"
. "  WHERE f.follower_user_id = " . $userid . " ORDER BY  f.id"
. " LIMIT " . $offset . ", " . $limit;


$query = $this->db->query($query);
$result = $query->result_array();
for ($x = 0;
$x < count($result);
$x++) {

$query = "Select *"
. " FROM "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. " WHERE f.follower_user_id=" . $myid . " and f.following_user_id = " . $result[$x]['follower_id'];

$query = $this->db->query($query);

if ($query->num_rows() > 0) {
$result[$x]['is_following'] = 1;
} else {
$result[$x]['is_following'] = 0;
}
}
return $result;
}

/**
 * Method: draftPosts
 * Params: $user_id
 * Return: array
 */
 

function draftPosts($userid, $myid, $offset = 0, $limit = "") {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}

 $query = "select d.id as post_id,d.title, d.bar_count,d.post_recording as audio_url,t.track_id,t.image_url,g.name as genre"
. " FROM "
. $this->db->dbprefix($this->tbl_draftPost) . " AS d "
. " left join  "
. $this->db->dbprefix($this->tbl_tracks) . " AS t"
. " on d.track_id=t.track_id"
. " left join  "
. $this->db->dbprefix($this->tbl_genre) . " AS g "
. " on t.genre=g.id "
. " WHERE  d.user_id = " . $userid . "   ORDER BY d.id DESC  LIMIT " . $offset . ", " . $limit . " ; ";

$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: usersForTag
 * Params: $user_id
 * Return: array
 */

function usersForTag($user_id, $offset, $limit) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "Select u.user_id,u.name,u.avatar,u.is_premium"
. " FROM "
. $this->db->dbprefix($this->tbl_follower). " AS f"
." INNER JOIN "
.$this->db->dbprefix($this->tbl_users). " AS u " 
. " on u.user_id = f.follower_user_id"
." INNER JOIN "
.$this->db->dbprefix($this->tbl_follower). " AS b " 
. "ON b.follower_user_id = f.following_user_id  and b.following_user_id = u.user_id "
. " WHERE is_active = 1"
. " and f.following_user_id =" . $user_id . ""
. " ORDER BY u.user_id"
. " LIMIT " . $offset . ", " . $limit;


$query = $this->db->query($query);
$result['users'] = $query->result_array();
for ($x = 0;
$x < count($result['users']);
$x++) {
$result['users'][$x]['total_post'] = $this->totalPosts($result['users'][$x]['user_id']);
$result['users'][$x]['followers_count'] = getCount('following_user_id', 'no_of_followers', 'follower', 'following_user_id', $result['users'][$x]['user_id']);
}

return $result;
}

/**
 * Method: following_newsFeed
 * Params: $user_id
 * Return: array
 */
 
function following_newsFeed($userid, $offset = 0, $limit = "") {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}


$query = "select p.post_id,p.post_description,p.user_id as initiator_id,p.filename as audio_url,u.name as initiator_name,u.avatar as initiator_avatar,p.post_type,p.post_title as title,"
. "p.post_title as title,p.total_playes,p.total_like as total_likes,p.total_like as total_likes,DATE(p.created) as post_since,"
. "p.is_locked as is_published,p.post_avatar as image_url,g.name as genre,"
. "(SELECT EXISTS(SELECT user_id FROM post_likes WHERE post_id=p.post_id and user_id='" . $userid . "'))as is_liked"
. " FROM "
. $this->db->dbprefix($this->tbl_post) . " AS p "
. "  LEFT JOIN "
. $this->db->dbprefix($this->tbl_follower) . " AS f "
. "on f.following_user_id=p.user_id"
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " ON t.track_id=p.track_id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g "
. " ON t.genre=g.id "
. " INNER JOIN  "
. $this->db->dbprefix($this->tbl_users) . " AS u"
. " ON p.user_id=u.user_id "

." where f.follower_user_id=".$userid
." OR p.user_id=".$userid        
."  group by p.post_id"
. " ORDER BY p.post_id DESC"
. " LIMIT " . $offset . ", " . $limit;


$query = $this->db->query($query);
if ($query->num_rows() > 0) {
$result['posts'] = $query->result_array();

for ($x = 0;
$x < count($result['posts']);
$x++) {
    
$query = "select avatar"
. " FROM "
. $this->db->dbprefix($this->tbl_users) . " AS u "
. "  INNER JOIN "
. $this->db->dbprefix($this->tbl_participant) . " AS p"
. " on p.participant_id=u.user_id"
. " WHERE  p.post_id = " . $result['posts'][$x]['post_id'] . "  ORDER BY p.post_id DESC; ";

$query = $this->db->query($query);
$result['posts'][$x]['participant_avatars'] = $query->result_array();
$result['posts'][$x]['post_since'] = $result['posts'][$x]['post_since'] != "" ? $result['posts'][$x]['post_since'] : "";
$result['posts'][$x]['share_message'] = "Lorem ipsum dolor sit amet";
$result['posts'][$x]['share_url'] = "http://tagalongmusic.com";
if($result['posts'][$x]['post_type']==1){
    unset($result['posts'][$x]['initiator_avatar']);
}
 unset($result['posts'][$x]['post_type']);
}

}

return $result;

}

/**
 * Method: getAllParticipant
 * Params: $user_id
 * Return: array
 */
 
function getAllParticipant($post_id) {

$query = "Select participant_id"
. " FROM "
. $this->db->dbprefix($this->tbl_participant)
. " WHERE is_active = 1"
. " and post_id =" . $post_id. "";
$query = $this->db->query($query);
return $query->result_array();
}


/**
 * Method: searchTracks
 * Params: $user_id
 * Return: array
 */
 
function searchTracks($searchtext, $offset, $limit,$user_id) {
if ($limit == 0 || $limit == "") {
$limit = 10;
}
if ($offset == 0 || $offset == "") {
$offset = 0;
}
$query = "select t.track_id,t.image_url,t.title,t.duration,t.audio_url,g.name as genre,IF(t.user_id='" . $user_id . "' AND t.approve=1, '0', t.required_tag_tokens)as required_tag_tokens, "
 . " (SELECT EXISTS(SELECT id FROM purchase_tracks WHERE track_id=t.track_id and user_id='" . $user_id . "'))as is_purchased "       
. " FROM "
. $this->db->dbprefix($this->tbl_tracks) . " AS t "
. " LEFT JOIN  "
. $this->db->dbprefix($this->tbl_genre) . " AS g"
. " ON t.genre=g.id "
. "Where ( t.title LIKE '%" . $searchtext . "%' " . " or t.description LIKE '%" . $searchtext . "%' " . " or g.name LIKE '%" . $searchtext . "%' )"        
. "ORDER BY t.track_id DESC  LIMIT " . $offset . ", " . $limit . " ; ";
$query = $this->db->query($query);
$result = $query->result_array();
return $result;
}

/**
 * Method: getSpacePlans
 * Params: $user_id
 * Return: array
 */
 
function getSpacePlans() {
$query = "Select plan_id,CONCAT(space, '', space_type) AS space,month,price*month as total_price,store_id as appstore_id "
. " FROM "
. $this->db->dbprefix($this->tbl_additional_space)
. " WHERE is_active = 1"
. " ORDER BY plan_id DESC";


$query = $this->db->query($query);
return $query->result_array();
}

/**
 * Method: user_Plan_Items
 * Params: $user_id
 * Return: array
 */
 
 
function user_Plan_Items($user_id) {
 $query = " SELECT
            u.token as tag_tokens,
            u.additional_space as remaining_space,IF( CURDATE() > date(u.premium_expiry), date(DATE_ADD(NOW(),INTERVAL 2 DAY)), date(u.premium_expiry))as premium_expiry
            
            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.is_active = 1 AND  u.user_id = " . $user_id . " limit 1 ";

            $result = $this->db->query($query);
            $results = $result->row_array();
             return $results;
           
}

/**
 * Method: getcards
 * Params: $user_id
 * Return: array
 */
 
function getcards($user_id) {
 $query = "SELECT RIGHT(card_number, 4) as last_digits,id as card_id,is_primary "
. "  FROM "
.  $this->db->dbprefix($this->tbl_billing_address)
. " WHERE is_active = 1 and user_id=".$user_id
. " ORDER BY id DESC";


$query = $this->db->query($query);
$result=$query->result_array();


return $result;
}
}

//End Class