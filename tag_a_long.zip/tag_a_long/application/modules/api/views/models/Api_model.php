<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Api_model extends CI_Model {

    var $tbl_users = 'users';
    var $tbl_locations = 'location';
    var $tbl_users_preferred_location = 'user_preferred_location';
    var $tbl_user_firebase_tokens = 'user_firebase_tokens';
    var $tbl_country = "country";
    var $tbl_city = "city";
    var $tbl_banner = "banner";
    var $tbl_category = "category";
    var $tbl_class = "class";
    var $tbl_private_class = "private_class";
    var $tbl_private_class_schedule = "private_class_schedule";
    var $tbl_liked_class = "liked_class";
    var $tbl_liked_guru = "liked_guru";
    var $tbl_guru_skill = "guru_skill";
    var $tbl_guru_rating = "guru_rating";
    var $tbl_class_member = "class_member";
    var $tbl_user_rating = "user_rating";
    var $tbl_achievement = "achievement";
    var $tbl_class_schedule = "class_schedule";
    var $tbl_messages = "messages";
    var $tbl_thread = "thread";
    var $tbl_filter = "filter";
    var $tbl_guru_rating_questions = "guru_rating_questions";
    var $tbl_user_rating_questions = "user_rating_questions";
    var $tbl_notifications_logs = "notifications_logs";
    var $tbl_activity_logs = "activity_logs";
    
    
    var $tbl_users_feedback = 'users_feedback';
    var $tbl_products = "products";
    var $tbl_products_images = "products_images";
    var $tbl_subcategories = "sub_categories";
//    var $tbl_categories = "categories";
    var $tbl_products_filters = "products_filters";
    var $tbl_users_delivery_address = "users_delivery_address";
    var $tbl_users_carts_products = "users_carts_products";
    var $tbl_vendor = "vendor";
    var $tbl_notifications = "notifications";
    var $tbl_orders_feedback = "orders_feedback";
    
    var $tbl_users_orders = "users_orders";
    var $tbl_orders_products = "orders_products";
    var $tbl_orders_vendors = "orders_vendors";
    var $tbl_delivery_options = "delivery_options";
    var $tbl_orders_shipping = "orders_shipping";
    var $tbl_tracks = "tracks";
    
//    var $tbl_albums = 'albums';
//    var $tbl_artists = 'artists';
//    var $tbl_playlists = 'playlists';
//    var $tbl_playlist_tracks = 'playlist_tracks';
//    var $tbl_collection = 'collections';
//    var $tbl_collection_playlists = 'collection_playlists';
//    var $tbl_collection_albums = 'collection_albums';
//    var $tbl_racks = 'racks';
//    var $tbl_rack_albums = 'rack_albums';
//    var $tbl_tracks = 'tracks';
//    var $tbl_albums_purchase_histrory = 'albums_purchase_histrory';
//    var $tbl_cms_pages = 'cms_pages';
//    var $tbl_genre = 'genre';

    public function __construct() {
        parent::__construct();
    }

//End __construct

    /**
     * Method: insert
     * Return: id
     */
    function create($table, $data) {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    /**
     * Method: update
     * Return:
     */
    function update($table, $data, $where) {
        $this->db->where($where);
        return $this->db->update($table, $data);
    }

    /**
     * Method: delete
     * Return:
     */
    function delete($table, $where) {
        $this->db->where($where);
        return $this->db->delete($table);
    }

    /**
     * Method: ajaxLogin
     * params: $_POST
     * Retruns:
     */
    public function ajaxLogin($email, $passwrd) {
        $password = md5($passwrd);
        $this->db->select('*');
//        $this->db->where('status', 1);
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->limit(1);
        $qry = $this->db->get($this->db->dbprefix($this->tbl_users));
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $result) {
                if ($result-> is_active == 0) {
                  return -1;  
                } 
                $user_session['user_id'] = $result->user_id;
            }
            
            
            $data = array(
                'last_activity_time' => time());
            $this->db->where('user_id', $user_session['user_id']);
            $this->db->update($this->db->dbprefix($this->tbl_users), $data);
            return $user_session['user_id'];
        } else {
            return 0;
        }
    }

    /**
     * Method: ajaxLoginPhone
     * params: $_POST
     * Retruns:
     */
    public function ajaxLoginPhone($phone, $passwrd) {
        $password = md5($passwrd);
        $this->db->select('*');
        $this->db->where('is_active', 1);
        $this->db->where('phone_no', $phone);
        $this->db->where('password', $password);
        $this->db->limit(1);
        $qry = $this->db->get($this->db->dbprefix($this->tbl_users));
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $result) {
                $user_session['user_id'] = $result->user_id;
            }
            $data = array(
                'last_activity_time' => time());
            $this->db->where('user_id', $user_session['user_id']);
            $this->db->update($this->db->dbprefix($this->tbl_users), $data);
            return $user_session['user_id'];
        } else {
            return 0;
        }
    }
    
    
    
      /**
     * Method: verify_category
     * Params: $email
     * Return: True
     */
    function verify_category($category) {
        $query = " SELECT  c.id
                     FROM " . $this->db->dbprefix($this->tbl_category) . " AS c
                     WHERE c.id = " . $category . " ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }
    
    
    /**
     * Method: verify_product
     * Params: $email
     * Return: True
     */
    function verify_product($product) {
        $query = " SELECT  p.product_id
                     FROM " . $this->db->dbprefix($this->tbl_products) . " AS p
                     WHERE p.product_id = " . $product . " ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }
    
    
     /**
     * Method: check_category_type
     * Params: $email
     * Return: True
     */
    function check_category_type($category) {
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_categories) . " AS c
                     WHERE c.super_category_id = " . $category ;
        $result = $this->db->query($query);
        return $result->num_rows();
    }
    
    

    /**
     * Method: verify_email
     * Params: $email
     * Return: True
     */
    function verify_email($email) {
        
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.email = '" . $email . "' ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $resultArray = $result->row_array();
            if ($this->isUserInactive($resultArray['user_id']) == 1){
                return -1;
            }
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * Method: verifyUserEmail
     * Params: $email
     * Return: True
     */
    function verifyUserEmail($email, $user_id) {
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.email = '" . $email . "' AND user_id <> " . $user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * Method: verifyUserNo
     * Params: $verify_no
     * Return: True
     */
    function verifyUserNo($verify_no,$user_id) {
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.phone_no = '" . $verify_no . "'  AND user_id <> " . $user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * Method: verify_phone
     * Params: $fb_identifier_id
     * Return: True
     */
    function verify_phone($phone_no) {
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.phone_no = '" . $phone_no . "' ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * Method: verify_user
     * Params: $fb_identifier_id
     * Return: True
     */
    function verify_user($media,$media_id) {
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.".$media." = " . $media_id . " ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }
    
    function isUserInactive($user_id){
        $query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        if ($resultArray['is_active'] == 0){
            return 1;
        }
        else if ($resultArray['is_active'] == 1){
            return 0;
        } 
    }
    
    function getBadgeIncremented($user_id) {
        $query = " SELECT  *
                     FROM user  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        $badge = $resultArray['badge'];
        $badge++;
        $post_data = array();
        $post_data['badge'] = $badge;
        $this->update($this->tbl_users,$post_data,array('user_id' => $user_id));
        return $badge;
    }
    
    
     function getMessageBadgeIncremented($user_id) {
        $query = " SELECT  *
                     FROM user  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        $badge = $resultArray['message_badge'];
        $badge++;
        $post_data = array();
        $post_data['message_badge'] = $badge;
        $this->update($this->tbl_users,$post_data,array('user_id' => $user_id));
        return $badge;
    }
    
    
    function getMessageBadgeDecremented($user_id) {
        $query = " SELECT  *
                     FROM user  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        $badge = $resultArray['message_badge'];
        $badge--;
        if ($badge < 0){
            $badge = 0;
        }
        $post_data = array();
        $post_data['message_badge'] = $badge;
        $this->update($this->tbl_users,$post_data,array('user_id' => $user_id));
        return $badge;
    }
    
    
    
    /**
     * Method: verify_user
     * Params: $fb_identifier_id
     * Return: True
     */
    function verify_user_twitter($user_twId) {
        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.user_twid  = " . $user_twId . " ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 0;
        } else {
            return 1;
        }
    }
    
    
    
    

    /**
     * Method: verify_user_id
     * Params: $fb_identifier_id
     * Return: True
     */
    function verify_user_id($user_id) {
        $query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        if ($result->num_rows() > 0 && $resultArray['is_active'] == 1) {
            return 1;
        } 
        else if ($result->num_rows() > 0 && $resultArray['is_active'] == 0) {
            return -1;
        }
        else {
            return 0;
        }
    }
    
    function verifyUserPin($user_id,$pin){
        $query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " and u.pin = ".$pin;
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        if ($result->num_rows() > 0 && $resultArray['status'] == 1) {
            return 1;
        }
        else if ($result->num_rows() > 0 && $resultArray['status'] == 0) {
            return -1;
        }
        else {
            return 0;
        }

    }
    
    function ifExistUserDevice($user_id, $device_id){
        $query = " SELECT  *
                     FROM user_firebase_tokens  AS u 
                     WHERE  u.device_id = '".$device_id."'";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    
   

    /**
     * Method: get_user_data
     * Params: $user_id
     * Return: array
     */
    function get_user_data($user_id) {
        $query = " SELECT
                u.user_id,
                u.name,
                u.email,
                u.phone_no,
                u.avatar,
                u.fb_url,
                u.tw_url,
                u.soundcloud_url,
                u.web_url,
                u.cover_photo,
                u.is_verified

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.is_active = 1 AND  u.user_id = " . $user_id . " limit 1 ";
        $result = $this->db->query($query);

//        if ($result->num_rows() > 0) {
        $results = $result->row_array();
        if ($results['avatar'] <> '') {
            $results['avatar'] = $results['avatar'];
        }
        return $results;
//        }
    }
    
    
    function getFirebaseRegistrationIds($user_id){
        $query = " SELECT u.firebase_token "
            . "FROM " . $this->db->dbprefix($this->tbl_user_firebase_tokens) . " AS u "
            ." WHERE u.user_id = " . $user_id ;
        $result = $this->db->query($query);
        $result = $result->result_array();
        $results = array();
        for($x=0; $x<count($result); $x++){
            $temp = $result[$x];
            $results[$x] = $temp['firebase_token'];
        }
        return $results;
    }
    
    function get_student_data($user_id) {
        $query = " SELECT
                u.user_id,
                u.name,
                u.email,
                u.phone_no,
                u.avatar,
                u.date_of_birth,
                u.gender,
                u.city_id,
                u.country_id,
                u.about_me,
                u.is_guru,
                u.is_verified,
                u.user_average_rating as rating

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.status = 1 AND  u.user_id = " . $user_id . " limit 1 ";
        $result = $this->db->query($query);

//        if ($result->num_rows() > 0) {
        $results = $result->row_array();
        if ($results['avatar'] <> '') {
            $results['avatar'] = $results['avatar'];
        }
        return $results;
//        }
    }
    
    
    
    
     /**
     * Method: get_user_location
     * Params: $user_id
     * Return: array
     */
    function get_user_location($user_id) {
        $query = " SELECT n.location_id,n.latitude,n.longitude,n.city,n.country,n.street_address,n.post_code 

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u "
            . " INNER JOIN  "
            . $this->db->dbprefix($this->tbl_locations) . " AS n"
            . " ON n.location_id = u.location_id  "
            ." WHERE u.status = 1 AND  u.user_id = " . $user_id . " limit 1 ";
        $result = $this->db->query($query);

        if ($result->num_rows() > 0) {
            $results = $result->row_array();
        }
        else{
            $results = "";
        }
        return $results;
    }
    
    
    
    /**
     * Method: get_user_location
     * Params: $user_id
     * Return: array
     */
    function get_user_preferred_location($user_id) {
        $query = " SELECT n.location_id,n.latitude,n.longitude,n.city_id,n.country_id,n.street_address,n.post_code 

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u "
            . " INNER JOIN  "
            . $this->db->dbprefix($this->tbl_users_preferred_location) . " AS p"
            . " ON p.user_id = u.user_id  "
            . " INNER JOIN  "
            . $this->db->dbprefix($this->tbl_locations) . " AS n"
            . " ON n.location_id = p.location_id  "
            ." WHERE u.status = 1 AND  u.user_id = " . $user_id ;
        $result = $this->db->query($query);
        $results = $result->result_array();
        return $results;
    }
    
    
    
    
    /**
     * Method: getCountries
     * Params: $user_id
     * Return: array
     */
    function getCountries() {
        $query = " SELECT  id as country_id, name as country_name 
            FROM " . $this->db->dbprefix($this->tbl_country);
        $result = $this->db->query($query);
        $results = $result->result_array();
        return $results;
    }
    
    
    /**
     * Method: getCities
     * Params: $user_id
     * Return: array
     */
    function getCities($country_id) {
        $query = " SELECT  id as city_id, name as city_name 
            FROM " . $this->db->dbprefix($this->tbl_city)
            ." WHERE country_id = ".$country_id;
        $result = $this->db->query($query);
        $results = $result->result_array();
        return $results;
    }
    
    
    
    
    
    
    
    
    
    
    
    
     /**
     * Method: get_user_delivery_address
     * Params: $user_id
     * Return: array
     */
    function get_user_delivery_address($user_id) {
        $query = " SELECT
                d.delivery_address_id,
                d.recipient_name,
                d.recipient_surname,
                d.country,
                d.postal_code,
                d.city,
                d.street_line

            FROM " . $this->db->dbprefix($this->tbl_users_delivery_address) . " AS d
            WHERE d.user_id = " . $user_id;
        $result = $this->db->query($query);
        $results = $result->result_array();
        
        for($x=0;$x<count($results);$x++){
            $temp = $results[$x];
            $temp['postal_code'] = '||'.$temp['postal_code'];
            $results[$x] = $temp;
        }
        
        return $results;
    }
    
    function getBanner(){
        $query = "Select *"
                ." FROM "
                .$this->db->dbprefix($this->tbl_banner) 
                . "  ORDER BY id DESC LIMIT 5" ;
                
              
        $query = $this->db->query($query);
        return $query->result_array();
        
    }
    
    function getCategoriesHome(){
        $query = "Select *"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category) 
                . "  ORDER BY id DESC LIMIT 20" ;
                
              
        $query = $this->db->query($query);
        return $query->result_array();
    }
    
    function getFeaturedGuruHome($user_id){
        $gurus = array();
        $user_city_id = getVal('city_id', 'user', 'user_id', $user_id);
        
        $query = "Select u.user_id as guru_id,u.name,u.avatar,u.guru_average_rating as rating"
                ." FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " WHERE u.city_id = " . $user_city_id . " and u.status = 1 and u.is_guru = 1 and u.is_guru_featured = 1 "
                . "  ORDER BY u.guru_average_rating DESC LIMIT 10" ;
 
             
        $query = $this->db->query($query);
        $is_feature_guru = $query->result_array();
        $gurus = $is_feature_guru;
        $diff = 10 - count($gurus);
        if($diff > 0){
            $query = "Select u.user_id as guru_id,u.name,u.avatar,u.guru_average_rating as rating"
                ." FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " WHERE u.city_id = " . $user_city_id . " and u.is_guru = 1 and u.status = 1 and u.is_guru_featured = 0 "
                . "  ORDER BY u.guru_average_rating DESC LIMIT ".$diff ;
            $query = $this->db->query($query);
            $non_feature_guru = $query->result_array();
            for ($x = 0 ; $x < count($non_feature_guru); $x++){
                $gurus[count($gurus)] = $non_feature_guru[$x];
            }
        }
        return $gurus;
    }
//    class = {title,category_color,category_icon, category_name}
    function getFeaturedClassHome($user_id){
        $classes = array();
        $user_city_id = getVal('city_id', 'user', 'user_id', $user_id);
        
        $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE l.city_id = " . $user_city_id . " and c.is_featured = 1 and g.status = 1 "
                . "  ORDER BY c.id DESC LIMIT 10" ;
                
              
        $query = $this->db->query($query);
        $is_feature_classes = $query->result_array();
        $classes = $is_feature_classes;
        $diff = 10 - count($is_feature_classes);
        if($diff >0){
            $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "    
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE l.city_id = " . $user_city_id . " and c.is_featured = 0 and g.status = 1 "
                
                . "  ORDER BY c.class_requests DESC LIMIT ".$diff ;
            $query = $this->db->query($query);
            $top_trending = $query->result_array();
            for ($x = 0 ; $x < count($top_trending); $x++){
                $classes[count($classes)] = $top_trending[$x];
            }
            
        }
        
        return $classes;
        
    }

    
    function verifyCategory($cat_id){
        $query = "Select *"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category). " AS c "
                . " WHERE c.id = " . $cat_id;
        $query = $this->db->query($query);
        if(count($query->result_array())>0){
            return true;
        }
        else{
            return false;
        }
    }
    
    function getCategories($offset, $limit){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
        $query = "Select c.id,c.bg_color as category_color, c.icon as category_icon, c.name as category_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category). " AS c "
                . " WHERE c.super_category_id is null "
                . " LIMIT " . $offset . ", " . $limit . " ; ";
        $query = $this->db->query($query);
        
        $result = $query->result_array();
        
        for($x = 0; $x < count($result); $x++){
            $query = "Select *"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category). " AS c "
                . " WHERE c.super_category_id = " . $result[$x]['id'];
                $query = $this->db->query($query);
                
            if($query->num_rows() > 0){
                $result[$x]['has_sub_category'] = 1;
            }
            else{
                $result[$x]['has_sub_category'] = 0;
            }
                
        }
        
        return $result;
        
    }
    
    function getSubCategories($cat_id){
        $query = "Select c.id ,c.bg_color as category_color, c.icon as category_icon, c.name as category_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category). " AS c "
                . " WHERE c.super_category_id = " . $cat_id;
        $query = $this->db->query($query);
        return $query->result_array();
    }

    function getCatGurus($cat_id,$user_id,$offset,$limit){
        $gurus = array();
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        $query = "Select u.user_id as guru_id,u.name, u.avatar,u.guru_average_rating as rating, (Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = u.city_id limit 1) as city_name, (Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = u.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_guru_skill) . " AS c"
                . " ON u.user_id = c.guru_id  "
                . " WHERE u.status = 1 and c.category_id = " . $cat_id. " LIMIT " . $offset . ", " . $limit . " ; ";
        $query = $this->db->query($query);
        $result = $query->result_array();
         for($x=0; $x< count($result); $x++){
                $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_guru). " AS c "
                    . " WHERE c.guru_id = " . $result[$x]['guru_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $result[$x]['is_liked'] = 1;
                }
                else{
                    $result[$x]['is_liked'] = 0;
                }
         }
       
        
        $gurus = $result;
        return $gurus;
    }
    
    function getCatClasses($cat_id,$user_id,$offset,$limit){
        $classes = array();
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
         $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "
                
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE g.status = 1 and c.category_id = " . $cat_id. " LIMIT " . $offset . ", " . $limit . " ; "; 
         $query = $this->db->query($query);
         $result = $query->result_array();
         for($x=0; $x< count($result); $x++){
                $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $result[$x]['is_liked'] = 1;
                }
                else{
                    $result[$x]['is_liked'] = 0;
                }
         }
         $classes = $result;
         return $classes;
    }
    
    
    function getLikedGurus($user_id,$offset,$limit){
        $gurus = array();
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        $query = "Select u.user_id as guru_id,u.name,u.avatar,u.guru_average_rating as rating,".
                 "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = u.city_id limit 1) as city_name,"
                ."(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = u.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_liked_guru) . " AS c"
                . " ON u.user_id = c.guru_id  "
                . " WHERE u.status = 1 and c.user_id = " . $user_id. " LIMIT " . $offset . ", " . $limit . " ; ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        
        for($x = 0 ; $x < count($result) ; $x++){
            $result[$x]['is_liked'] = 1;
        }
        
        $gurus = $result;
        return $gurus;
    }
    
    
    
    
    function getUserNotification($user_id,$offset,$limit){
       if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }

        
        
        $query = "Select c.*, n.avatar as sender_avatar"
                ." FROM "
                .$this->db->dbprefix($this->tbl_notifications_logs). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                . " ON n.user_id = c.sender_id  "
                . " WHERE c.user_id = " . $user_id. "   ORDER BY c.id DESC  LIMIT " . $offset . ", " . $limit . " ; "; 
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;
    }
    
    
    function getLikedClasses($user_id,$offset,$limit){
        $classes = array();
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
       $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_liked_class) . " AS q"
                . " ON q.class_id = c.id  "
                
                . " WHERE g.status = 1 and q.user_id = " . $user_id. " LIMIT " . $offset . ", " . $limit . " ; "; 
        $query = $this->db->query($query);
        $result = $query->result_array();
        
        for($x = 0 ; $x < count($result) ; $x++){
            $result[$x]['is_liked'] = 1;
        }
        
        $classes = $result;
        return $classes;
    }
    
    function getGuruProfile($user_id,$guru_id){
         $query = "Select u.user_id as guru_id,u.name,u.avatar,u.guru_average_rating as rating,u.created as member_since,".
                 "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = u.city_id limit 1) as city_name,"
                ."(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = u.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " WHERE u.user_id = " . $guru_id;
         
        $query = $this->db->query($query);
        $result = $query->result_array();
        if($result){
            $guru = $result[0];
            $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_guru). " AS c "
                    . " WHERE c.guru_id = " . $guru['guru_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $guru['is_liked'] = 1;
                }
                else{
                    $guru['is_liked'] = 0;
                }
                
            
                
                $query = "Select u.id as skill_id,c.id as category_id ,c.bg_color as color, c.icon as icon, c.name as name"
                . " FROM "
                .$this->db->dbprefix($this->tbl_guru_skill). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS c"
                . " ON u.category_id = c.id  "
                . " WHERE u.guru_id = " . $guru_id. " ; ";
                $query = $this->db->query($query);
                $result = $query->result_array();
                $guru['skills'] = $result;
                
                
                $query = "Select u.name,u.avatar,c.rating , c.note as description, c.time_stamp as date"
                . " FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_guru_rating) . " AS c"
                . " ON u.user_id = c.user_id  "
                . " WHERE c.guru_id = " . $guru_id. " LIMIT " . 0 . ", " . 10 . " ; ";
                $query = $this->db->query($query);
                $result = $query->result_array();
                $guru['reviews'] = $result;
                
                
            return $guru;
        }
        else{
            return NULL;
        }
    }
    
    function getGuruReviews($guru_id,$offset,$limit){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
        $reviews = array();
        
        $query = "Select u.name,u.avatar,c.rating , c.note as description, c.time_stamp as date"
                . " FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_guru_rating) . " AS c"
                . " ON u.user_id = c.user_id  "
                . " WHERE c.guru_id = " . $guru_id. " LIMIT " . $offset . ", " . $limit . " ; ";
                $query = $this->db->query($query);
                $result = $query->result_array();
                
        $reviews = $result;
        return $reviews;
    }
    
    function getGuruClasses($guru_id,$user_id,$offset,$limit,$skill_id){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
        $classes = array();
        
        $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE c.guru_id = " . $guru_id. " and c.category_id = ".$skill_id." LIMIT " . $offset . ", " . $limit . " ; "; 
        
        $query = $this->db->query($query);
         $result = $query->result_array();
         if($user_id<>''){
         for($x=0; $x< count($result); $x++){
                $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $result[$x]['is_liked'] = 1;
                }
                else{
                    $result[$x]['is_liked'] = 0;
                }
         }
         }
        $classes = $result;
        
        return $classes;
    }
    
    
    function categoryGraph(){
        
        $query = "Select n.id, n.name, count(l.id) as max_class"
                ." FROM "
                . $this->db->dbprefix($this->tbl_activity_logs) . " AS l"
                ." INNER JOIN "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " ON l.class_id = c.id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                . " WHERE l.action = 'Create Class'  and DATEDIFF(NOW(), l.timestamp) <= 30 "
                . " GROUP BY n.id  order by max_class desc LIMIT 5";
        

        $query = $this->db->query($query);
        $create_class = $query->result_array();
       
        $query = "Select n.id, n.name, count(l.id) as max_request"
                ." FROM "
                . $this->db->dbprefix($this->tbl_activity_logs) . " AS l"
                ." INNER JOIN "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " ON l.class_id = c.id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                . " WHERE l.action = 'Requested Class'  and DATEDIFF(NOW(), l.timestamp) <= 30 "
                . " GROUP BY n.id  order by max_request desc LIMIT 5";
        
        
        $query = $this->db->query($query);
        $requested_class = $query->result_array();
        
        
//        print_r($create_class);
//        print_r($requested_class);
//        exit;
        
        
        
        $result_array = array();
        $create_id_not_found =array();
        
        for ($i=0; $i<count($create_class); $i++){
            $current = $create_class[$i]; 
            for($j=0; $j<count($requested_class); $j++){
                if ($current["id"] == $requested_class[$j]["id"]){
                    $temp["category_id"] = $current["id"];
                    $temp["category_name"] = $current["name"];
                    $temp["category_value"] = (($current["max_class"] * 10) + $requested_class[$j]["max_request"]);
                    $result_array[count($result_array)] = $temp;
                    $current = NULL;
                    break;
                }
            }
            if($current != NULL){
                $temp["category_id"] = $current["id"];
                $temp["category_name"] = $current["name"];
                $temp["category_value"] = ($current["max_class"] * 10);
                $result_array[count($result_array)] = $temp;
                    
            }
        }
       
        if(count($result_array) < 5){
            
            for ($i=0; $i<count($requested_class); $i++){
            $current = $requested_class[$i]; 
            for($j=0; $j<count($create_class); $j++){
                if ($current["id"] == $create_class[$j]["id"]){
                    $current = NULL;
                }
            }
                if($current != NULL){
                    $temp["category_id"] = $current["id"];
                    $temp["category_name"] = $current["name"];
                    $temp["category_value"] = ($current["max_request"]);
                    $result_array[count($result_array)] = $temp;
                    
                }
            }
        }
       
//        print_r($result_array);
//        exit;
        
        $sorted_array  = usort($result_array,  array($this, "mysort"));
        
        $returned_array = array();
        for ($x = 0; $x < count($result_array) && $x < 5; $x++){
            $returned_array[$x] = $result_array[$x];
        }
        
        return $returned_array;
//        print_r($result_array);
//        exit;
        
    }
    
    function mysort($a,$b){
      if ($a["category_value"] == $b["category_value"]) {
        return 0;
    }
    return ($a["category_value"] < $b["category_value"]) ? 1 : -1;
  }

    
    function getGuruPrivateClassesCount($guru_id){
        $query = "Select count(*) as count"
                 ." FROM "
                .$this->db->dbprefix($this->tbl_private_class). " AS c "
                . " WHERE c.guru_id = " . $guru_id. " and c.is_approved = 0  ; "; 
         $query = $this->db->query($query);
         $result = $query->result_array()[0]['count'];
         return $result;
    }
    
    
    function getGuruHomeClasses($guru_id){
        
        
        $classes = array();
        
        $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE c.guru_id = " . $guru_id; 
        
        $query = $this->db->query($query);
        $result = $query->result_array();
        
        $classes = $result;
        
        
        for ($x = 0 ; $x < count($classes); $x++){
            $temp = $classes[$x];
            $query = "Select count(*) as pending_count"
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                  . " WHERE l.class_id = " . $temp['class_id'] ." and l.is_approved = 0  ; "; 
            $query = $this->db->query($query);
            $temp['pending_count'] = $query->result_array()[0]['pending_count'];
            $classes[$x] = $temp;
        }
        
        return $classes;
    }
    
    function getPrivateGuruAcceptedClasses($guru_id){
//        if ($limit == 0 || $limit == "") {
//            $limit = 10;
//        }
//        if ($offset == 0 || $offset == "") {
//            $offset = 0;
//        }
        
        $classes = array();
        
        $query ="Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date"
                ." FROM "
                .$this->db->dbprefix($this->tbl_private_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                . " WHERE c.guru_id = " . $guru_id. " and c.is_approved = 1   ; "; 
         $query = $this->db->query($query);
         $result = $query->result_array();
         
        $classes = $result;
        
        return $classes;
    }
    
    
    function getPrivateGuruPendingClasses($guru_id,$offset,$limit){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
        $classes = array();
        
        $query ="Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date, c.start_date, u.user_id as student_id,u.name as student_name, u.avatar as student_avatar "
                ." FROM "
                .$this->db->dbprefix($this->tbl_private_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS u"
                . " ON u.user_id = c.user_id  "
                . " WHERE c.guru_id = " . $guru_id. " and c.is_approved = 0   LIMIT " . $offset . ", " . $limit . " ; "; 
         $query = $this->db->query($query);
         $result = $query->result_array();
         
        $classes = $result;
        
        return $classes;
    }
    
    
    
    
    function searchGurus($user_id,$city_id,$country_id,$category_id,$filter_id,$query_text,$offset,$limit){
        if($offset == '' || $offset <= 0){
            $offset = 0;
        }
        if($limit == '' || $limit <= 0){
            $limit = 10;
        }
        
        $query =  "Select Distinct n.user_id as guru_id, n.name, n.avatar,n.guru_average_rating as rating, "
                . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = n.city_id limit 1) as city_name,"
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = n.country_id limit 1) as country_name"
                ." From "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_guru_skill) . " AS l"
                . " ON l.guru_id = n.user_id  "
                ." LEFT JOIN "
                . $this->db->dbprefix($this->tbl_category) . " AS q"
                . " ON l.category_id = q.id  OR q.super_category_id = l.category_id "
                 . " LEFT JOIN  "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " ON n.user_id = c.guru_id  "
                . " where n.status = 1 and n.is_guru = 1 "
                ;
        $cityString = "";$countryString = ""; $categoryString = "";
        if($city_id != 0){
            $cityString = " n.city_id =  ".$city_id;
        }
        
        if($country_id != 0){
            $countryString = " n.country_id = ".$country_id;
        }
//        super_category_id
        if($category_id != 0){
            $categoryString = " ( l.category_id = ".$category_id . " or q.super_category_id = ".$category_id." ) ";
        }
        
        if($cityString != ""){
            $query = $query." and ".$cityString;
            if($countryString != ""){
                $query = $query." and ".$countryString;
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
            else{
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
        }
        else{
            if($countryString != ""){
                $query = $query ." and ". $countryString;
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
            else{
                if($categoryString != ""){
                    $query = $query." and ". $categoryString;
                }
            }
        }
        
        $query = $query. " and ( n.name LIKE '%" . $query_text. "%' ". " or c.name LIKE '%" . $query_text. "%' ". " or q.name LIKE '%" . $query_text. "%' ) ";
        if($filter_id == 1){
            $query = $query. " ORDER BY n.user_id DESC  ";
        }
        else if ($filter_id == 2){
            $query = $query. " ORDER BY n.guru_average_rating DESC  ";
        }
        
        $query = $query . " LIMIT " . $offset . ", " . $limit . " ; ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        for($x=0; $x< count($result); $x++){
                $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_guru). " AS c "
                    . " WHERE c.guru_id = " . $result[$x]['guru_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $result[$x]['is_liked'] = 1;
                }
                else{
                    $result[$x]['is_liked'] = 0;
                }
         }
        
        // --------------- Categories  
         $result1 = $result;
                 
        // ---------------- Categor     
        
        return $result;
    }
    
    
    
    function searchClasses($user_id,$city_id,$country_id,$category_id,$filter_id,$query_text,$offset,$limit){
        if($offset == '' || $offset <= 0){
            $offset = 0;
        }
        if($limit == '' || $limit <= 0){
            $limit = 10;
        }
        
           $query = "Select Distinct c.id as class_id,c.name as title,c.end_date ,n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." From "
                . $this->db->dbprefix($this->tbl_class) . " AS c"
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "

                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON c.location_id = l.location_id  "
                ." LEFT JOIN "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON c.category_id = n.id OR n.super_category_id = c.category_id "
                ;
           
        $cityString = "";$countryString = ""; $categoryString = "";
        if($city_id != 0){
            $cityString = " l.city_id =  ".$city_id;
        }
        
        if($country_id != 0){
            $countryString = " l.country_id = ".$country_id;
        }
        
        if($category_id != 0){
            $categoryString = " ( c.category_id = ".$category_id." or n.super_category_id =  ".$category_id." ) ";
        }
        
        if($cityString != ""){
            $query = $query." where g.status = 1 and ".$cityString;
            if($countryString != ""){
                $query = $query." and ".$countryString;
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
            else{
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
        }
        else{
            if($countryString != ""){
                $query = $query. " where g.status = 1 and  ". $countryString;
                if($categoryString != ""){
                    $query = $query." and ".$categoryString;
                }
            }
            else{
                if($categoryString != ""){
                    $query = $query." where g.status = 1 and  ". $categoryString;
                }
            }
        }
        
        $query = $query. " and ( c.name LIKE '%" . $query_text. "%' ". " or n.name LIKE '%" . $query_text. "%' ) ";
        if($filter_id == 1){
            $query = $query. " ORDER BY c.id DESC  ";
        }
        else if ($filter_id == 2){
            $query = $query. " ORDER BY c.class_requests DESC  ";
        }
        
       
        
        $query = $query . " LIMIT " . $offset . ", " . $limit . " ; ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        for($x=0; $x< count($result); $x++){
                $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                $query = $this->db->query($query);
                if(count($query->result_array())>0){
                    $result[$x]['is_liked'] = 1;
                }
                else{
                    $result[$x]['is_liked'] = 0;
                }
         }
        
        
        return $result;
    }
    
    
    
    function getAllApprovedStuddents ($guru_id){
        $sql = "SELECT u.user_id FROM `class` as c 
          INNER JOIN class_member AS cm on cm.class_id = c.id
          INNER JOIN user as u on u.user_id = cm.user_id
          WHERE c.guru_id=" . $guru_id . " AND cm.is_approved=1
          GROUP BY cm.user_id";
        $results = $this->db->query($sql)->result_array(); 
        return $results;
    }
    
    function getClassApprovedStudents($class_id){
        $query = "Select n.user_id as student_id,n.avatar,n.name,n.user_average_rating as rating,l.is_approved as req_status,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = n.city_id limit 1) as city_name,"
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = n.country_id limit 1) as country_name"
                ." FROM "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                . " ON l.user_id = n.user_id " 
                . " WHERE n.status = 1 and l.class_id = " . $class_id ." and l.is_approved = 1 ; "; 
         $query = $this->db->query($query);
         $students = $query->result_array();
         return $students;
    }
    
        function getClassPendingStudents($class_id){
        $query = "Select n.user_id as student_id,n.avatar,n.name,n.user_average_rating as rating,l.is_approved as req_status,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = n.city_id limit 1) as city_name,"
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = n.country_id limit 1) as country_name"
                ." FROM "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                . " ON l.user_id = n.user_id " 
                . " WHERE n.status = 1 and l.class_id = " . $class_id ." and l.is_approved = 0 ; "; 
         $query = $this->db->query($query);
         $students = $query->result_array();
         return $students;
    }
    
//    getClassApprovedStudents
//    getClassPendingStudents
           
    function getSearchCategories(){
        
        $query = "Select c.id as category_id , c.name as category_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_category). " AS c ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;
    }
    
    function getSearchFilters(){
        $query = "Select c.id as filter_id , c.name as filter_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_filter). " AS c ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;
    }
    
    
    function getClassDetail($user_id,$class_id){
//        echo '11111';
        $query = "Select c.id as class_id,c.name as class_name, c.end_date,c.category_id,c.guru_id,n.avatar,n.name,n.guru_average_rating as rating,c.class_limit,c.last_joining_date,c.start_date,c.start_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                . "(Select cat.name from " . $this->db->dbprefix($this->tbl_category) . " As cat where cat.id = c.category_id limit 1) as category_name," 
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                ." FROM "
                .$this->db->dbprefix($this->tbl_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                . " ON n.user_id = c.guru_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                . " WHERE c.id = " . $class_id ." ; "; 
         $query = $this->db->query($query);
         $class = $query->result_array()[0];
         
//         echo '22222222';
         
         $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $class['class_id'] ." and c.user_id = ".$user_id;
                    $query = $this->db->query($query);
                    if(count($query->result_array())>0){
                        $class['is_liked'] = 1;
                    }
                    else{
                        $class['is_liked'] = 0;
                    }
         
         
          $query = "Select *"
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                  . " WHERE l.class_id = " . $class_id ." and l.user_id = ".$user_id ." ; "; 
         $query = $this->db->query($query);
         if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];
            if($result['is_approved'] == 0){
                $class['user_req_status'] = 0;
            }
            else if ($result['is_approved'] == 1){
                $class['user_req_status'] = 1;
            }
        } else {
            $class['user_req_status'] = 2;
        }
        
        $query = "Select id,class_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,DATE_FORMAT(start_time, '%H:%i') AS start_time,DATE_FORMAT(end_time, '%H:%i') AS end_time "
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_class_schedule) . " AS l"
                  . " WHERE l.class_id = " . $class_id ." ; "; 
         $query = $this->db->query($query);
         if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];
            $class['repeat'] = $result;
        }
         
        
         $query = "Select count(*) as approved_count"
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                  
                  . " INNER JOIN  "
                  . $this->db->dbprefix($this->tbl_users) . " AS g"
                  . " ON l.user_id = g.user_id  "
                  
                 . " WHERE g.status = 1 and l.class_id = " . $class_id ." and l.is_approved = 1  ; "; 
         $query = $this->db->query($query);
        $class['approved_count'] = $query->result_array()[0]['approved_count'];
         
         $query = "Select count(*) as pending_count"
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_class_member) . " AS l"
                  
                  . " INNER JOIN  "
                  . $this->db->dbprefix($this->tbl_users) . " AS g"
                  . " ON l.user_id = g.user_id  "
                  
                  . " WHERE g.status = 1 and l.class_id = " . $class_id ." and l.is_approved = 0  ; "; 
         $query = $this->db->query($query);
         $class['pending_count'] = $query->result_array()[0]['pending_count'];
         
         return $class;
    }
    
    
    
    
    function getPrivateClassDetail($user_id,$class_id){
//        echo '11111';
        $query = "Select c.id as class_id,c.name as class_name, c.end_date,c.category_id,c.guru_id,n.avatar,n.name,n.guru_average_rating as rating,u.user_id as student_id,u.name as student_name, u.avatar as student_avatar, c.last_joining_date,c.start_date,c.is_approved,c.address"
                . ", (Select cat.name from " . $this->db->dbprefix($this->tbl_category) . " As cat where cat.id = c.category_id limit 1) as category_name" 
                ." FROM "
                .$this->db->dbprefix($this->tbl_private_class). " AS c "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS n"
                . " ON n.user_id = c.guru_id  "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS u"
                . " ON u.user_id = c.user_id  "
                
                . " WHERE c.id = " . $class_id ." ; "; 
         $query = $this->db->query($query);
         $class = $query->result_array()[0];
        
         
        $query = "Select id,class_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,DATE_FORMAT(start_time, '%H:%i') AS start_time,DATE_FORMAT(end_time, '%H:%i') AS end_time "
                  ." FROM "
                  . $this->db->dbprefix($this->tbl_private_class_schedule) . " AS l"
                  . " WHERE l.class_id = " . $class_id ." ; "; 
         $query = $this->db->query($query);
         if ($query->num_rows() > 0) {
            $result = $query->result_array()[0];
            $class['repeat'] = $result;
        }
         
        return $class;
    }
    
    
    
    
    function getMyProfile($user_id){
//        name, avatar, city, country, total_classes, rating, isGuru, on_going_classes:[], past_classes:[]
//        date("Y-m-d")
                $query = "Select u.name,u.avatar,u.user_average_rating as rating, u.is_guru, "
                . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = u.city_id limit 1) as city_name,"
                . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = u.country_id limit 1) as country_name"
                . " FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " WHERE u.user_id = " . $user_id;
                $query = $this->db->query($query);
                $res = $query->result_array()[0];
                $user_profile['name'] = $res['name'];
                $user_profile['avatar'] = $res['avatar'];
                $user_profile['rating'] = $res['rating'];
                $user_profile['is_guru'] = $res['is_guru'];
                $user_profile['city_name'] = $res['city_name'];
                $user_profile['country_name'] = $res['country_name'];
                
                
                
                $query = "Select count(*) as total "
                . " FROM "
                .$this->db->dbprefix($this->tbl_class_member). " AS m "
                . " WHERE m.user_id = " . $user_id. " and m.is_approved = 1 ";
                $query = $this->db->query($query);
                $count1 = $query->result_array()[0]['total'];
                
                $query = "Select count(*) as total "
                . " FROM "
                .$this->db->dbprefix($this->tbl_private_class). " AS m "
                . " WHERE m.user_id = " . $user_id. " and m.is_approved = 1 ";
                $query = $this->db->query($query);
                $count2 = $query->result_array()[0]['total'];
                
                $user_profile['total_classes'] = $count1+$count2;
                
                
                
                
//                 $user_profile = $query->result_array();
               
                
                $date = date("Y-m-d");
//                echo $date;
                
                
                $on_going = array();
                $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name,s.start_time,s.end_time,c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                .
                " FROM "
                . $this->db->dbprefix($this->tbl_class) . " AS c"
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_member) . " AS m"
                . " ON c.id = m.class_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_schedule) . " AS s"
                . " ON c.id = s.class_id  "
                . " WHERE m.user_id = " . $user_id ." and m.is_approved = 1 and c.end_date > '".$date."'";
                
                 $query = $this->db->query($query);
                $result = $query->result_array();
                for($x=0; $x< count($result); $x++){
                    $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                    $query = $this->db->query($query);
                    if(count($query->result_array())>0){
                        $result[$x]['is_liked'] = 1;
                    }
                    else{
                        $result[$x]['is_liked'] = 0;
                    }
                }
                
                $on_going = $result;
                $user_profile['on_going'] = $on_going;
                
                
                $past_classes = array();
                $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, s.start_time,s.end_time,c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                .
                " FROM "
                . $this->db->dbprefix($this->tbl_class) . " AS c"
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_member) . " AS m"
                . " ON c.id = m.class_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_schedule) . " AS s"
                . " ON c.id = s.class_id  "
                . " WHERE m.user_id = " . $user_id ." and m.is_approved = 1 and c.end_date < '".$date."'";
                
               
               
                
                 $query = $this->db->query($query);
                $result = $query->result_array();
                for($x=0; $x< count($result); $x++){
                    $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                    $query = $this->db->query($query);
                    if(count($query->result_array())>0){
                        $result[$x]['is_liked'] = 1;
                    }
                    else{
                        $result[$x]['is_liked'] = 0;
                    }
                }
                
                $past_classes = $result;
                $user_profile['past_classes'] = $past_classes;
                
                $private_classes = array();
                $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, c.end_date,c.address, c.is_approved"
                . " FROM "
                . $this->db->dbprefix($this->tbl_private_class) . " AS c"
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                . " WHERE c.user_id = " . $user_id ;
                
               
               
                
                $query = $this->db->query($query);
                $private_classes = $query->result_array();
                
                $user_profile['private_classes'] = $private_classes;
                
                
                return $user_profile;
        
    }
    
    
    function getPastAsSeekerClasses($user_id){
        $date = date("Y-m-d");
        
        $past_classes = array();
                $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, s.start_time,s.end_time,c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                .
                " FROM "
                . $this->db->dbprefix($this->tbl_class) . " AS c"
                
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_users) . " AS g"
                . " ON g.user_id = c.guru_id  "
        
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_member) . " AS m"
                . " ON c.id = m.class_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_schedule) . " AS s"
                . " ON c.id = s.class_id  "
                . " WHERE g.status = 1 and m.user_id = " . $user_id ." and m.is_approved = 1 and c.end_date < '".$date."'";
                
               $query = $this->db->query($query);
                $result = $query->result_array();
                for($x=0; $x< count($result); $x++){
                    $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                    $query = $this->db->query($query);
                    if(count($query->result_array())>0){
                        $result[$x]['is_liked'] = 1;
                    }
                    else{
                        $result[$x]['is_liked'] = 0;
                    }
                }
                
                return $result;
    }
    
    function getPastAsGuruClasses ($user_id){
        $date = date("Y-m-d");
        $past_classes = array();
                $query = "Select c.id as class_id,c.name as title, n.bg_color as category_color, n.icon as category_icon, n.name as category_name, s.start_time,s.end_time,c.end_date,l.location_id,l.latitude,l.longitude,l.city_id,l.country_id,l.street_address,l.post_code,"
                 . "(Select city.name from " . $this->db->dbprefix($this->tbl_city) . " As city where city.id = l.city_id limit 1) as city_name,"
                 . "(Select country.name from " . $this->db->dbprefix($this->tbl_country) . " As country where country.id = l.country_id limit 1) as country_name"
                .
                " FROM "
                . $this->db->dbprefix($this->tbl_class) . " AS c"
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS n"
                . " ON n.id = c.category_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_locations) . " AS l"
                . " ON l.location_id = c.location_id  "
                ." INNER JOIN "
                . $this->db->dbprefix($this->tbl_class_schedule) . " AS s"
                . " ON c.id = s.class_id  "
                . " WHERE c.guru_id = " . $user_id ."  and c.end_date < '".$date."'";
                
                $query = $this->db->query($query);
                $result = $query->result_array();
                for($x=0; $x< count($result); $x++){
                    $query = "Select *"
                    ." FROM "
                    .$this->db->dbprefix($this->tbl_liked_class). " AS c "
                    . " WHERE c.class_id = " . $result[$x]['class_id'] ." and c.user_id = ".$user_id;
                    $query = $this->db->query($query);
                    if(count($query->result_array())>0){
                        $result[$x]['is_liked'] = 1;
                    }
                    else{
                        $result[$x]['is_liked'] = 0;
                    }
                }
                
                return $result;

    }
    
    function getRatingAsSeeker($user_id,$offset,$limit){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
           
                $query = "Select u.name,u.avatar,c.rating , c.note as review"
                . " FROM "
                .$this->db->dbprefix($this->tbl_users). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_user_rating) . " AS c"
                . " ON u.user_id = c.guru_id  "
                . " WHERE c.user_id = " . $user_id. " LIMIT " . $offset . ", " . $limit . " ; ";
                
                 $query = $this->db->query($query);
                $result = $query->result_array();
                
        return $result;
        
    }
    
   
    
    function isGuruAlreadyLiked($user_id,$guru_id){
         $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_liked_guru) . " AS c
                     WHERE c.user_id = " . $user_id . " and c.guru_id = ".$guru_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
        
    }
    
    function isClassAlreadyLiked($user_id,$class_id){
         $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_liked_class) . " AS c
                     WHERE c.user_id = " . $user_id . " and c.class_id = ".$class_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }
    
    function verifyGuru($guru_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS c
                     WHERE c.user_id = " . $guru_id . " and c.is_guru = 1 ";
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function verifyClass($class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class) . " AS c
                     WHERE c.id = " . $class_id ;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function verifyPrivateClass($class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_private_class) . " AS c
                     WHERE c.id = " . $class_id ;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    
    function verifyClassRequest($user_id, $class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id. " and c.user_id = ".$user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
           $resultObject = $result->result_array()[0];
           return $resultObject['is_approved'];
        } else {
            return -1;
        }
    }
    
    
    
    function isUserAlreadyEnrolledRequested($user_id,$class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                return 1;
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                return 2;
            } 
        } else {
            return -1;
        }
    }
    
    function checkClassLimit($class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.is_approved = 1";
        $result = $this->db->query($query);
        
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class) . " AS c
                     WHERE c.id = " . $class_id;
        $limit = $this->db->query($query)->result_array()[0]['class_limit'];
        
        if(count($result->result_array()) < $limit){
            return 1;
        }
        else{
            return 0;
        }
    }
    
    function guruRatingQuestions($user_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_guru_rating_questions);
        $result = $this->db->query($query)->result_array();
        return $result;
    }
    
    
     function studentRatingQuestions($user_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_user_rating_questions);
        $result = $this->db->query($query)->result_array();
        return $result;
    }
    
    function ifAlreadyRatedGuru($user_id,$guru_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_guru_rating) . " AS c
                     WHERE c.guru_id = " . $guru_id ." and c.user_id = ".$user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return $result->result_array()[0]['rating'];
        } else {
            return -1;
        }
    }
    
    
    function ifAlreadyRatedStudent($guru_id,$student_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_user_rating) . " AS c
                     WHERE c.guru_id = " . $guru_id ." and c.user_id = ".$student_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return $result->result_array()[0]['rating'];
        } else {
            return -1;
        }
    }

    
    function getRatingCountGuru($guru_id){
        $query = " SELECT  count(*) as count_rating 
                     FROM " . $this->db->dbprefix($this->tbl_guru_rating) . " AS c
                     WHERE c.guru_id = " . $guru_id;
        $result = $this->db->query($query);
        return $result->result_array()[0]['count_rating'];
    }
    
    function getRatingCountStudent($student_id){
        $query = " SELECT  count(*) as count_rating 
                     FROM " . $this->db->dbprefix($this->tbl_user_rating) . " AS c
                     WHERE c.user_id = " . $student_id;
        $result = $this->db->query($query);
        return $result->result_array()[0]['count_rating'];
    }


    
    function skillAlreadyAdded($guru_id,$category_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_guru_skill) . " AS c
                     WHERE c.guru_id = " . $guru_id ." and c.category_id = ".$category_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function checkJoiningDate($class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class) . " AS c
                     WHERE c.id = " . $class_id;
        $date = $this->db->query($query)->result_array()[0]['last_joining_date'];
        $today_date = date("Y-m-d");
        
        if($today_date>$date){
            return 0;
        }
        else{
            return 1;
        }
    }
    
    function updateClassRequest($class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class) . " AS c
                     WHERE c.id = " . $class_id;
        $request = $this->db->query($query)->result_array()[0]['class_requests'];
        $request = $request+1;
        $post_data = array();
        $post_data['class_requests'] = $request;
        $this->update($this->tbl_class,$post_data,array('id' => $class_id));
    }
    
    function cancelClassRequest($user_id,$class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                $post_data = array();
                $post_data['class_id'] = $class_id;
                $post_data['user_id'] = $user_id;
                $this->delete($this->tbl_class_member,$post_data);
                return 1;
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                return 2;
            } 
        } else {
            return -1;
        }
    }
    
    
    
    
    function leaveClass($user_id,$class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$user_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                return 2;
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                 $post_data = array();
                $post_data['class_id'] = $class_id;
                $post_data['user_id'] = $user_id;
                $this->delete($this->tbl_class_member,$post_data);
                return 1;
            } 
        } else {
            return -1;
        }
    }

    
    
    function getGuruSkills($guru_id){
          $query = "Select u.id as skill_id,c.name as skill_name,c.id as category_id, c.bg_color as category_color, c.icon as category_icon"
                . " FROM "
                .$this->db->dbprefix($this->tbl_guru_skill). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS c"
                . " ON u.category_id = c.id  "
                ."WHERE u.guru_id = " . $guru_id;
          
            $query = $this->db->query($query);
            $result = $query->result_array();
            
            return $result;
    }
    
    function getSkillDetail($skill_id){
          $query = "Select u.category_id,c.name as category_name,c.super_category_id,u.level,u.qualification,u.description,"
                  . "(Select q.name from " . $this->db->dbprefix($this->tbl_category) . " As q where q.id = c.super_category_id limit 1) as super_category_name"
                . " FROM "
                .$this->db->dbprefix($this->tbl_guru_skill). " AS u "
                . " INNER JOIN  "
                . $this->db->dbprefix($this->tbl_category) . " AS c"
                . " ON u.category_id = c.id  "
                ."WHERE u.id = " . $skill_id;
          
            $query = $this->db->query($query);
            $skill = $query->result_array()[0];
            
            $query = "Select a.id as achievement_id, a.url"
                . " FROM "
                .$this->db->dbprefix($this->tbl_achievement). " AS a "
                ."WHERE a.skill_id = " . $skill_id;
          
            $query = $this->db->query($query);
            $skill['achievements'] = $query->result_array();
            
            return $skill;
    }
    
    

    function verify_guru_class($guru_id,$class_id){
       
        
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class) . " AS c
                     WHERE c.id = " . $class_id." and c.guru_id = ".$guru_id;
        $result = $this->db->query($query);
        
        if($result->num_rows() > 0){
            return 1;
        }
        else{
            return 0;
        }
    }

    
    function acceptClassRequest($student_id,$class_id){
        $query = " SELECT  count(*) as approved_count
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.is_approved = 1 ";
        $result = $this->db->query($query);
        $count = $result->result_array()[0]['approved_count'];
        $class_limit =  getVal('class_limit', 'class', 'id', $class_id);
        
        if ($count >= $class_limit) {
            return 3;
        }
        
        
        
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$student_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                $post_data = array();
                $post_data['is_approved'] = 1;
                $cond = array();
                $cond['user_id'] = $student_id;
                $cond['class_id'] = $class_id;
                $this->update($this->tbl_class_member,$post_data,$cond);
                return 1;
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                return 2;
            } 
        } else {
            return -1;
        }
    }

    
    function removeStudent($student_id,$class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$student_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                return 2;
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                $cond = array();
                $cond['user_id'] = $student_id;
                $cond['class_id'] = $class_id;
                $del = $this->delete($this->tbl_class_member, $cond);
                if($del > 0){
                    return 1;
                }
                else{
                    return 0;
                }
            } 
        } else {
            return 2;
        }
    }
    
    function rejectClassRequest($student_id,$class_id){
        $query = " SELECT  *
                     FROM " . $this->db->dbprefix($this->tbl_class_member) . " AS c
                     WHERE c.class_id = " . $class_id ." and c.user_id = ".$student_id;
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            if($result->result_array()[0]['is_approved'] == 0){
                $cond = array();
                $cond['user_id'] = $student_id;
                $cond['class_id'] = $class_id;
                $del = $this->delete($this->tbl_class_member, $cond);
                if($del > 0){
                    return 1;
                }
                else{
                    return 0;
                }
            }
            else if($result->result_array()[0]['is_approved'] == 1){
                return 2;
            } 
        } else {
            return -1;
        }
    }

    
    
    
    function verifyShouldDecrementBadge($user_id,$thread_id) {
        $result = $this->getMessageIdsToUserIsNotRead($user_id, $thread_id);
        if(count($result) > 0){
            return true;
        }
        return false;
    }
    
    function fetchMessageThreads($user_id,$offset, $limit){
        if ($limit == 0 || $limit == "") {
            $limit = 10;
        }
        if ($offset == 0 || $offset == "") {
            $offset = 0;
        }
        
        
//        SELECT DISTINCT m.thread_id,m.message,m.from_user_id,m.to_user_id FROM thread AS t INNER JOIN ( select DISTINCT thread_id,message_id,message,from_user_id,to_user_id from messages ORDER BY message_id DESC ) as m ON m.thread_id = t.id WHERE t.from_id = 20 or t.to_id = 20 GROUP by m.thread_id LIMIT 0, 10
        
        $query = " SELECT DISTINCT  m.thread_id,m.message,m.from_user_id as lastest_from_id ,m.to_user_id as lastest_to_id,m.is_read,m.created as datetime  ".
                     "FROM " . $this->db->dbprefix($this->tbl_thread) . " AS t "
                ."  INNER JOIN ( select DISTINCT thread_id,message_id,message,from_user_id,to_user_id,is_read,created from messages "
                . " where ((from_user_id =  ".$user_id. " and sender_status= 1 ) or ( to_user_id = "
                    .$user_id. " and receiver_status = 1 )) ".
                
                "  ORDER BY message_id DESC ) "
                     . "   as m"
                     . " ON m.thread_id = t.id  "
                     ." WHERE t.from_id = " . $user_id ." or t.to_id = ".$user_id
                     ." Group by m.thread_id  ORDER BY t.last_update DESC "
                     ." LIMIT " . $offset . ", " . $limit . " "
                ;
        
        $query = $this->db->query($query);
        $result = $query->result_array();
        
        for($x = 0 ; $x < count($result) ; $x++){
            $tmp = $result[$x];
            if($tmp['lastest_from_id'] == $user_id){
                $with_id = getVal('user_id', 'user', 'user_id', $tmp['lastest_to_id']);
                $with_name = getVal('name', 'user', 'user_id', $tmp['lastest_to_id']);
                $with_url = getVal('avatar', 'user', 'user_id', $tmp['lastest_to_id']);
                $result[$x]['with_id'] = $with_id;
                $result[$x]['with_name'] = $with_name;
                $result[$x]['with_url'] = $with_url;
            }
            else if($tmp['lastest_to_id'] == $user_id){
                $with_id = getVal('user_id', 'user', 'user_id', $tmp['lastest_from_id']);
                $with_name = getVal('name', 'user', 'user_id', $tmp['lastest_from_id']);
                $with_url = getVal('avatar', 'user', 'user_id', $tmp['lastest_from_id']);
                $result[$x]['with_id'] = $with_id;
                $result[$x]['with_name'] = $with_name;
                $result[$x]['with_url'] = $with_url;
            }
            
        }
        
        return $result;
        
    }
    
    function shouldIncrementMessageBadge ($reciever, $thread_id, $message_id)
    {
        $query = "Select m.message_id,m.from_user_id,m.message,m.created,m.is_read"
                 ." FROM "
                 .$this->db->dbprefix($this->tbl_messages). " AS m "
                 ."WHERE  m.thread_id = " . $thread_id. " and m.to_user_id = ".$reciever." and m.receiver_status = 1";
        $query = $this->db->query($query);
        $result = $query->result_array();
        if (count($result) == 1){
            return 1;
        }
        else{
            if ($result[count($result)-2]['is_read'] == 1){
                return 1;
            }
        }
        return 0;
    }
    
    function updateMessageBadgeIfRequired($receiver, $ids ){
        $max = 0;
        foreach ($ids as $id) {
            if ((int)$id > $max){
                $max = $id;
            }
        }
        
        if (count($ids) == 0){
            return;
        }
        
        $thread_id = getVal('thread_id', 'messages', 'message_id', $ids[0]);
        
         $query = "Select m.message_id "
                 ." FROM "
                 .$this->db->dbprefix($this->tbl_messages). " AS m "
                 ."WHERE  m.thread_id = " . $thread_id. " and m.to_user_id = ".$receiver." and m.receiver_status = 1 "
                 ." ORDER BY m.message_id DESC LIMIT 1 ";
        $query = $this->db->query($query);
        $result = $query->result_array();
        if (count($result) == 0) {
            return;
        }
        else{
            if ($max == $result[0]) {
                $this->getMessageBadgeDecremented($receiver);
            }
        }
        
    }
    
    function fetchMessages($user_id,$thread_id,$count,$before,$after){
        if ($count == 0 || $count == "") {
            $count = 10;
        }
        
        if(($before == '' || $before == 0) && ($after == '' || $after == 0)){
            $query = "Select m.message_id,m.from_user_id,m.message,m.created,m.is_read"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE ( m.thread_id = " . $thread_id. " )"
                    ." and ((m.from_user_id =  ".$user_id. " and m.sender_status= 1 ) or ( m.to_user_id = "
                    .$user_id. " and m.receiver_status = 1 )) "
                . " ORDER BY m.message_id DESC LIMIT " . $count ." "    
                ;
          
            
            $query = $this->db->query($query);
            $result = $query->result_array();
            $result = array_reverse($result, true);
            
            return $result;
        }
        else if ($after <> ''){
            $query = "Select m.message_id,m.from_user_id,m.message,m.created,m.is_read"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE m.thread_id = " . $thread_id . " and m.message_id > ".$after
                    ." and ((m.from_user_id =  ".$user_id. " and m.sender_status= 1 ) or ( m.to_user_id = "
                    .$user_id. " and m.receiver_status = 1 )) "
                . "  LIMIT " . $count ." "    
                ;
            $query = $this->db->query($query);
            $result = $query->result_array();
            return $result;
        }
        else if($before <> ''){
            $query = "Select m.message_id,m.from_user_id,m.message,m.created,m.is_read"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE m.thread_id = " . $thread_id ." and m.message_id  < ".$before
                ." and ((m.from_user_id =  ".$user_id. " and m.sender_status= 1 ) or ( m.to_user_id = "
                .$user_id. " and m.receiver_status = 1 )) "
                . " ORDER BY m.message_id DESC LIMIT " . $count ." "    
                ;
          
            $query = $this->db->query($query);
            $result = $query->result_array();
            $result = array_reverse($result, true);
            
            return $result;
        }
    }
    
    function getMessageIdsToUser($user_id,$thread_id){
        $query = "Select message_id"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE m.thread_id = ".$thread_id. " and m.to_user_id = ".$user_id
                ;
          
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;
    }
    
    function getMessageIdsToUserIsNotRead($user_id,$thread_id){
        $query = "Select message_id"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE m.thread_id = ".$thread_id. " and m.is_read = 0 and m.receiver_status = 1 and m.to_user_id = ".$user_id
                ;
          
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;
    }
    
    
    function verifyThreadExist($user1,$user2){
        $query = "Select *"
                . " FROM "
                .$this->db->dbprefix($this->tbl_thread). " AS t "
                ."WHERE ( t.from_id = " . $user1 ." and t.to_id  = ".$user2." ) OR "
                . "( t.from_id = " . $user2 ." and t.to_id  = ".$user1." ) "
                ;
          
            $query = $this->db->query($query);
            if ($query->num_rows() > 0) {
                $result = $query->result_array()[0]['id'];
                return $result;
            } else {
                return 0;
            }
    }
    
    function getMessageIds($thread_id){
        $query = "Select message_id"
                . " FROM "
                .$this->db->dbprefix($this->tbl_messages). " AS m "
                ."WHERE m.thread_id = ".$thread_id
                ;
          
        $query = $this->db->query($query);
        $result = $query->result_array();
        return $result;    
    }
    
    
/**
     * Method: get_braintree_data
     * Params: $slug
     * Return: True
     */
    function get_braintree_data() {

        $query = "SELECT  braintree_merchant_id,"
                . "braintree_public_key ,"
                . "braintree_private_key ,"
                . "braintree_environment "
                . " FROM "
                . " payment_integration AS pg "
                . " WHERE  status = 1 "
                . " ORDER BY id DESC limit 1";
        $query = $this->db->query($query);
        return $query->row_array();
    }

    //finger print of searchGurus
     function searchTracks($query_text,$offset,$limit){
         
        if($offset == '' || $offset <= 0){
            $offset = 0;
        }
        if($limit == '' || $limit <= 0){
            $limit = 10;
        }
        
        $query = "Select *"
                . " FROM "
                .$this->db->dbprefix($this->tbl_tracks) . " AS track "
                . " where track.is_active = 1";
        if($query_text != ""){
            $query = $query. " and ( track.track_name LIKE '%" . $query_text. "%' "." or track.description LIKE '%" . $query_text. "%') ";
            }
         $query = $query . " LIMIT " . $offset . ", " . $limit . " ; ";
        
        $query = $this->db->query($query);
        
        $result = $query->result_array();
        return $result;
       
    }
    
}

//End Class