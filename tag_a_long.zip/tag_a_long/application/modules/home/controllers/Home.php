<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('home_model');
        $this->load->library('emailutility');
    }

    public function index() {

        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }
        $data['row'] = $row;

        $result1 = $this->home_model->getHomePageSettings();
        $page = array();
        foreach ($result1 as $row2) {
            $page[$row2['field_name']] = $row2['field_value'];
        }

        
        $data['page'] = $page;

        $data['testimonial'] = $this->home_model->getTestimonial();
      
        $data['navBar'] = $this->home_model->getNavbar();
        $data['content'] = $this->load->view('home', $data, true);
        $this->load->view('frontEnd_view', $data);
    }

    // Function Send Email Start from here
    function send_email() {
        $data = array();
        $name = $this->input->post('name');
        $user_email = $this->input->post('user_email');
        $subject = $this->input->post('subject');
        $message = $this->input->post('message');
        $data['receiver_name'] = 'Admin';
        $data['email_content'] = "You have received new contact inquiry from <strong>" . SITE_NAME . "</strong>.<br /><br />Please see the details below.<br /><br />
        <strong>Name:</strong>&nbsp; " . ucwords($name) . " <br />
        <strong>Email:</strong>&nbsp; " . $user_email . " <br />
        <strong>Message:</strong><br />" . $message . " <br /> <br />";

        $email_tempData = getEmailTemplate(3);
        if (!empty($email_tempData)) {
            $data['title'] = $subject;
            $data['content'] = $email_tempData['content'];
            $data['welcome_content'] = $email_tempData['welcome_content'];
            $data['footer'] = $email_tempData['footer'];
            $subject = $data['title'];
            $email_content = $this->load->view('includes/email_templates/email_template', $data, true);
            $this->emailutility->send_contact_inquiry($email_content, $subject);

            $this->session->set_flashdata('success', 'Contact inquiry sent successfully.');
            redirect('home#message_div');
        } else {
            $this->session->set_flashdata('error', 'Contact inquiry can not sent successfully.');
            redirect('home#message_div'); // due to flash data.
            //    $this->load->view('includes/email_templates/email_template', $data);
        }
    }

    // Subcribe Email Function

    function subcribe() {
        $subcribe_email = $this->input->post('subcribe_email');
        $check = $this->home_model->checkEmail($subcribe_email);
        if ($check == 1) {
            $this->session->set_flashdata('errorr', 'This email already subcribed');
            redirect('home#message_div');
        } else {
            $data = array();
            $data['receiver_name'] = 'User';
            $data['email_content'] = "You have received email from <strong>" . SITE_NAME . "</strong><br />
        We are wellcomed you. Now you are our member for getting new updates our website.
        <br />";
            $email_tempData = getEmailTemplate(3);

            if (!empty($email_tempData)) {
                $data['title'] = 'Subscription';
                $data['footer'] = $email_tempData['footer'];
                $subject = $data['title'];
                $email_content = $this->load->view('includes/email_templates/email_template', $data, true);
                // echo $email_content;
                // die;
                $data['to_email'] = $subcribe_email;
                $db['email'] = $subcribe_email;
                $this->emailutility->leave_feedback_message($data, $email_content, $subject);
                $this->db->insert('subcribe_email', $db);
                $this->session->set_flashdata('successs', 'Wellcome! You are subcribed to our website.');
                redirect('home#message_div');
            } else {
                $this->session->set_flashdata('errorr', 'Try again! Check you email');
                redirect('home#message_div'); // due to flash data.
            }
        }
    }

    // Subcribe Email From Cms Function
    function subcribeFromCms() {
        $subcribe_email = $this->input->post('subcribe_email');
        $check = $this->home_model->checkEmail($subcribe_email);
        if ($check == 1) {
            $this->session->set_flashdata('errorr', 'This email already subcribed');
            $url = $_SERVER['HTTP_REFERER'];
            redirect($url);
        } else {
            $data = array();
            $data['receiver_name'] = 'User';
            $data['email_content'] = "You have received email from <strong>" . SITE_NAME . "</strong><br />
         We are wellcomed you. Now you are our member for getting new updates our website.
         <br />";

            $email_tempData = getEmailTemplate(3);
            if (!empty($email_tempData)) {
                $data['title'] = 'Subscription';
                $data['footer'] = $email_tempData['footer'];
                $subject = $data['title'];
                // echo $email_content;
                // die;
                $email_content = $this->load->view('includes/email_templates/email_template', $data, true);
                $data['to_email'] = $subcribe_email;
                $db['email'] = $subcribe_email;
                $this->emailutility->leave_feedback_message($data, $email_content, $subject);
                $this->db->insert('subcribe_email', $db);
                $this->session->set_flashdata('successs', 'Wellcome! You are subcribed to our website.');
                $url = $_SERVER['HTTP_REFERER'];
                redirect($url);
            } else {
                $this->session->set_flashdata('errorr', 'Try again! Check you email');
                $url = $_SERVER['HTTP_REFERER'];
                redirect($url);
            }
        }
    }

    // Check Cms Pages 

    public function check_cms_pages() {
        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }

        $data['row'] = $row;

        $result1 = $this->home_model->getHomePageSettings();
        $page = array();
        foreach ($result1 as $row2) {
            $page[$row2['field_name']] = $row2['field_value'];
        }


        $data['page'] = $page;

        $slug = $this->uri->segment(2);
        $table = 'content_management';
        $where = array('slug' => $slug);
        $data['c_m_s'] = $this->home_model->getCms($table, $where);
        $data['navBar'] = $this->home_model->getNavbar();
        $data ['content'] = $this->load->view('cms_view/cmsPage', $data, true);
        $this->load->view('cms_view', $data);
    }

    function email_verification($user) {
        $user_id = decode($user);

        $check = $this->home_model->isUserInactive($user_id);

        if ($check == 0) {
            $post_data = array();
            $post_data['is_verified'] = '1';
            $up = $this->home_model->update('users', $post_data, array('user_id' => $user_id));
            if ($up > 0) {
                redirect(base_url('thank-you'));
                /* $data = array();
                  $data = $this->home_model->get_user_data($user_id);

                  $data['user_id']        = $data['user_id'];
                  $data['name']           = $data['name'];
                  $data['email']          = $data['email'];
                  $data['phone_no']       = $data['phone_no'];
                  $data['avatar']         = $data['avatar'];
                  $data['fb_url']         = $data['fb_url'];
                  $data['tw_url']         = $data['tw_url'];
                  $data['soundcloud_url'] = $data['soundcloud_url'];
                  $data['web_url']        = $data['web_url'];
                  $data['cover_photo']    = $data['cover_photo'];
                  $data['is_verified']    = $data['is_verified'];
                  $data['status'] = 1;
                  $data['message'] = 'Congratulation! Your account has been verified successfully.';
                  $this->makeLog($user_id, "Verify email address", NULL, NULL, "User successfully verifed email address");
                 */
            }
        } else if ($check == 1) {
            $data['status'] = 0;
            $data['error'] = 204;
            $data['message'] = 'The user you are trying to access is inactive.';
        } else {

            $data['status'] = 0;
            $data['error'] = 202;
            $data['message'] = 'User "' . $email . '" not exists. Please try another email.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    public function thank_you() {
        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }

        $data['row'] = $row;
        $data['title'] = "Thank You";
        $data['description'] = "Congratulation! Your account has been verifed successfully. ";
        $data['navBar'] = $this->home_model->getNavbar();
        $data ['content'] = $this->load->view('cms_view/thankyou', $data, true);
        $this->load->view('cms_view', $data);
    }

    public function payment_done() {
        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }

        $data['row'] = $row;
        $data['title'] = "Payment";
        $data['description'] = "Congratulation! Payment Done Successfully";
        $data['navBar'] = $this->home_model->getNavbar();
        $data ['content'] = $this->load->view('cms_view/thankyou', $data, true);
        $this->load->view('cms_view', $data);
    }

    function forgotPassword($user_id) {

        $user_id = decode($user_id);

        $check = $this->home_model->isUserInactive($user_id);

        if ($check == 0) {
            $post_data = array();
            $data['status'] = 1;
            $data['user_id'] = $user_id;
            $data['message'] = 'Password change request';
            $this->makeLog($user_id, "Verify email address", NULL, NULL, "User successfully verifed email address");
        } else if ($check == 1) {
            $data['status'] = 0;
            $data['error'] = 204;
            $data['message'] = 'The user you are trying to access is inactive.';
        } else {

            $data['status'] = 0;
            $data['error'] = 404;
            $data['message'] = 'Invalid data provided.';
        }
        header('Content-Type: application/json');
        echo str_replace("||", "", json_encode($data, JSON_NUMERIC_CHECK));
        exit;
    }

    function makeLog($user_id, $action, $class_id, $target_user_id, $description) {
        $post_data = array();
        if ($user_id) {
            $post_data['user_id'] = $user_id;
        }
        if ($action) {
            $post_data['action'] = $action;
        }
        if ($class_id) {
            $post_data['class_id'] = $class_id;
        }
        if ($target_user_id) {
            $post_data['target_user_id'] = $target_user_id;
        }
        if ($description) {
            $post_data['description'] = $description;
        }
        $this->home_model->create("activity_logs", $post_data);
    }

    function payment() {

        
        $data = array();
        if ($_REQUEST['user_id'] <> '' && $_REQUEST['purchase_type'] <> '' && $_REQUEST['plan_id'] <> '' && $_REQUEST['amount'] <> '') {
            $data['title'] = "Payment";
            $data['description'] = "Description";
            $data['user_id'] = $_REQUEST['user_id'];
            $data['purchase_type'] = $_REQUEST['purchase_type'];
            $data['plan_id'] = $_REQUEST['plan_id'];
            $data['amount'] = $_REQUEST['amount'];
        }
        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }

        $data['row'] = $row;
        $data['navBar'] = $this->home_model->getNavbar();
        $data ['content'] = $this->load->view('cms_view/payment', $data, true);
        $this->load->view('cms_view', $data);
    }

    function updateNonce() {
        $this->load->library('stripe');
		$url = $_SERVER['HTTP_REFERER'];
        $data = array();
        $update_data = array();
        if ($_POST['user_id'] <> '' && $_POST['purchase_type'] <> '' && $_POST['plan_id'] <> '' && $_POST['token']) {
            $description = "";
            $post_data = array();
            $_POST['user_id'] = decode($_POST['user_id']);
            $post_data['user_id'] = $_POST['user_id'];
            $post_data['plan_id'] = $_POST['plan_id'];
            $post_data['price'] = $_POST['amount'];
            $post_data['purchase_type'] = $_POST['purchase_type'];
            $token = $_POST['token'];
            $result = $this->stripe->charge_card($_POST['amount'] * 100, $token, $description);
            $json = json_decode($result);

            if ($json->paid == 1) {

                if ($post_data['purchase_type'] == 1) {

                    $post_data['token'] = getVal('tokens', 'tokenplans', 'plan_id', $post_data['plan_id']);
                    $prev_token = getVal('token', 'users', 'user_id', $post_data['user_id']);
                    $update_data['token'] = $prev_token + $post_data['token'];
                    $data['tag_tokens'] = $update_data['token'];
                } else if ($post_data['purchase_type'] == 2) {

                    $post_data['months'] = getVal('months', 'premium_plans', 'plan_id', $post_data['plan_id']);
                    $update_data['premium_expiry'] = date("y-m-d", strtotime("+" . $post_data['months'] . " months", strtotime(date("y-m-d"))));
                    $data['premium_expiry'] = $update_data['premium_expiry'];
                    $data['is_premium'] = 1;
                } else {
                    $user_data = getValArray('space,space_type', 'additional_space', 'plan_id', $post_data['plan_id']);
                    $post_data['space'] = $user_data['space'];
                    $post_data['space_type'] = $user_data['space_type'];
                    $prev_space = getVal('additional_space', 'users', 'user_id', $post_data['user_id']);
                    $converted_value = convertToMBs($user_data['space'], $user_data['space_type']);
                    $update_data['additional_space'] = $prev_space + $converted_value;
                    $data['remaining_space'] = $update_data['additional_space'];
                }

                $insert_id = $this->home_model->create("payment_history", $post_data);

                $result = $this->home_model->update('users', $update_data, array('user_id' => $_POST['user_id']));
                $this->makeLog($_POST['user_id'], "token Nonce", NULL, NULL, "Token Nonce updated successfully");
                redirect(base_url('payment-successful'));
                exit;
            } else {
                $this->session->set_flashdata('error', 'Payment Failed please try again');
                redirect($url);
            }
        } else {
            $this->session->set_flashdata('error', 'Sorry Invalid Date Provided');
            redirect($url);
        }
    }

    function user_register() {
        $url = $_SERVER['HTTP_REFERER'];
        $data = array();
        if ($this->input->post()) {
            $verify = $this->home_model->verify_email($_POST['email']);
            if ($verify == 1) {

                $post_data['email'] = $_POST['email'];
                $post_data['username'] = $_POST['username'];
                $post_data['name'] = $_POST['first_name'] . '  ' . $_POST['last_name'];
                $post_data['password'] = md5($_POST['password']);
                $post_data['secret_key'] = $this->common->uniqueKey(40, 8);
                $post_data['is_active'] = 1;

                $post_data['created'] = date('Y-m-d H:i:s');
                $post_data['premium_expiry'] = date("y-m-d", strtotime("+1 months", strtotime(date("y-m-d"))));
                $results = $this->home_model->create('users', $post_data);
                $insert_id = $this->db->insert_id();

                if ($results) {



                    $email = $_POST['email'];
                    $e_data['receiver_name'] = $post_data['name'];
                    $e_data['email_content'] = "To verify your email address " . $email . " Please Click on the below link. 
                                <br /><br />
                                Email verification Link: <a href=" . base_url() . "home/email_verification/" . encode($insert_id) . "><b>Click Here</b></a>
                                <br /><br />
                                if you did not request this verification, please ignore this email. If you feel something is wrong, please contact our support team: info@tagalongmusic.com.
                                ";


                    $e_data['title'] = 'Verify Email Address';
                    $e_data['content'] = $data['email_content'];
                    $e_data['welcome_content'] = "Greetings " . $e_data['receiver_name'];
                    $e_data['footer'] = "Regards";
                    $subject = $e_data['title'];
                    $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
                    $this->emailutility->send_email_user($email_content, $email, $subject);
                    $this->makeLog($insert_id, "User Email Signup", NULL, NULL, "User signup using email");

                    $this->session->set_flashdata('success', 'Congratulation! Your account has been created successfully. Now please verify your email address by click the link sent to your email address.d');
                } else {


                    $this->session->set_flashdata('error', 'Not able to register. Try again later.');
                }
            } else {
                $this->session->set_flashdata('error', 'Email already exists. Please try another one.');
            }
            redirect($url);
        }
        $result = $this->home_model->getSettings();
        $row = array();
        foreach ($result as $row1) {
            $row[$row1['option_name']] = $row1['option_value'];
        }

        $data['row'] = $row;
        $data['navBar'] = $this->home_model->getNavbar();
        $data['genres'] = $this->home_model->getGenres();
        $data ['content'] = $this->load->view('cms_view/trackUpload', $data, true);
        $this->load->view('cms_view', $data);
    }

    public function add_track() {
        
        ini_set('post_max_size', '500M');
        ini_set('upload_max_filesize', '500M');
        $data = array();
        // Check rights

        if ($this->input->post()) {
            $url = $_SERVER['HTTP_REFERER'];
            $oldmask = umask(0);
            $email = $_POST['email'];
            $password = $_POST['password'];

            $response = $this->home_model->ajaxLogin($email, $password);

            if ($response <> 0 && $response <> -1) {
                $data = $this->home_model->get_user_data($response);
                if ($data['is_verified'] > 0) {
                    $extension = $this->common->getExtension($_FILES ['audio_url'] ['name']);
                    $extension = strtolower($extension);
                    if ($_FILES['audio_url']['name'] != '' && ($extension == "mp3" || $extension == "m4a" || $extension == "amr")) {
                        $path = 'uploads/tracks/';
                        $tag_name = $_FILES ['audio_url']['tmp_name'];
                        $file_name = $_FILES ['audio_url']['name'];
                        $name = explode(".", $file_name);
                        $up_ext = strtolower($name [(count($name) - 1)]);
                        $rand = rand(1, 99999999999);
                        $string = str_replace(' ', '-', $name[0]); // Replaces all spaces with hyphens.
                        $names = preg_replace('/[^A-Za-z0-9\-]/', '', $string);
                        $file_name = $names . '_' . $rand . '.' . $up_ext;
                        $target_path = $path . $file_name;
                        chmod($_SERVER['DOCUMENT_ROOT'] . '/' . $target_path, 0777);
                        if (move_uploaded_file($tag_name, $target_path)) {
                            $source = $target_path;
                            if ($extension == 'mp3') {

                                $new_name = $names . '_' . time() . '.' . "m4a";
                                $newfileName = $path . '/' . $new_name;

                                $cmd = FFMPEG . " -i " . $source . " -ar 22050 " . $newfileName;

                                if (!shell_exec($cmd)) {
                                    $file=$newfileName;
                                    unlink($source);
                                } 
                            }
                            else{
                                $file= $source;
                            }
                            
                        }
                        
                        umask($oldmask);
                        $post_data['audio_url'] = BURL . $file;



                        $dur = shell_exec(FFMPEG . " -i " . $post_data['audio_url'] . " 2>&1");
                        preg_match("/Duration: (.{2}):(.{2}):(.{2})/", $dur, $duration);
                        $post_data['duration'] = $duration[1] . ":" . $duration[2] . ":" . $duration[3];
                        $post_data['genre'] = $_POST['genre'];
                        $post_data['title'] = $_POST['title'];
                        $post_data['created'] = strtotime(date('Y-m-d H:i:s'));
                        $post_data['user_id'] = $data['user_id'];
                        $post_data['approve'] = 0;
                        // $this->db->save_queries = true;
                        $results = $this->home_model->create('tracks', $post_data);
//                    echo $this->db->last_query();
//                    exit;
                        if ($results) {

                            $e_data['receiver_name'] = $data['name'];

                            $e_data['email_content'] = "Congratulations!
                                <br /><br />
                                Your track has been uploaded. You will be notified when admin will approve the track and you can use this track free using this email from the app.
                                <br /><br />
                                Thankyou
                                ";


                            $e_data['title'] = 'Your track has been uploaded please check your email';
                            $e_data['footer'] = "Copyright &copy; " . date("Y") . " Tag-a-Long. All Rights Reserved.";
                            $subject = $e_data['title'];
                            $email_content = $this->load->view('includes/email_templates/email_template', $e_data, true);
                            $this->emailutility->send_email_user($email_content, $email, $subject);
                            $this->makeLog($insert_id, "User Email for track upload", NULL, NULL, "track uploaded");
                           
                            $msg="Track uploaded successfully. please check your email";
                            $type="alert-success";
                        } else {
                             $msg="Opps! Error saving informtion. Please try again.";
                             $type="alert-danger";
                                                     
                        }
                    }
                    else{
                         $msg="Sorry invalid File type.please upload audio file"; 
                         $type="alert-danger";
                         
                    }
                } else {
                    $msg="Your email address is not verified. Kindly verify your email.";
                    $type="alert-danger";
                    
                }
            } else if ($response == -1) {
                $msg="The user you are trying to access is inactive.";
                $type="alert-danger";
                
            } else {
                $msg="The email or password you entered is incorrect. Please try again.";
                $type="alert-danger";
                
            }
            $data['msg'] =$msg;
            $data['type'] =$type;
            echo json_encode($data, JSON_NUMERIC_CHECK);
            exit;
            //redirect($url);
        }
    }

}


