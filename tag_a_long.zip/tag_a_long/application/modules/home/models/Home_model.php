<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home_model extends CI_Model {

    var $tbl_users = 'users';
    var $tbl = 'site_settings';
    var $tbl_cms = 'content_management';
    var $tbl1 = 'home_setting';
    var $tbl_genres = 'genre';

    public function __construct() {
        parent::__construct();
    }

    // Get Seting Function
    function getSettings() {
        $this->db->select('*');
        $this->db->from($this->tbl);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getTestimonial() {
        $this->db->select('*');
        $this->db->from('testimonial');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getHomePageSettings() {
        $this->db->select('*');
        $this->db->from($this->tbl1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

//End __construct

    /**
     * Method: insert
     * Return: id
     */
    function create($table, $data) {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    /**
     * Method: update
     * Return:
     */
    function update($table, $data, $where) {
        $this->db->where($where);
        return $this->db->update($table, $data);
    }

    // Get Navbar Function
    function getNavbar() {
        $this->db->select('*');
        $this->db->from($this->tbl_cms);
        $this->db->where('show_header', '1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    /**
     * Method: delete
     * Return:
     */
    function delete($table, $where) {
        $this->db->where($where);
        return $this->db->delete($table);
    }

	 /**
     * Method: isUserInactive
     * Return: 1 or 0
     */
	 
    function isUserInactive($user_id) {
        $query = " SELECT  *
                     FROM users  AS u
                     WHERE u.user_id  = " . $user_id . " ";
        $result = $this->db->query($query);
        $resultArray = $result->row_array();
        if ($resultArray['is_active'] == 0) {
            return 1;
        } else if ($resultArray['is_active'] == 1) {
            return 0;
        }
    }

    /**
     * Method: ajaxLogin
     * Params: $user_id
     * Return: array
     */
    public function ajaxLogin($email, $passwrd) {
        
        $password = md5($passwrd);
        $this->db->select('*');
//        $this->db->where('status', 1);
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->limit(1);
        $qry = $this->db->get($this->db->dbprefix($this->tbl_users));
        
   
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $result) {
                if ($result->is_active == 0) {
                    return -1;
                }
                $user_session['user_id'] = $result->user_id;
            }


            $data = array(
                'last_activity_time' => time());
            $this->db->where('user_id', $user_session['user_id']);
            $this->db->update($this->db->dbprefix($this->tbl_users), $data);
            return $user_session['user_id'];
        } else {
            return 0;
        }
    }

	 /**
     * Method: get_user_data
     * Params: $user_id
     * Return: array
     */
	
    function get_user_data($user_id) {
        $query = " SELECT
                u.user_id,
                u.name,
                u.email,
                u.phone_no,
                u.avatar,
                u.fb_url,
                u.tw_url,
                u.soundcloud_url,
                u.web_url,
                u.cover_photo,
                u.is_verified

            FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
            WHERE u.is_active = 1 AND  u.user_id = " . $user_id . " limit 1 ";

        $result = $this->db->query($query);

//        if ($result->num_rows() > 0) {
        $results = $result->row_array();
        if ($results['avatar'] <> '') {
            $results['avatar'] = $results['avatar'];
        }
        return $results;
//        }
    }

    /**
     * Method: checkEmail
     * Return: 0/1
     */
    function checkEmail($subcribe_email) {

        $sql_ = "SELECT email FROM subcribe_email WHERE email = '" . $subcribe_email . "'";
        $query = $this->db->query($sql_);
        if ($query->num_rows() >= 1) {
            return 1;
        } else {
            return 0;
        }
    }

	/**
     * Method: checkEmail
     * Return: result array
     */
    public function getCms($table, $where) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get()->result();
        return $query;
    }

	/**
     * Method: checkEmail
     * Return: 1 or 0
     */
	 
    function verify_email($email) {

        $query = " SELECT  u.user_id
                     FROM " . $this->db->dbprefix($this->tbl_users) . " AS u
                     WHERE u.email = '" . $email . "' ";

        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            $resultArray = $result->row_array();
            if ($this->isUserInactive($resultArray['user_id']) == 1) {
                return -1;
            }
            return 0;
        } else {
            return 1;
        }
    }

	/**
     * Method: getGenres
     * Return: result array
     */
	 
    public function getGenres() {
        $this->db->select('*');
        $this->db->from($this->db->dbprefix($this->tbl_genres));
        $this->db->where("is_active", 1);
        $query = $this->db->get()->result_array();
        return $query;
    }

}

//End Class