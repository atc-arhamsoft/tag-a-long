<?php $this->load->view('includes/cms_header.php'); ?>

<!-- top-header -->
<?php echo htmlspecialchars_decode($content); ?>


<?php $this->load->view('includes/cms_footer.php'); ?>
