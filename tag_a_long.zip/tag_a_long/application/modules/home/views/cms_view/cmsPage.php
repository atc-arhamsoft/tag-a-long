           
<!-- Inner Page Content Start -->
<div class="inner-content">
<!-- About Page content Start -->
            <section class="about-page-wrap">
                <div class="container">
                    <div class="row">
<!-- About page heading Start -->
                        <div class="col-12">
                        <h1></h1>
                            <div class="feature-heading text-center animatable wow fadeInDown">
                                <h2 class="section-heading"><b class="text-blue fw700"> <?php echo $c_m_s[0]->title;?></b></h2>
                            </div>
                        </div>
<!-- About page heading End -->
                        <div class="about-sec row">
<!-- About page Image Start -->
                          <?php if($c_m_s[0]->id==20){?>
                           <div class="col-md-12 col-12 animatable wow bounceInLeft">
                                <div class="best-app best-app-text">
                                    <p><?php echo $c_m_s[0]->description;?></p>
                                    <p></p>
                                </div>
                            </div>
                          <?php }else {?>
                            <div class="col-md-5 col-12 animatable wow bounceInRight">
                                <div class="about-text-device mt-30"><img src="<?php echo base_url('uploads/cms/pic/'.$c_m_s[0]->display_image)?>" class="img-fluid" alt="about-mbl"/></div>
                            </div>
<!-- About page Image End -->
<!-- About page text Start -->
                            <div class="col-md-7 col-12 animatable wow bounceInLeft">
                                <div class="best-app best-app-text">
                                    <p><?php echo $c_m_s[0]->description;?></p>
                                    <p></p>
                                </div>
                            </div>
                          <?php }?>
<!-- About page text End -->

                        </div>
                        <!-- <div class="about-sec"> -->
<!-- About page text Start -->
                            <!-- <div class="col-md-7 col-12 animatable wow bounceInLeft">
                                <div class="best-app best-app-text">
                                    <h4>BEST <span class="yellow">MOBILE APP</span></h4>
                                    <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes,</p>
                                    <p>mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes,</p>
                                </div>
                            </div> -->
<!-- About page text End -->
<!-- About page Image Start -->
                            <!-- <div class="col-md-5 col-12 animatable wow bounceInRight">
                                <div class="about-text-device mt-30"><img src="image/about-mbl-2.png" class="img-fluid" alt="about-mbl"/></div>
                            </div> -->
<!-- About page Image End -->
                        <!-- </div> -->
                    </div>
                </div>
            </section>
<!-- About Page content End -->
        </div>
<!-- Inner Page Content End -->