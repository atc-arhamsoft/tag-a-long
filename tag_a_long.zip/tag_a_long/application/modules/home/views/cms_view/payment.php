   
<!-- Inner Page Content Start -->
<div class="inner-content">
    <!-- About Page content Start -->
    <section class="about-page-wrap">
        <div class="container">
            <div class="row">
                <!-- About page heading Start -->
                <div class="col-12">
                    <h1></h1>
                    <div class="feature-heading text-center animatable wow fadeInDown">
                        <h2 class="section-heading"><b class="text-blue fw700"> <?php echo $title; ?></b></h2>
                    </div>
                </div>
                <!-- About page heading End -->
                <div class="about-sec row">
                    <!-- About page Image Start -->
                         
                    <div class="col-md-6 col-12 animatable wow bounceInLeft mb-30">
                        <div class="notification-msg">
                            <div id="stripformerrorcontainer" style="display: none" class="text-danger alert alert-danger alert-form alert-box">
                                <p id="stripformerrors"></p>
                            </div>
                            <?php if ($this->session->flashdata('error')) { ?>
                                <div class="alert alert-danger col-sm-12">
                                    <?php echo $this->session->flashdata('error'); ?>
                                </div>
                            <?php } ?>
                            <?php if ($this->session->flashdata('success')) { ?>
                                <div class="alert alert-success text-success col-sm-12">
                                    <p><?php echo $this->session->flashdata('success'); ?></p>
                                </div>
                            <?php } ?>  
                        </div>
                        <form action="<?php echo base_url('home/updateNonce') ?>" method="post" id="payment-form" name="payment-form">
                            <input type="hidden" name="purchase_type" value="<?php echo $purchase_type; ?>">
                            <input type="hidden" name="plan_id"  value="<?php echo $plan_id; ?>">
                            <input type="hidden" name="user_id"  value="<?php echo encode($user_id); ?>">
                            <input type="hidden" name="amount"  value="<?php echo $amount; ?>">

                            <div class="row">
                            <div class=" col-12">
                                <div class="form-group tag-fields">
                                    <input type="text" class="form-control" value="" id="ccard_number" data-stripe="number"  name="ccard_number" placeholder="Card Number" required>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group tag-fields">
                                    <input type="text" class="form-control" value="" id="stripe_expire_month" data-stripe="exp_month" name="expire_month"  placeholder="MM" required>
                                </div>
                            </div>
                                    
                            <div class="col-12">
                                <div class="form-group tag-fields">
                                    <input type="text" class="form-control" value="" id="stripe_expire_year" data-stripe="exp_year" name="expire_year"  placeholder="YYYY" required>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group tag-fields">
                                    <input type="text" class="form-control" value="" id="stripe_cvv" data-stripe="cvc" name="cvv"  required placeholder="cvc">
                                </div>
                            </div>
                                    
                            <div class="col-12">
                            <div class="tag-fields">
                                <button type="button" onclick="payByCredit()" class="btn btn-submit p-style text-blue fw600">Submit</button>
                                </div>
                            </div>


                            </div>
                        </form>
                    </div>
                        
<!-- Payment type image -->
                    <div class="col-md-6 col-12 animatable wow bounceInRight">
                        <div class="payment-img-card">
                            <img src="<?php echo IMG;?>payment-card.jpg" class="img-fluid" alt="">
                        </div>
                    </div>

                    <!-- About page text End -->

                </div>

            </div>
        </div>
    </section>
    <!-- About Page content End -->
</div>
<!-- Inner Page Content End -->
