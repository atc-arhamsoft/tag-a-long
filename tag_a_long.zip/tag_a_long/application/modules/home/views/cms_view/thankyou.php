<div class="inner-content">

    <section class="about-page-wrap">
        <div class="container">
            <div class="row">

                <div class="col-12">
                    <h1></h1>
                    <div class="feature-heading text-center animatable wow fadeInDown">
                        <h2 class="section-heading"><b class="text-blue fw700"> <?php echo $title; ?></b></h2>
                    </div>
                </div>

                <div class="about-sec row">


                    <div class="col-md-12 col-12 animatable wow bounceInLeft">
                        <div class="text-center">
                            <p><?php echo $description; ?></p>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </section>

</div>
