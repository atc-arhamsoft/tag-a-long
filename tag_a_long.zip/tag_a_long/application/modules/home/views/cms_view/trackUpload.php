
<!-- Inner Page Content Start -->
<div class="inner-content">
    <!-- About Page content Start -->
    <section class="about-page-wrap">
        <div class="container">
            <div class="row">
                <!-- About page heading Start -->
                <div class="col-12">
                    <h1></h1>
                    <div class="feature-heading text-center animatable wow fadeInDown">
                        <h2 class="section-heading"><b class="text-blue fw700"> Upload Track</b></h2>
                    </div>
                </div>
                <!-- About page heading End -->
                <div class="about-sec row">
                    <!-- About page Image Start -->
                    <div class="notification-msg">
                        <div id="stripformerrorcontainer" style="display: none" class="text-danger alert alert-danger alert-form alert-box">
                            <p id="stripformerrors"></p>
                        </div>
                        <?php if ($this->session->flashdata('error')) { ?>
                            <div class="alert alert-danger col-sm-12">
                                <?php echo $this->session->flashdata('error'); ?>
                            </div>
                        <?php } ?>
                        <?php if ($this->session->flashdata('success')) { ?>
                            <div class="alert alert-success text-success col-sm-12">
                                <p><?php echo $this->session->flashdata('success'); ?></p>
                            </div>
                        <?php } ?>  
                    </div>
                     <div class="alert" id="formErrorMsg" style="display: none;">
                     </div>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tempus, ante quis placerat pulvinar, dolor ante dictum diam, sed pharetra tellus sapien convallis nunc. Quisque convallis suscipit sagittis. Nunc arcu nunc, ullamcorper nec facilisis non, rutrum eget nibh.</p>
                    </div>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item ">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home-content" role="tab" aria-controls="home" aria-selected="true">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Track</a>
                        </li>
                    </ul>


                    <div class="tab-content">
                        <div class="tab-pane active " id="home-content" role="tabpanel" aria-labelledby="home-tab">
                            <div class="col-md-8 col-12  mb-30">

                                <form action="<?php echo base_url('home/user_register') ?>" method="post" id="register_form">

                                    <div class="row">
                                        <div class=" col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="text" class="form-control" value="" id="first_name"  name="first_name" placeholder="First Name*" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="text" class="form-control" value="" id="last_name"  name="last_name"  placeholder="Last Name*" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="text" class="form-control" value="" id="username"  name="username"  placeholder="Username*" required>
                                            </div>
                                        </div>        
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="email" class="form-control" value="" id="email"  name="email"  placeholder="Email*" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="password" class="form-control" value="" id="password"  name="password"   placeholder="Password*" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="password" class="form-control" value="" id="confirm_password"  name="confirm_password"   placeholder="Confirm Password*" required>
                                            </div>
                                        </div>       
                                        <div class="submit-button">
                                            <div class="tag-fields">
                                                <button type="submit"  class="btn btn-submit p-style text-blue fw600">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Payment type image -->

                        <div class="tab-pane" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="col-md-8 col-12 ">
                                <form  method="post" accept-charset="utf-8" enctype="multipart/form-data" id="trackupload">

                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="email" class="form-control" value="" id="email"  name="email"  placeholder="Email" required autocomplete="off">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="password" class="form-control" value="" id="password"  name="password"   placeholder="Password" required autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <select class="form-control" value="" id="genre"  name="genre" required>
                                                    <option value="">Select</option>
                                                    <?php foreach ($genres as $genre) { ?>
                                                        <option value="<?php echo $genre['id'] ?>"><?php echo $genre['name'] ?></option>
                                                    <?php } ?>
                                                </select>

                                            </div>
                                        </div> 
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input type="text" class="form-control" value="" id="title"  name="title"   placeholder="Title" required autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group tag-fields">
                                                <input class="custom-file-input" type="file" id="audio_url" name="audio_url" required>
                                                <label class="custom-file-label" for="customFile">Choose file</label>
                                                <audio id="audio"></audio>
                                            </div>

                                        </div>       
                                        <div class="submit-button">
                                            <div class="tag-fields">

                                                <button type="submit"  class="btn btn-submit p-style text-blue fw600">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- About page text End -->

                </div>

            </div>
        </div>
    </section>
    <!-- About Page content End -->
</div>
<div class="loading-overlay">
    <h1 class="text-center">Please wait you file is uploading...</h1>
    <div class="lds-css ng-scope">
        <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    </div>

</div>
<!-- Inner Page Content End -->
<script>

    $("#home-tab").click(function () {
        $("#home-content").show();
        $("#profile").hide();
    });
    $("#profile-tab").click(function () {
        $("#home-content").hide();
        $("#profile").show();
    });

</script>
<script>
    $(function () {
        $('#register_form').validate({
            errorElement: 'div',
            errorClass: 'help-block',
            focusInvalid: false,
            rules: {
                password: {
                    minlength: 5
                },
                confirm_password: {
                    minlength: 5,
                    equalTo: "#password"
                }
            },
            highlight: function (e) {
                $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
            },
            success: function (e) {
                $(e).closest('.form-group').removeClass('has-error');
                $(e).remove();
            },
            errorPlacement: function (error, element) {
                if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                    var controls = element.closest('div[class*="col-"]');
                    if (controls.find(':checkbox,:radio').length > 1)
                        controls.append(error);
                    else
                        error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                } else if (element.is('.select2')) {
                    error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                } else if (element.is('.chosen-select')) {
                    error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                } else
                    error.insertAfter(element.parent());
            },
            invalidHandler: function (form) {
            }
        });
    });


</script>
<script>
    $(function () {
    $('#trackupload').validate({
    errorElement: 'div',
            errorClass: 'help-block',
            focusInvalid: false,
            highlight: function (e) {
            $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
            },
            success: function (e) {
            $(e).closest('.form-group').removeClass('has-error');
                    $(e).remove();
            },
            errorPlacement: function (error, element) {
            if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
            var controls = element.closest('div[class*="col-"]');
                    if (controls.find(':checkbox,:radio').length > 1)
                    controls.append(error);
                    else
                    error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
            } else if (element.is('.select2')) {
            error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
            } else if (element.is('.chosen-select')) {
            error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
            } else
                    error.insertAfter(element.parent());
            },
            invalidHandler: function (form) {
            },
    submitHandler: function (form) {

    $('.loading-overlay').fadeIn();
            window.scrollTo(0, 0);
            var formData = new FormData($(form)[0]);
            $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('home/add_track') ?>',
                    data:      formData,
                    dataType: "json",
                    processData: false,
                    contentType: false,
                    success: function (data) {
                    $('.loading-overlay').fadeOut();
                    $("#trackupload")[0].reset();
                    $(".custom-file-label").text("");
                    
                    showMessage(data.type, 'formErrorMsg', data.msg);
//                              if (data == 1 || data == '1') {
//                              $("#qualifyModelLabel").html("Thank you!");   
//                              $("#msg_qualify").html("Your message has been sent successfully.");
//                              $("#success_qualify").modal('show');
//
//                              }
//                              else{
//                                  $("#qualifyModelLabel").html("Sorry");
//                                  $("#msg_qualify").html("Fail to sent email please try again.");
//                                  $("#success_qualify").modal('show');
//                              }
                    }
            });
            return false;
    }
    });
    });
    $(document).ready(function(){
    $('input[type="file"]').change(function(e){
    var fileName = e.target.files[0].name;
            $(".custom-file-label").text(fileName);
    });
    });
    
    function showMessage(cls, divId, message) {
        $("#" + divId).show();
        $("#" + divId).html('');
        var html = '' + message + '';
        $("#" + divId).html(html);
        $("#" + divId).removeClass('alert-info').removeClass('alert-success').removeClass('alert-danger').addClass(cls).show('slow');
        $('html,body').animate({
            scrollTop: $("#" + divId).offset().top - 100
        }, 'slow');
        $('#contentContainer').animate({
            scrollTop: $("#" + divId).offset().top - 100
        }, 'slow');

    }

</script>