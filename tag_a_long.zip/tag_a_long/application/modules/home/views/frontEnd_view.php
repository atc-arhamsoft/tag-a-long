
  <?php $this->load->view('includes/home_header.php'); ?>

     <!-- top-header -->
<?php echo htmlspecialchars_decode($content); ?>


<?php $this->load->view('includes/home_footer.php'); ?>
