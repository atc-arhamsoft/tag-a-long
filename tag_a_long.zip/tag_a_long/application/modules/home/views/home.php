
<!-- Banner -->
            <section  id="head">
                <div class="container mt-80">
                    <div class="row">
                        <div class="col-md-8 animatable wow bounceInLeft">
                            <div class="banner-contant">
                                <h2><?php echo $page['heading_1']; ?></br><span class="yellow"><?php echo $page['heading_2']; ?></span> <?php echo $page['heading_3']; ?></h2>
                                    <p><?php echo $page['heading_discription']; ?></p>
                                    <div class="banner-button">
                                        <button class="btn btn-light">
                                            <i class="fab fa-apple   float-left"></i>
                                            <div class="hiden"><span><a href="https://itunes.apple.com/us/app/tag-a-long/id1454661068"> <?php echo $page['button_1_text_1']; ?> <strong><?php echo $page['button_1_text_2']; ?></strong></a></span></div>
                                        </button>
                                        <button class="btn btn-light ml-30 comingsoon-btn">
                                            <i class="fab fa-android float-left"></i>
                                            <div class="hiden"><span><?php echo $page['button_2_text_1']; ?><strong><?php echo $page['button_2_text_2']; ?></strong></span></div>
                                        </button>
                                    </div>
                                <div class="col-md-3 col-4 ios-download">
                                    <div class="ios">
                                        <i class="fab fa-apple"></i>
                                        <span><?php echo $page['button_5_text_1']; ?><strong><?php echo $page['button_5_text_2']; ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-4 totla-download">
                                    <div class="ios">
                                        <i class="fas fa-cloud-download-alt"></i>
                                        <span><?php echo $page['button_4_text_1']; ?><strong><?php echo $page['button_4_text_2']; ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-4 android-download">
                                    <div class="ios">
                                        <i class="fab fa-android"></i>
                                        <span><?php echo $page['button_3_text_1']; ?><strong><?php echo $page['button_3_text_2']; ?> <br/><?php echo $page['button_3_text_3']; ?></strong></span> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 animatable wow bounceInRight">
                            <div class="img-banner">
                                <img src="<?php echo IMG;?>ban-mobile.png" class="img-fluid" alt="mobile-img"/>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<!-- Banner End -->
 <!-- About Section Start  -->
            <section id="about"> 
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 animatable wow fadeInDown">
                            <div class="about-text">
                             <h2><?php echo $page['about_title_1']; ?><span class="yellow"><?php echo $page['about_title_2']; ?></span></h2> 
                             <p><?php echo $page['about_discription_line_1']; ?></p>
                             <p><?php echo $page['about_discription_line_2']; ?></p>    
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12 col-sm-12 animatable wow bounceInRight">
                            <div class="mt-80 about-text-device"><img src="<?php echo IMG;?>about-mbl.png" class="img-fluid" alt="about-mbl"/></div>
                        </div>
                        <div class="col-lg-7 col-md-12 col-sm-12 animatable wow bounceInLeft">
                            <div class="best-app best-app-text">
                                <h4><?php echo $page['about_sub_title_1']; ?> <span class="yellow"><?php echo $page['about_sub_title_2']; ?></span></h4>
                                <p><?php echo $page['about_sub_title_discription_1']; ?></p>
                                <p><?php echo $page['about_sub_title_discription_2']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
 <!-- Section 03  -->
                <section class="gry-bg about-icon-section">
                    <div class="container">
                        <div class="about-step-icons">
                            <div class="row">
 <!-- Bar Selection Icon -->
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12  animatable wow fadeInUp">
                                    <div class="about-step-box bar">
                                        <div class="about-icon">
                                            <img src="<?php echo IMG;?>bar-selection-icon.png" class="img-fluid" alt="">
                                        </div>
                                        <div class="about-step-detail">
                                            <h3 class="fw500 text-blue"><?php echo $page['bars_selection_title']; ?></h3>
                                            <p class="p-style"><?php echo $page['bars_selection_discription']; ?></p>
                                        </div>
                                    </div>
                                </div>
 <!-- Tag Friend Icon -->
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 animatable wow fadeInDown">
                                    <div class="about-step-box tag">
                                        <div class="about-icon">
                                            <img src="<?php echo IMG;?>tag-friend-icon.png" class="img-fluid" alt="">
                                        </div>
                                        <div class="about-step-detail">
                                            <h3 class="fw500 text-blue"><?php echo $page['tag_friend_title']; ?></h3>
                                            <p class="p-style"><?php echo $page['tag_friend_discription']; ?></p>
                                        </div>
                                    </div>
                                </div>
 <!-- Beat Selection Icon -->
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 animatable wow fadeInUp">
                                    <div class="about-step-box beat">
                                        <div class="about-icon">
                                            <img src="<?php echo IMG;?>beat-selection-icon.png" class="img-fluid" alt="">
                                        </div>
                                        <div class="about-step-detail">
                                            <h3 class="fw500 text-blue"><?php echo $page['beat_selection_title']; ?></h3>
                                            <p class="p-style"><?php echo $page['beat_selection_discription']; ?></p>
                                        </div>
                                    </div>
                                </div>
    <!-- Icons End --> 
                            </div>
                        </div>
                    </div>
                </section>
            </section>
 <!-- About Section End -->

<!-- Features Section Start -->
            <section class="feature-section-wrap" id="feature">
                <div class="container">
<!-- Feature section heading -->
                    <div class="col-xs-12 animatable wow fadeInDown">
                        <div class="feature-heading text-center">
                            <h2 class="section-heading"><b class="text-blue fw700"><?php echo $page['feature_title_1']; ?></b>&nbsp;<b class="text-yellow fw700"><?php echo $page['feature_title_2']; ?></b></h2>
                            <p class="p-style text-center section-salogan"><?php echo $page['feature_discription_line_1']; ?></p>
                            <p class="p-style text-center section-salogan"><?php echo $page['feature_discription_line_2']; ?></p>
                        </div>
                    </div>
                    <div class="row">
<!-- Feature section content -->
                        <div class="col-md-6 col-sm-6 col-xs-12 animatable wow bounceIn">
                            <div class="feature-device">
                                <img src="<?php echo IMG;?>feature-device-img.png" class="img-fluid" alt="">
                            </div>
                        </div>
<!-- Feature section featurs -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="feature-services-sections">
                                <ul>
<!-- Feature 01 -->
                                    <li class=" animatable wow bounceInRight">
                                        <div class="feature-service">
                                            <div class="about-icon feature-icon">
                                                <img src="<?php echo IMG;?>unlimited-features-icon.png" class="img-fluid" alt="">
                                            </div>
                                            <div class="feature-detail">
                                                <h3 class="fw500 text-blue"><?php echo $page['feature_sub_title_1']; ?></h3>
                                                <p class="p-style"><?php echo $page['feature_sub_discription_1']; ?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Feature 02 -->
                                    <li class="animatable wow bounceInRight">
                                        <div class="feature-service">
                                            <div class="about-icon feature-icon">
                                                <img src="<?php echo IMG;?>user-profile-icon.png" class="img-fluid" alt="">
                                            </div>
                                            <div class="feature-detail">
                                                <h3 class="fw500 text-blue"><?php echo $page['feature_sub_title_2']; ?></h3>
                                                <p class="p-style"><?php echo $page['feature_sub_discription_2']; ?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Feature 03 -->
                                    <li class="animatable wow bounceInRight">
                                        <div class="feature-service">
                                            <div class="about-icon feature-icon">
                                                <img src="<?php echo IMG;?>menu-icon.png" class="img-fluid" alt="">
                                            </div>
                                            <div class="feature-detail">
                                                <h3 class="fw500 text-blue"><?php echo $page['feature_sub_title_3']; ?></h3>
                                                <p class="p-style"><?php echo $page['feature_sub_discription_3']; ?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Feature 04 -->
                                    <li class="animatable wow bounceInRight">
                                        <div class="feature-service">
                                            <div class="about-icon feature-icon">
                                                <img src="<?php echo IMG;?>collaboration-icon.png" class="img-fluid" alt="">
                                            </div>
                                            <div class="feature-detail">
                                                <h3 class="fw500 text-blue"><?php echo $page['feature_sub_title_4']; ?></h3>
                                                <p class="p-style"><?php echo $page['feature_sub_discription_4']; ?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Feature 05 -->
                                    <li class="animatable wow bounceInRight">
                                        <div class="feature-service">
                                            <div class="about-icon feature-icon">
                                                <img src="<?php echo IMG;?>newsfeeds-icon.png" class="img-fluid" alt="">
                                            </div>
                                            <div class="feature-detail">
                                                <h3 class="fw500 text-blue"><?php echo $page['feature_sub_title_5']; ?></h3>
                                                <p class="p-style"><?php echo $page['feature_sub_discription_5']; ?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Features End -->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<!-- Features Section End -->

<!-- Download our app Section -->
            <section class="download-section-wrap section-bg pt-100">
                <div class="container">
                    <div class="Download-ourapp">
<!-- Download app heading -->
                        <div class="feature-heading text-center animatable wow fadeInDown">
                            <h2 class="section-heading white"><b class="text-white fw700"> <?php echo $page['download_title_1']; ?></b>&nbsp;<b class="text-yellow fw700"><?php echo $page['download_title_2']; ?></b></h2>
                            <p class="p-style text-white section-salogan"><?php echo $page['download_discription_line_1']; ?></p>
                            <p class="p-style text-white section-salogan"><?php echo $page['download_discription_line_2']; ?></p>
                        </div>
<!-- Download app buttons -->
                        <div class="Download-ourapp-buttons text-center mt-20">
                            <button class="btn btn-light animatable wow bounceInLeft"><i class="fab fa-apple  float-left"></i>
                                <a href="https://itunes.apple.com/us/app/tag-a-long/id1454661068"> <span><?php echo $page['download_button_1_text_1']; ?><br><strong><?php echo $page['download_button_1_text_2']; ?></strong></span></a>
                            </button>
                            <button class="btn btn-light comingsoon-btn ml-20 animatable wow bounceInRight"><i class="fab fa-android float-left"></i>
                                <span><?php echo $page['download_button_2_text_1']; ?><br><strong><?php echo $page['download_app_button_2_text_2']; ?></strong></span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>
<!-- Download our app Section End -->

<!-- app Reviews Section Strat -->
            <section class="app-review-wrap" id="review">
                <div class="container">
<!-- App Review heading -->
                    <div class="feature-heading text-center animatable wow fadeInUp">
                        <h2 class="section-heading"><b class="text-blue fw700"><?php echo $page['review_title_1']; ?></b>&nbsp;<b class="text-yellow fw700"><?php echo $page['review_title_2']; ?></b></h2>
                        <p class="p-style text-p section-salogan"><?php echo $page['review_discription_line_1']; ?></p>
                        <p class="p-style text-p section-salogan"><?php echo $page['review_discription_line_2']; ?></p>
                    </div>
<!-- App reviews from users -->
                    <div class="row">
                        <div class="col-md-12 animatable wow moveUp">
                            <div class="carousel slide" data-ride="carousel" id="quote-carousel">
<!-- Carousel Buttons Next/Prev -->
                            <div class="quote-carousel-arrows">
                                <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
                                <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                            </div>
<!-- Bottom Carousel Indicators -->
                                <ol class="carousel-indicators">
                                    <?php 
                                    $var = 0;
                                    $cls = 'active';
                                    foreach ($testimonial as $value) {  ?>
                                            <li data-target="#quote-carousel" data-slide-to="<?php echo $var; ?>" class="<?php echo $cls; ?>"><img class="img-fluid" src="<?php echo $value['image_url']?>" alt=""></li>
                                    <?php $var++;  $cls = ' '; } ?>
                                </ol>
<!-- Carousel Slides / Quotes -->
                                <div class="carousel-inner quote-inner text-center">
<!-- Quote 0 -->                       <?php
                                        $class = 'active';
                                        foreach ($testimonial as $val) {  ?>
                                            <div class="carousel-item <?php echo $class; ?>">
                                        <blockquote>
                                            <div class="quote-content">
                                                <h4 class="text-blue fw600"><?php echo $val['name']?></h4>
                                                <span class="quote-stars">
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                </span>
                                                <p class="p-style mt-10"><?php echo $val['about']?></p>
                                            </div>
                                        </blockquote>
                                    </div>
                                       <?php $class = ''; }
                                        ?>
                                   
<!-- Quote 2 -->
                                </div>
<!-- Quotes End -->
                            </div>
                        </div>
                    </div>
<!-- App reviews from users End -->
                </div>
            </section>
<!-- app Reviews Section End -->

<!-- App Secreenshorts Section Strat -->
            <section class="app-secreenshort-wrap" id="appscreens">
                <div class="container">
<!-- App Secreenshorts heading -->
                    <div class="feature-heading text-center animatable wow fadeInUp">
                        <h2 class="section-heading"><b class="text-blue fw700"><?php echo $page['screenshot_title_1']; ?></b>&nbsp;<b class="text-yellow fw700"><?php echo $page['screenshot_title_2']; ?></b></h2>
                        <p class="p-style text-p section-salogan"><?php echo $page['screenshot_discription_line_1']; ?></p>
                        <p class="p-style text-p section-salogan"><?php echo $page['screenshot_discription_line_2']; ?></p>
                    </div>
                    <div class="col-xs-12 animatable wow fadeInDown">
<!-- App Secreenshorts slider -->
<!-- Slider main container -->
                        <div class="swiper-container appscreens">
<!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
<!-- Slides -->
                                <div class="swiper-slide"><img src="<?php echo IMG;?>slider-screen-01.png" alt=""></div>
                                <div class="swiper-slide"><img src="<?php echo IMG;?>slider-screen-02.png" alt=""></div>
                                <div class="swiper-slide"><img src="<?php echo IMG;?>slider-screen-03.png" alt=""></div>
                                <div class="swiper-slide"><img src="<?php echo IMG;?>slider-screen-04.png" alt=""></div>
                                <div class="swiper-slide"><img src="<?php echo IMG;?>slider-screen-05.png" alt=""></div>
                            </div>
<!-- If we need navigation buttons -->
                            <div class="swiper-arrow">
                                <div class="swiper-button-prev"><i class="fa fa-chevron-left" aria-hidden="true"></i></div>
                                <div class="swiper-button-next"><i class="fa fa-chevron-right" aria-hidden="true"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<!-- App Secreenshorts Section End -->
