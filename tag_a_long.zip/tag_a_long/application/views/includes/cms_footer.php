
<!-- Footter Section Start -->
<footer class="footer-wrap footer-bg inner-footer" id="support">
                <div class="container">
<!-- Newsletter -->
                    <div class="row">
                        <div class="newsletter-section">
<!-- Newsletter heading -->
                            <div class="newsletter-heading text-center animatable wow bounceInRight">
                                <h3 class="text-white fw700"><?php echo $page['subcribe_email_title']; ?></h3>
                                <p class="p-style text-white section-salogan">There are many <?php echo $page['subcribe_email_discription']; ?>
                            </div>
<!-- Newsletter field -->
                            <div class="newsletter-form animatable wow bounceInLeft">
                            <?php if ($this->session->flashdata('errorr')) { ?>
                                <div class="alert alert-danger col-sm-12"><?php echo $this->session->flashdata('errorr'); ?></div>
                                <?php } ?>
                                <?php if ($this->session->flashdata('successs')) { ?>
                                <div class="alert alert-success col-sm-12"><?php echo $this->session->flashdata('successs'); ?></div>
                                <?php
                                }
                                ?> 
                                <form action="<?php echo base_url().'/'.'home/subcribeFromCms';?>" method="post">
                                    <div class="input-group">
                                        <input type="email" id="subcribe_email" name="subcribe_email" class="form-control" placeholder="Enter your Email address" aria-label="Enter your Email address" aria-describedby="basic-addon2" required>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="submit">Subscrube</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
<!-- Footer Social Icons -->
                            <div class="social-icons animatable wow fadeInUp">
                                <ul>
                                <li><a href="<?php echo $row['facebook_url']?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['twitter_url']?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['google_plus_url']?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['linkedin_url']?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['pinterest_url']?>" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['youtube_url']?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>                
            </footer>
<!-- Footter Section End -->

<!-- Copyright bar Start -->
            <section class="copyright-wrap animatable wow fadeInDown">
                <div class="copyright">
                    <p class="p-style text-center"><?php echo $page['copyright']; ?><a href="#" class="text-yellow"><?php echo $page['sitename']; ?></a></p>
                </div>
            </section>
<!-- Copyright bar Start -->
  </div>

  
  
 
  <script>
      var swiper = new Swiper('.swiper-container', {
          effect: 'coverflow',
          grabCursor: true,
          centeredSlides: true,
          slidesPerView: 5,
          spaceBetween: 25,
          loop: true,
              coverflowEffect: {
              rotate: 10,
              stretch: 0,
              depth: 40,
              modifier: 2,
              slideShadows : false,
              },
              breakpoints: {
              1200: {
                  slidesPerView: 5,
                  // spaceBetween: 40,
              },
              1024: {
                  slidesPerView: 4,
                  // spaceBetween: 40,
              },
              992: {
                  slidesPerView: 3,
                  // spaceBetween: 30,
              },
              767: {
                  slidesPerView: 1,
                  // spaceBetween: 30,
              },
              640: {
                  slidesPerView: 1,
                  spaceBetween: 15,
              },
              320: {
                  slidesPerView: 1,
                  spaceBetween: 10,
              }
          },
  // If neended pagination
          pagination: {
              el: '.swiper-pagination',
          },
  // Navigation arrows
          navigation: {
              nextEl: '.swiper-button-next',
              prevEl: '.swiper-button-prev',
          },
  // And if we need scrollbar
          scrollbar: {
              el: '.swiper-scrollbar',
          },
      });
// Smooth Scrolll Script
    jQuery(document).ready(function($) {
      setTimeout(function() {
          $('.alert').fadeOut('slow');
         }, 3000);
        function scrollToSection(event) {
            event.preventDefault();
            var $section = $($(this).attr('href')); 
            $('html, body').animate({
                scrollTop: $section.offset().top
            }, 700);
        }
        $('[data-scroll]').on('click', scrollToSection);
    }(jQuery));
  </script>
<!--<script type="text/javascript" src="https://js.stripe.com/v2/"></script>-->
<script type="text/javascript">
   //Stripe.setPublishableKey('<?php echo STRIPE_PK; ?>');
  //Stripe.setPublishableKey('pk_test_jYsw9tqg81T713qyAy6uWRz8');
</script>
<script>
//function validatePaybyCredit(creditCardForm)
//{
//    creditCardForm.validate({
//        ignore: "input[type='text']:hidden",
//        onfocusout: false,
//        rules: {
//           
//            ccard_number: {required: true, number: true, maxlength: 16, minlength: 16},
//            expire_month: {required: true},
//            expire_year: {required: true},
//            cvv: {required: true, maxlength: 4},
//        },
//        messages: {
//            ccard_number: {required: "Valid Card Number is required", number: "Provide a valid card Number",
//                maxlength: "Length should be 16 characters", minlength: "Length should be 16 characters"},
//            expire_month: {required: "Expire Month is required"},
//            expire_year: {required: "Expire Year is required"},
//            cvv: {required: "CVV code is required", maxlength: "CVV code should be 4 characters"},
//        },
//
//        highlight: function (element) {
//            $(element).parent().css("color", "red");
//        },
//        errorPlacement: function (error, element) {},
//        invalidHandler: function (form, validator) {
//            var errors = validator.numberOfInvalids();
//            if (errors) {
//                $('#stripformerrorcontainer').fadeIn('slow');
//                $('#stripformerrors').html( validator.errorList[0].message);
//                validator.errorList[0].element.focus(); //Set Focus
//            }
//        }
//
//    });
//}
//
//
//function payByCredit()
//{
//   var paymentForm = document.getElementById('payment-form');
//   var form_data = new FormData(paymentForm);
//    var creditForm = $("#payment-form");
//    validatePaybyCredit(creditForm);
//    if (creditForm.valid()) {
//
//        creditForm.find('.submit').prop('disabled', true);
//        Stripe.card.createToken(creditForm, stripeResponseHandler);
//        return false;
//    } else {
//        $('.submit').prop('disabled', false);
//        
//        $('#errorContainer').show();
//    }
//}
//
//function stripeResponseHandler(status, response) {
//    //console.log(status);
//    //console.log(response);
//    $('#stripformerrorcontainer').hide();
//    if (response.error) {
//        $("#ccard_number").val('');
//        $("#stripe_cvv").val('');
//        $('#stripformerrorcontainer').css('display', 'block');
//        $('#stripformerrors').html(response.error.message);
//        $('.submit').prop('disabled', false); // Re-enable submission
//
//    } else {
//        //console.log(response);
//        var token = response.id;
//        //console.log("token is: " + token);
//        $('#payment-form').append("<input type='hidden' name='token' value='" + token + "' >");
//        $('#payment-form').submit();
//        $("#ccard_number").val('');
//        $("#stripe_cvv").val('');
//        $("#stripe_expire_month").val('');
//        $("#stripe_expire_year").val('');
//        
//     
//    }
//}
</script>

</body>
</html>
