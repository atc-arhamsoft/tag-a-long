  <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo SITE_TITLE; ?></title>
        <link href="<?php echo base_url('assets/site'); ?>/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url('assets/site'); ?>/css/style.css" rel="stylesheet">
        <link type="image/x-icon" rel="icon" href="<?php echo base_url('uploads/site/pic/' . FAVICON); ?>">
        <link type="image/x-icon" rel="shortcut icon" href="<?php echo base_url('uploads/site/pic/' . FAVICON); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/site'); ?>/css/animate.min.css" type="text/css">
        <link rel="stylesheet" href="<?php echo base_url('assets/site'); ?>/css/custom.css" type="text/css">
        <link rel="stylesheet" href="<?php echo base_url('assets/site'); ?>/css/font-elegant.min.css" type="text/css">    
        <link rel="stylesheet" href="<?php echo base_url('assets/site'); ?>/css/lightslider.css" type="text/css">    
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500" rel="stylesheet">
          <link rel="stylesheet" href="<?php echo base_url('assets/admin/css/datepicker.min.css'); ?>" />
          <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
            <script src=" https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js "></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
             <script src="<?php echo base_url('assets/site'); ?>/js/bootstrap.js "></script>
             <script src="<?php echo base_url('assets/site'); ?>/js/lightslider.js "></script>
             <script src="<?php echo base_url('assets/site'); ?>/js/sweetalert.min.js"></script>
<script type="text/javascript">
  BASE_URL  = '<?php echo base_url(); ?>'
</script>
    </head>

  