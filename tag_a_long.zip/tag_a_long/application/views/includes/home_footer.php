
<!-- Footter Section Start -->
<footer class="footer-wrap footer-bg" id="support">
                <div class="container">
<!-- Get in touch heading -->
                    <div class="footer-heading text-center animatable wow moveUp">
                        <h2 class="section-heading white"><b class="text-white fw700"><?php echo $page['contact_title_1']; ?></b>&nbsp;<b class="text-yellow fw700"><?php echo $page['contact_title_2']; ?></b></h2>
                        <p class="p-style text-white section-salogan"><?php echo $page['contact_discription_line_1']; ?></p>
                        <p class="p-style text-white section-salogan"><?php echo $page['contact_discription_line_2']; ?></p>
                    </div>
<!-- Message, Contact, Downlaod App Section ROW -->
                    <div class="row mt-100 mb-80">
<!-- Say hello Fields -->
                        <div class="col-lg-5 col-md-12 col-sm-12 animatable wow bounceInLeft">
<!-- Send US Message -->
                            <div class="send-message" id="message_div">
                                <?php if ($this->session->flashdata('error')) { ?>
                                <div class="alert alert-danger col-sm-12"><?php echo $this->session->flashdata('error'); ?></div>
                                <?php } ?>
                                <?php if ($this->session->flashdata('success')) { ?>
                                <div class="alert alert-success col-sm-12"><?php echo $this->session->flashdata('success'); ?></div>
                                <?php
                                }
                                ?> 
                                <h4 class="text-white fw500 mb-30"><?php echo $page['email_us_title']; ?></h4>
                                <div class="message-fields">
                                    <form action="<?php echo base_url('home/send_email') ?>" method="post">
<!-- name field -->
                                        <div class="form-group tag-fields">
                                            <input type="name" class="form-control" id="name" name="name" placeholder="Name" required>
                                        </div>
<!-- Email Field -->
                                        <div class="form-group tag-fields">
                                            <input type="email" class="form-control" name="user_email" placeholder="Email" id="user_email" required>
                                        </div>
<!-- Subject Field -->
                                        <div class="form-group tag-fields">
                                            <input type="text" class="form-control" name="subject" placeholder="Subject" id="subject" required>
                                        </div>
<!-- Message Field -->
                                        <div class="form-group tag-fields">
                                            <textarea class="form-control" name="message" id="message" placeholder="Massage" rows="4" required></textarea>
                                        </div>
                                        <div class="tag-fields">
                                            <button type="submit" class="btn btn-submit p-style text-blue fw600">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
<!-- Contact us section -->
                        <div class="col-lg-4 col-md-6 col-sm-12 animatable wow fadeInDown">
                            <div class="contact-detail-section">
                                <h4 class="text-white fw500 mb-30"><?php echo $page['contact_info_title']; ?></h4>
                                <ul>
<!-- Contact 01 -->
                                    <li>
                                        <div class="contact-box">
                                            <div class="contact-icon">
                                                <i class="fa fa-phone" aria-hidden="true"></i>
                                            </div>
                                            <div class="contact-detail">
                                                <p><?php echo $row['site_phone']?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Contact 02 -->
                                    <li>
                                        <div class="contact-box">
                                            <div class="contact-icon">
                                                <i class="fa fa-globe" aria-hidden="true"></i>
                                            </div>
                                            <div class="contact-detail">
                                            <p><?php echo $row['site_email']?></p>
                                            </div>
                                        </div>
                                    </li>
<!-- Contact 03 -->
                                    <li>
                                        <div class="contact-box">
                                            <div class="contact-icon">
                                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                            </div>
                                            <div class="contact-detail">
                                                <p><?php echo $row['address']?></p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
<!-- Download buttons section -->
                        <div class="col-lg-3 col-md-6 col-sm-12 animatable wow bounceInRight">
                            <div class="downlaod-app-footer">
                                <h4 class="text-white fw500 mb-30"><?php echo $page['download_app_title']; ?></h4>
                                <ul>
                                    <li><a href="https://itunes.apple.com/us/app/tag-a-long/id1454661068"><button type="button" class="btn btn-light">
                                        <i class="fab fa-apple float-left"></i>
                                        <span><?php echo $page['download_app_button_1_text_1']; ?><br><strong><?php echo $page['download_app_button_1_text_2']; ?></strong></span>
                                    </button></a></li>
                                    <li><button type="button" class="btn btn-light comingsoon-btn">
                                        <i class="fab fa-android float-left"></i>
                                        <span><?php echo $page['download_app_button_2_text_1']; ?><br><strong><?php echo $page['download_app_button_2_text_2']; ?></strong></span>
                                    </button></li>
                                </ul>
                            </div>
                        </div>
<!-- Message, Contact, Downlaod App Section ROW End -->
                    </div>
<!-- Newsletter -->
                    <div class="row">
                        <div class="newsletter-section">
<!-- Newsletter heading -->
                            <div class="newsletter-heading text-center animatable wow bounceInRight">
                                <h3 class="text-white fw700"><?php echo $page['subcribe_email_title']; ?></h3>
                                <p class="p-style text-white section-salogan"><?php echo $page['subcribe_email_discription']; ?></p>
                            </div>
<!-- Newsletter field -->
                            <div class="newsletter-form animatable wow bounceInLeft">
                            <?php if ($this->session->flashdata('errorr')) { ?>
                                <div class="alert alert-danger col-sm-12"><?php echo $this->session->flashdata('errorr'); ?></div>
                                <?php } ?>
                                <?php if ($this->session->flashdata('successs')) { ?>
                                <div class="alert alert-success col-sm-12"><?php echo $this->session->flashdata('successs'); ?></div>
                                <?php
                                }
                                ?> 
                                <form action="<?php echo base_url('home/subcribe') ?>" method="POST">
                                    <div class="input-group">
                                        <input type="email" id="subcribe_email" name="subcribe_email"  class="form-control" placeholder="Enter your Email address"    aria-label="Enter your Email address" aria-describedby="basic-addon2"
                                        required>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="submit">Subscrube</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
<!-- Footer Social Icons -->
                            <div class="social-icons animatable wow fadeInUp">
                                <ul>
                                    <li><a href="<?php echo $row['facebook_url']?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['twitter_url']?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['google_plus_url']?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['linkedin_url']?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['pinterest_url']?>" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                                    <li><a href="<?php echo $row['youtube_url']?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>                
            </footer>
<!-- Footter Section End -->

<!-- Copyright bar Start -->
            <section class="copyright-wrap animatable wow fadeInDown">
                <div class="copyright">
                    <p class="p-style text-center"><?php echo $page['copyright']; ?><a href="#" class="text-yellow"><?php echo $page['sitename']; ?></a></p>
                </div>
            </section>
<!-- Copyright bar Start -->
  </div>

    <script src="<?php echo JS; ?>jquery-3.3.1.min.js"></script>
    <script src="<?php echo JS; ?>bootstrap.min.js"></script>
    <script src="<?php echo JS; ?>wow.min.js" type="text/javascript"></script>
    <script>new WOW().init();</script>
   	<script type="text/javascript"> Placeholdem(document.querySelectorAll('[placeholder]'));</script>
    <script src="<?php echo SWIPER; ?>swiper.min.js"></script>
  <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper('.swiper-container', {
            effect: 'coverflow',
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: 5,
            spaceBetween: 25,
            loop: true,
                coverflowEffect: {
                rotate: 10,
                stretch: 0,
                depth: 40,
                modifier: 2,
                slideShadows : false,
                },
                breakpoints: {
                1200: {
                    slidesPerView: 5,
                    // spaceBetween: 40,
                },
                1024: {
                    slidesPerView: 4,
                    // spaceBetween: 40,
                },
                992: {
                    slidesPerView: 3,
                    // spaceBetween: 30,
                },
                767: {
                    slidesPerView: 1,
                    // spaceBetween: 30,
                },
                640: {
                    slidesPerView: 1,
                    spaceBetween: 15,
                },
                320: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            },
    // If neended pagination
            pagination: {
                el: '.swiper-pagination',
            },
    // Navigation arrows
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
    // And if we need scrollbar
            scrollbar: {
                el: '.swiper-scrollbar',
            },
        });
        // Smooth Scrolll Script
    jQuery(document).ready(function($)
    {    
        setTimeout(function() {
          $('.alert').fadeOut('slow');
         }, 3000);
        function scrollToSection(event) {
            event.preventDefault();
            var $section = $($(this).attr('href')); 
            $('html, body').animate({
                scrollTop: $section.offset().top
            }, 700);
        }
        $('[data-scroll]').on('click', scrollToSection);
    }(jQuery));
    // Sticky Navigation JS
    $(window).scroll(function(){
        if ($(window).scrollTop() >= 900) {
            $('.headertop').addClass('fixed-header');
        }
        else {
            $('.headertop').removeClass('fixed-header');
        }
    });
    </script>
    </body>
    </html>