<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title><?php echo $row['site_title'];?></title>
        <link rel="shortcut icon" type="image/png" href="<?php echo base_url('uploads/site/pic/'.$row['favicon']);?>"/>
		<link rel="stylesheet" href="<?php echo CSS; ?>bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo CSS; ?>all.css">
		<link rel="stylesheet" href="<?php echo CSS; ?>style.css">
        <link rel="stylesheet" href="<?php echo CSS; ?>responsive.css">
        <link rel="stylesheet" href="<?php echo CSS; ?>animate.min.css">
        <link rel="stylesheet" href="<?php echo CSS; ?>animation.css">
        <link href="<?php echo CSS; ?>font-awesome.min.css" rel="stylesheet">
<!-- Swiper Slider css -->
        <link rel="stylesheet" href="<?php echo SWIPER; ?>swiper.css">
        <!-- <link rel="stylesheet" href="swiper/swiper.min.css"> -->

	</head>
	<body>
        <div class="wrapper">
<!-- header Start -->
<header class="headertop">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-7 col-7">
                        <div class="logo"><a class="nav-link" href="<?php echo base_url()?>"><img src="<?php echo base_url('uploads/site/pic/'.SITE_LOGO); ?>"></a></div>
                    </div>
                    <div class="col-md-9 col-sm-5 col-5">
                        <nav class="navbar navbar-expand-lg navbar-light float-right">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="fa fa-bars" aria-hidden="true"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <li class=" active"><a data-scroll class="nav-link active" href="#home">Home</a></li>
                                    <!-- <li class=""><a data-scroll class="nav-link" href="#about">About Us</a></li> -->
                                    <?php foreach($navBar as $nav){ ?>
                                    <li class=""><a  class="nav-link" href="<?php echo base_url('cms') .'/'. $nav['slug']?>">
                                    <?php echo $nav['title']?>
                                    </a></li>
                                    <?php
                                    }
                                    ?>
                                    <!-- <li class=""><a data-scroll class="nav-link" href="#feature">Features</a></li>
                                    <li class=""><a data-scroll class="nav-link" href="#review">Reviews</a></li>
                                    <li class=""><a data-scroll class="nav-link" href="#appscreens">Screenshort</a></li>
                                    <li class=""><a data-scroll class="nav-link" href="#support">Support</a></li> -->
                                    <li class=""><a class="nav-link" href="<?php echo base_url('track');?>">Upload Track</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
<!-- header End -->