
  <?php $this->load->view('includes/head.php'); ?>

    	
   <?php  $this->load->view('includes/header.php'); ?>
        <!-- top-header -->
 <?php echo htmlspecialchars_decode($content); ?>

  
   <?php $this->load->view('includes/footer.php'); ?>
